import React, { useState, useEffect } from 'react';
import { Plus, Users, Play, BarChart3, Trash2, Edit2, Calendar, Zap, X, Send, Wifi, WifiOff, Radio } from 'lucide-react';

// Firebase configured - set USE_FIREBASE = true when deploying
const USE_FIREBASE = false;

const FORMATIONS = {
  'Spread': [
    { position_id: 'WR_X', x: 5, y: 10 }, { position_id: 'LT', x: 19, y: 10 }, { position_id: 'LG', x: 22, y: 10 },
    { position_id: 'C', x: 25, y: 10 }, { position_id: 'RG', x: 28, y: 10 }, { position_id: 'RT', x: 31, y: 10 },
    { position_id: 'WR_Z', x: 45, y: 10 }, { position_id: 'QB', x: 25, y: 3 }, { position_id: 'RB', x: 25, y: 0 },
    { position_id: 'WR_Y', x: 15, y: 9 }, { position_id: 'TE', x: 35, y: 9 }
  ],
  'Shotgun': [
    { position_id: 'WR_X', x: 5, y: 10 }, { position_id: 'LT', x: 19, y: 10 }, { position_id: 'LG', x: 22, y: 10 },
    { position_id: 'C', x: 25, y: 10 }, { position_id: 'RG', x: 28, y: 10 }, { position_id: 'RT', x: 31, y: 10 },
    { position_id: 'WR_Z', x: 45, y: 10 }, { position_id: 'QB', x: 25, y: 5 }, { position_id: 'RB', x: 20, y: 5 },
    { position_id: 'WR_Y', x: 10, y: 9 }, { position_id: 'TE', x: 33, y: 10 }
  ],
  'I-Formation': [
    { position_id: 'WR_X', x: 5, y: 10 }, { position_id: 'LT', x: 19, y: 10 }, { position_id: 'LG', x: 22, y: 10 },
    { position_id: 'C', x: 25, y: 10 }, { position_id: 'RG', x: 28, y: 10 }, { position_id: 'RT', x: 31, y: 10 },
    { position_id: 'TE', x: 33, y: 10 }, { position_id: 'QB', x: 25, y: 5 }, { position_id: 'FB', x: 25, y: 2 },
    { position_id: 'RB', x: 25, y: 0 }, { position_id: 'WR_Z', x: 45, y: 9 }
  ],
  'Empty': [
    { position_id: 'WR_X', x: 5, y: 10 }, { position_id: 'LT', x: 19, y: 10 }, { position_id: 'LG', x: 22, y: 10 },
    { position_id: 'C', x: 25, y: 10 }, { position_id: 'RG', x: 28, y: 10 }, { position_id: 'RT', x: 31, y: 10 },
    { position_id: 'WR_Z', x: 45, y: 10 }, { position_id: 'QB', x: 25, y: 5 }, { position_id: 'WR_Y', x: 15, y: 9 },
    { position_id: 'TE', x: 35, y: 9 }, { position_id: 'WR_H', x: 40, y: 9 }
  ]
};

// Personnel groupings (standard NFL notation: first digit = RBs, second = TEs)
const PERSONNEL_GROUPINGS = {
  '11': { // 1 RB, 1 TE, 3 WR - most common spread
    name: '11 Personnel (1 RB, 1 TE, 3 WR)',
    positions: ['QB', 'RB', 'TE', 'WR_X', 'WR_Y', 'WR_Z', 'LT', 'LG', 'C', 'RG', 'RT']
  },
  '12': { // 1 RB, 2 TE, 2 WR
    name: '12 Personnel (1 RB, 2 TE, 2 WR)',
    positions: ['QB', 'RB', 'TE_Y', 'TE_F', 'WR_X', 'WR_Z', 'LT', 'LG', 'C', 'RG', 'RT']
  },
  '13': { // 1 RB, 3 TE, 1 WR - heavy
    name: '13 Personnel (1 RB, 3 TE, 1 WR)',
    positions: ['QB', 'RB', 'TE_Y', 'TE_F', 'TE_U', 'WR_X', 'LT', 'LG', 'C', 'RG', 'RT']
  },
  '21': { // 2 RB (includes FB), 1 TE, 2 WR
    name: '21 Personnel (1 RB, 1 FB, 1 TE, 2 WR)',
    positions: ['QB', 'RB', 'FB', 'TE', 'WR_X', 'WR_Z', 'LT', 'LG', 'C', 'RG', 'RT']
  },
  '22': { // 2 RB, 2 TE, 1 WR - power/goal line
    name: '22 Personnel (1 RB, 1 FB, 2 TE, 1 WR)',
    positions: ['QB', 'RB', 'FB', 'TE_Y', 'TE_F', 'WR_X', 'LT', 'LG', 'C', 'RG', 'RT']
  },
  '23': { // 2 RB, 3 TE, 0 WR - jumbo/goal line
    name: '23 Personnel (1 RB, 1 FB, 3 TE, 0 WR)',
    positions: ['QB', 'RB', 'FB', 'TE_Y', 'TE_F', 'TE_U', 'LT', 'LG', 'C', 'RG', 'RT']
  },
  '10': { // 1 RB, 0 TE, 4 WR - empty spread
    name: '10 Personnel (1 RB, 0 TE, 4 WR)',
    positions: ['QB', 'RB', 'WR_X', 'WR_Y', 'WR_Z', 'WR_H', 'LT', 'LG', 'C', 'RG', 'RT']
  },
  '20': { // 2 RB, 0 TE, 3 WR 
    name: '20 Personnel (1 RB, 1 FB, 0 TE, 3 WR)',
    positions: ['QB', 'RB', 'FB', 'WR_X', 'WR_Y', 'WR_Z', 'LT', 'LG', 'C', 'RG', 'RT']
  }
};

// Route templates - realistic football route shapes
// Points are relative offsets from starting position (x, y in yards)
const ROUTE_TEMPLATES = {
  'Hitch': { name: 'Hitch (5-6 yd)', points: [[0, 6], [0, 5]], description: 'Run 6, turn back' },
  'Slant': { name: 'Slant', points: [[0, 3], [6, 8]], description: '3 steps, break inside 45°' },
  'Out': { name: 'Out (5 yd)', points: [[0, 5], [6, 5]], description: 'Stem 5, break outside' },
  'In/Dig': { name: 'In/Dig (10 yd)', points: [[0, 10], [-8, 10]], description: 'Stem 10, break inside' },
  'Comeback': { name: 'Comeback (12 yd)', points: [[0, 12], [2, 10]], description: 'Stem 12, break back outside' },
  'Curl': { name: 'Curl (10 yd)', points: [[0, 10], [-1, 9]], description: 'Stem 10, turn back inside' },
  'Corner': { name: 'Corner', points: [[0, 10], [6, 18]], description: 'Stem 10, break to corner' },
  'Post': { name: 'Post', points: [[0, 10], [-6, 18]], description: 'Stem 10, break to post' },
  'Go/Fly': { name: 'Go/Fly', points: [[0, 25]], description: 'Vertical route' },
  'Flat': { name: 'Flat', points: [[5, 2]], description: 'Quick out to flat' },
  'Wheel': { name: 'Wheel', points: [[4, 0], [6, 5], [4, 15]], description: 'Arc to sideline, up' },
  'Swing': { name: 'Swing', points: [[-3, -1], [-5, 2], [-3, 5]], description: 'RB swing route' },
  'Angle': { name: 'Angle', points: [[3, 1], [-3, 6]], description: 'Stem out, break in' },
  'Seam': { name: 'Seam', points: [[0, 20]], description: 'Vertical up the seam' },
  'Drag': { name: 'Drag/Shallow', points: [[0, 2], [12, 3]], description: 'Shallow cross' },
  'Crosser': { name: 'Crosser (12 yd)', points: [[0, 12], [15, 12]], description: 'Deep cross' },
  'Stick': { name: 'Stick (6 yd)', points: [[0, 6]], description: 'Stem 6, sit' },
  'Whip': { name: 'Whip', points: [[0, 6], [3, 6], [0, 8]], description: 'Out and back in' },
  'Sail': { name: 'Sail', points: [[0, 3], [8, 15]], description: 'Corner from off' },
  'Screen': { name: 'Screen', points: [[-2, -2], [-5, 0]], description: 'RB screen path' },
  'Check/Release': { name: 'Check/Release', points: [[0, 0], [0, 5], [4, 7]], description: 'Block check then release' },
  'Blocking': { name: 'Pass Pro/Block', points: [[0, 0]], description: 'Stay and block' }
};

// ============== PLAY TEMPLATE LIBRARY ==============
const PLAY_TEMPLATES = {
  // PASSING CONCEPTS
  'Smash': { category: 'Passing', formation: 'Spread', description: 'Corner + Hitch - High/Low on CB', positions: [
    // X receiver - Hitch at 5-6 yards (sit in soft spot vs Cover 2)
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:16},{x:4,y:15}], route_details: { alignment: 'on', steps: 'Hitch at 6', landmark: '6 yards', read_key: 'CB', coaching_point: 'Sit in soft spot of Cover 2' }},
    // Z receiver - Corner route (stem 10, break to corner)
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:45,y:20},{x:49,y:28}], route_details: { alignment: 'on', steps: 'Corner at 10-12', landmark: 'Sideline/Pylon', read_key: 'Safety', coaching_point: 'Vertical stem, snap break at 10, get to sideline' }},
    // Slot - Dig/In to occupy the safety
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:15,y:19},{x:25,y:19}], route_details: { alignment: 'off', steps: 'Dig at 10', landmark: 'Middle', read_key: 'Safety', coaching_point: 'Occupy FS, sit vs zone' }},
    // TE - Flat to widen the flat defender
    { position_id: 'TE', route_points: [{x:33,y:10},{x:40,y:12}], route_details: { alignment: 'on', steps: 'Flat', landmark: 'Numbers', read_key: 'Flat', coaching_point: 'Widen flat defender, option route vs man' }},
    { position_id: 'LT', route_points: [{x:19,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Kick slide' }},
    { position_id: 'LG', route_points: [{x:22,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gap', read_key: 'DT', coaching_point: 'Inside out' }},
    { position_id: 'C', route_points: [{x:25,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gaps', read_key: 'Mike', coaching_point: 'ID mike' }},
    { position_id: 'RG', route_points: [{x:28,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gap', read_key: 'DT', coaching_point: 'Handle twist' }},
    { position_id: 'RT', route_points: [{x:31,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Anchor' }},
    { position_id: 'QB', route_points: [{x:25,y:5}], route_details: { alignment: 'off', steps: '5-step drop', landmark: 'Pocket', read_key: 'CB/Flat', coaching_point: 'CB sits = Corner, CB bails = Hitch' }},
    { position_id: 'RB', route_points: [{x:22,y:5},{x:15,y:8}], route_details: { alignment: 'off', steps: 'Check release, swing', landmark: 'Flat', read_key: 'Blitz', coaching_point: 'Block first, checkdown' }}
  ]},
  'Curl Flat': { category: 'Passing', formation: 'Spread', description: 'High-low on flat defender', positions: [
    // Outside receivers run curls at 12
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:22},{x:3,y:20}], route_details: { alignment: 'on', steps: 'Curl at 12', landmark: '12 yards', read_key: 'LB', coaching_point: 'Stem outside, curl back inside' }},
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:45,y:22},{x:47,y:20}], route_details: { alignment: 'on', steps: 'Curl at 12', landmark: '12 yards', read_key: 'LB', coaching_point: 'Find hole in zone' }},
    // Slot/TE run flats underneath
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:5,y:12}], route_details: { alignment: 'off', steps: 'Flat', landmark: 'Numbers', read_key: 'OLB', coaching_point: 'Get width fast' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:43,y:13}], route_details: { alignment: 'on', steps: 'Flat', landmark: 'Numbers', read_key: 'Flat', coaching_point: 'Stretch horizontally' }},
    { position_id: 'LT', route_points: [{x:19,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Quick set' }},
    { position_id: 'LG', route_points: [{x:22,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gap', read_key: 'DT', coaching_point: 'Help C' }},
    { position_id: 'C', route_points: [{x:25,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gaps', read_key: 'Nose', coaching_point: 'Eyes up for stunts' }},
    { position_id: 'RG', route_points: [{x:28,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gap', read_key: 'DT', coaching_point: 'Combo' }},
    { position_id: 'RT', route_points: [{x:31,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Mirror' }},
    { position_id: 'QB', route_points: [{x:25,y:5}], route_details: { alignment: 'off', steps: '3-step drop', landmark: '5 yards', read_key: 'Flat defender', coaching_point: 'Flat drops = Curl, Flat sits = Flat' }},
    { position_id: 'RB', route_points: [{x:25,y:3}], route_details: { alignment: 'off', steps: 'Block', landmark: 'Backfield', read_key: 'Blitz', coaching_point: 'Scan protect' }}
  ]},
  'Mesh': { category: 'Passing', formation: 'Shotgun', description: 'Crossing routes - pick play', positions: [
    // Mesh routes cross at 5-6 yards
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:8,y:10},{x:8,y:15},{x:40,y:15}], route_details: { alignment: 'on', steps: 'Shallow cross', landmark: 'Across field', read_key: 'LBs', coaching_point: 'Run under the other mesh, find window' }},
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:42,y:10},{x:42,y:16},{x:10,y:16}], route_details: { alignment: 'on', steps: 'Shallow cross', landmark: 'Across field', read_key: 'LBs', coaching_point: 'Run over other mesh, settle vs zone' }},
    // Verticals to clear out
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:15,y:30}], route_details: { alignment: 'off', steps: 'Vertical/Seam', landmark: 'Deep', read_key: 'Safety', coaching_point: 'Clear out, take top off' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:38,y:25}], route_details: { alignment: 'on', steps: 'Corner', landmark: 'Sideline', read_key: 'Flat', coaching_point: 'Stretch D, option if uncovered' }},
    { position_id: 'LT', route_points: [{x:19,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Quick game' }},
    { position_id: 'LG', route_points: [{x:22,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gap', read_key: 'DT', coaching_point: 'Punch' }},
    { position_id: 'C', route_points: [{x:25,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gaps', read_key: 'Mike', coaching_point: 'Eyes up' }},
    { position_id: 'RG', route_points: [{x:28,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gap', read_key: 'DT', coaching_point: 'Ready twist' }},
    { position_id: 'RT', route_points: [{x:31,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Mirror' }},
    { position_id: 'QB', route_points: [{x:25,y:5}], route_details: { alignment: 'off', steps: 'Read mesh point', landmark: 'Pocket', read_key: 'Mike', coaching_point: 'Mike drops = under mesh, Mike sits = over mesh' }},
    { position_id: 'RB', route_points: [{x:20,y:5},{x:8,y:8}], route_details: { alignment: 'off', steps: 'Swing', landmark: 'Flat', read_key: 'Blitz', coaching_point: 'Checkdown, get outside' }}
  ]},
  'Four Verts': { category: 'Passing', formation: 'Spread', description: '4 verticals - stretch safety', positions: [
    // All 4 receivers go vertical
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:35}], route_details: { alignment: 'on', steps: 'Go', landmark: 'Deep third', read_key: 'CB', coaching_point: 'Win outside, stack and track' }},
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:45,y:35}], route_details: { alignment: 'on', steps: 'Go', landmark: 'Deep third', read_key: 'CB', coaching_point: 'Win outside, locate ball' }},
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:20,y:35}], route_details: { alignment: 'off', steps: 'Seam', landmark: 'Hash', read_key: 'Safety', coaching_point: 'Bend to open grass vs Cover 2' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:30,y:35}], route_details: { alignment: 'on', steps: 'Seam', landmark: 'Hash', read_key: 'Safety', coaching_point: 'Split safeties, sit vs Cover 2' }},
    { position_id: 'LT', route_points: [{x:19,y:10}], route_details: { alignment: 'on', steps: 'Max pro', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Buy time' }},
    { position_id: 'LG', route_points: [{x:22,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gap', read_key: 'DT', coaching_point: 'No inside pressure' }},
    { position_id: 'C', route_points: [{x:25,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gaps', read_key: 'Mike', coaching_point: 'Anchor' }},
    { position_id: 'RG', route_points: [{x:28,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gap', read_key: 'DT', coaching_point: 'Handle twists' }},
    { position_id: 'RT', route_points: [{x:31,y:10}], route_details: { alignment: 'on', steps: 'Max pro', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Patient' }},
    { position_id: 'QB', route_points: [{x:25,y:5}], route_details: { alignment: 'off', steps: '5-step hitch', landmark: '8 yards', read_key: 'Safety', coaching_point: '1 high = seams, 2 high = outside Go' }},
    { position_id: 'RB', route_points: [{x:25,y:3}], route_details: { alignment: 'off', steps: 'Block', landmark: 'Backfield', read_key: 'Free rusher', coaching_point: '6th blocker' }}
  ]},
  'Slant Flat': { category: 'Passing', formation: 'Spread', description: 'Quick game - Slants + Flats', positions: [
    // Slants: 3 steps up, break 45° inside
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:13},{x:12,y:18}], route_details: { alignment: 'on', steps: 'Slant', landmark: 'Inside', read_key: 'LB', coaching_point: '3 steps, break 45° inside' }},
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:45,y:13},{x:38,y:18}], route_details: { alignment: 'on', steps: 'Slant', landmark: 'Inside', read_key: 'LB', coaching_point: 'Win inside release' }},
    // Flats: immediate outside release
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:5,y:12}], route_details: { alignment: 'off', steps: 'Flat', landmark: 'Sideline', read_key: 'Flat D', coaching_point: 'Width immediately' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:43,y:13}], route_details: { alignment: 'on', steps: 'Flat', landmark: 'Sideline', read_key: 'Flat D', coaching_point: 'Get outside fast' }},
    { position_id: 'LT', route_points: [{x:19,y:10}], route_details: { alignment: 'on', steps: 'Quick set', landmark: 'B gap', read_key: 'DE', coaching_point: 'Fast hands' }},
    { position_id: 'LG', route_points: [{x:22,y:10}], route_details: { alignment: 'on', steps: 'Quick set', landmark: 'A gap', read_key: 'DT', coaching_point: 'Punch' }},
    { position_id: 'C', route_points: [{x:25,y:10}], route_details: { alignment: 'on', steps: 'Quick set', landmark: 'A gaps', read_key: 'Nose', coaching_point: 'Fast' }},
    { position_id: 'RG', route_points: [{x:28,y:10}], route_details: { alignment: 'on', steps: 'Quick set', landmark: 'A gap', read_key: 'DT', coaching_point: 'Ready' }},
    { position_id: 'RT', route_points: [{x:31,y:10}], route_details: { alignment: 'on', steps: 'Quick set', landmark: 'B gap', read_key: 'DE', coaching_point: 'Quick pass' }},
    { position_id: 'QB', route_points: [{x:25,y:5}], route_details: { alignment: 'off', steps: '1-step, throw', landmark: 'Gun', read_key: 'Flat D', coaching_point: 'Flat sits = Slant, Flat widens = Flat' }},
    { position_id: 'RB', route_points: [{x:22,y:5},{x:18,y:5},{x:12,y:10}], route_details: { alignment: 'off', steps: 'Check, angle', landmark: 'Weak flat', read_key: 'Blitz', coaching_point: 'Block first' }}
  ]},
  'Levels': { category: 'Passing', formation: 'Spread', description: 'Flood concept - 3 levels', positions: [
    // Deep crosser at 15
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:20},{x:5,y:25},{x:25,y:25}], route_details: { alignment: 'on', steps: 'Dig at 15', landmark: 'Far hash', read_key: 'Safety', coaching_point: 'Stem vertical, break across' }},
    // Intermediate in at 10
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:45,y:20},{x:30,y:20}], route_details: { alignment: 'on', steps: 'In at 10', landmark: 'Middle', read_key: 'Mike', coaching_point: 'Sit in zone, run vs man' }},
    // Shallow drag at 3-5
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:15,y:13},{x:35,y:14}], route_details: { alignment: 'off', steps: 'Shallow drag', landmark: 'Across', read_key: 'LBs', coaching_point: 'Under LBs, find window' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:33,y:30}], route_details: { alignment: 'on', steps: 'Seam', landmark: 'Hash', read_key: 'Safety', coaching_point: 'Occupy safety' }},
    { position_id: 'LT', route_points: [{x:19,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Set depth' }},
    { position_id: 'LG', route_points: [{x:22,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gap', read_key: 'DT', coaching_point: 'Inside out' }},
    { position_id: 'C', route_points: [{x:25,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gaps', read_key: 'Nose', coaching_point: 'Anchor' }},
    { position_id: 'RG', route_points: [{x:28,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'A gap', read_key: 'DT', coaching_point: 'Eyes up' }},
    { position_id: 'RT', route_points: [{x:31,y:10}], route_details: { alignment: 'on', steps: 'Pass pro', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Patient' }},
    { position_id: 'QB', route_points: [{x:25,y:5}], route_details: { alignment: 'off', steps: '5-step', landmark: 'Pocket', read_key: 'LBs', coaching_point: 'Low-Mid-High read' }},
    { position_id: 'RB', route_points: [{x:22,y:5},{x:32,y:8}], route_details: { alignment: 'off', steps: 'Check, swing', landmark: 'Flat', read_key: 'Blitz', coaching_point: 'Checkdown' }}
  ]},
  // RUN PLAYS
  'Inside Zone': { category: 'Run', formation: 'Shotgun', description: 'Zone blocking - read backside DE', positions: [
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:15}], route_details: { alignment: 'on', steps: 'Stalk block CB', landmark: 'CB', read_key: 'Corner', coaching_point: 'Inside position, sustain' }},
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:45,y:15}], route_details: { alignment: 'on', steps: 'Stalk block CB', landmark: 'CB', read_key: 'Corner', coaching_point: 'Cut off pursuit' }},
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:20,y:15}], route_details: { alignment: 'off', steps: 'Crack safety', landmark: 'Safety', read_key: 'SS', coaching_point: 'Big on big' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:36,y:15}], route_details: { alignment: 'on', steps: 'Base/Reach DE', landmark: 'C gap', read_key: 'DE', coaching_point: 'Covered = base, uncovered = climb' }},
    // OL Zone steps - all aiming playside
    { position_id: 'LT', route_points: [{x:19,y:10},{x:21,y:15}], route_details: { alignment: 'on', steps: 'Zone combo', landmark: 'B gap', read_key: 'DT to LB', coaching_point: 'Double to 2nd level' }},
    { position_id: 'LG', route_points: [{x:22,y:10},{x:24,y:15}], route_details: { alignment: 'on', steps: 'Zone combo', landmark: 'A gap', read_key: 'Nose to Mike', coaching_point: 'Movement then climb' }},
    { position_id: 'C', route_points: [{x:25,y:10},{x:27,y:15}], route_details: { alignment: 'on', steps: 'Zone playside', landmark: 'Playside A', read_key: 'Nose', coaching_point: 'Covered = block, uncovered = climb' }},
    { position_id: 'RG', route_points: [{x:28,y:10},{x:30,y:15}], route_details: { alignment: 'on', steps: 'Zone combo', landmark: 'B gap', read_key: 'DT to LB', coaching_point: 'Combo to Sam' }},
    { position_id: 'RT', route_points: [{x:31,y:10},{x:33,y:15}], route_details: { alignment: 'on', steps: 'Zone reach', landmark: 'C gap', read_key: 'DE', coaching_point: 'Cutoff backside' }},
    { position_id: 'QB', route_points: [{x:25,y:5},{x:28,y:8}], route_details: { alignment: 'off', steps: 'Mesh, read backside DE', landmark: 'Mesh point', read_key: 'Backside DE', coaching_point: 'DE crashes = keep, DE sits = give' }},
    { position_id: 'RB', route_points: [{x:22,y:5},{x:25,y:8},{x:28,y:15}], route_details: { alignment: 'off', steps: 'Aiming point, one cut', landmark: 'Playside A/B', read_key: 'First down block', coaching_point: 'Press hole, one cut, go!' }}
  ]},
  'Outside Zone': { category: 'Run', formation: 'Shotgun', description: 'Stretch play - reach and run', positions: [
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:15}], route_details: { alignment: 'on', steps: 'Stalk', landmark: 'CB', read_key: 'Corner', coaching_point: 'Outside leverage' }},
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:38,y:15}], route_details: { alignment: 'on', steps: 'Crack safety', landmark: 'Force player', read_key: 'SS', coaching_point: 'Seal inside' }},
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:15,y:15}], route_details: { alignment: 'off', steps: 'Stalk', landmark: 'Nickel', read_key: 'DB', coaching_point: 'Sustain' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:40,y:14}], route_details: { alignment: 'on', steps: 'Reach DE', landmark: 'Edge', read_key: 'DE', coaching_point: 'Get outside shoulder' }},
    // OL all reaching playside
    { position_id: 'LT', route_points: [{x:19,y:10},{x:24,y:14}], route_details: { alignment: 'on', steps: 'Zone reach', landmark: 'Playside', read_key: 'DT', coaching_point: 'Overtake' }},
    { position_id: 'LG', route_points: [{x:22,y:10},{x:27,y:14}], route_details: { alignment: 'on', steps: 'Zone reach', landmark: 'Playside', read_key: 'Nose', coaching_point: 'Head across' }},
    { position_id: 'C', route_points: [{x:25,y:10},{x:30,y:14}], route_details: { alignment: 'on', steps: 'Reach playside', landmark: 'Playside', read_key: 'Back DT', coaching_point: 'Scramble block' }},
    { position_id: 'RG', route_points: [{x:28,y:10},{x:33,y:14}], route_details: { alignment: 'on', steps: 'Reach climb', landmark: 'LB', read_key: 'DT to LB', coaching_point: '2nd level' }},
    { position_id: 'RT', route_points: [{x:31,y:10},{x:38,y:14}], route_details: { alignment: 'on', steps: 'Reach', landmark: 'DE', read_key: 'DE', coaching_point: 'Log or reach' }},
    { position_id: 'QB', route_points: [{x:25,y:5},{x:32,y:8}], route_details: { alignment: 'off', steps: 'Open, ride mesh', landmark: 'Mesh point', read_key: 'DE', coaching_point: 'Read the give' }},
    { position_id: 'RB', route_points: [{x:22,y:5},{x:30,y:8},{x:42,y:14}], route_details: { alignment: 'off', steps: 'Stretch, cut up', landmark: 'Edge', read_key: 'TE block', coaching_point: 'Aim sideline, cut when you see it' }}
  ]},
  'Power': { category: 'Run', formation: 'I-Formation', description: 'Gap scheme - FB kick, G pull', positions: [
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:15}], route_details: { alignment: 'on', steps: 'Stalk CB', landmark: 'CB', read_key: 'Corner', coaching_point: 'Sustain block' }},
    { position_id: 'WR_Z', route_points: [{x:45,y:9},{x:38,y:15}], route_details: { alignment: 'off', steps: 'Crack safety', landmark: 'Safety', read_key: 'SS', coaching_point: 'Big block' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:33,y:14}], route_details: { alignment: 'on', steps: 'Down block DE', landmark: 'DE', read_key: 'DE', coaching_point: 'Seal inside, create B gap' }},
    // Backside guard pulls
    { position_id: 'LT', route_points: [{x:19,y:10},{x:32,y:18}], route_details: { alignment: 'on', steps: 'Pull, lead through', landmark: 'B gap', read_key: 'LB', coaching_point: 'Pull flat, turn up in hole' }},
    { position_id: 'LG', route_points: [{x:22,y:10},{x:22,y:14}], route_details: { alignment: 'on', steps: 'Hinge backside', landmark: 'Backside A', read_key: 'DT', coaching_point: 'Protect backside' }},
    { position_id: 'C', route_points: [{x:25,y:10},{x:25,y:15}], route_details: { alignment: 'on', steps: 'Back block', landmark: 'Backside', read_key: 'Nose', coaching_point: 'Reach backside' }},
    { position_id: 'RG', route_points: [{x:28,y:10},{x:30,y:15}], route_details: { alignment: 'on', steps: 'Double to Mike', landmark: 'A gap', read_key: 'DT to Mike', coaching_point: 'Drive DT, climb to Mike' }},
    { position_id: 'RT', route_points: [{x:31,y:10},{x:33,y:15}], route_details: { alignment: 'on', steps: 'Double w/ RG', landmark: 'B gap', read_key: 'DT', coaching_point: 'Movement' }},
    { position_id: 'QB', route_points: [{x:25,y:5},{x:28,y:8}], route_details: { alignment: 'off', steps: 'Open, handoff, fake boot', landmark: 'Mesh', read_key: 'Give', coaching_point: 'Sell the boot fake' }},
    { position_id: 'FB', route_points: [{x:25,y:2},{x:33,y:12}], route_details: { alignment: 'off', steps: 'Kick out EMOL', landmark: 'B gap', read_key: 'Force', coaching_point: 'Kick out or log' }},
    { position_id: 'RB', route_points: [{x:25,y:0},{x:25,y:5},{x:32,y:16}], route_details: { alignment: 'off', steps: 'Patience, follow puller', landmark: 'B gap', read_key: 'FB block', coaching_point: 'Read FB kick, cut off his block' }}
  ]},
  'Counter': { category: 'Run', formation: 'Shotgun', description: 'Misdirection - G/T pull', positions: [
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:15}], route_details: { alignment: 'on', steps: 'Stalk', landmark: 'CB', read_key: 'Corner', coaching_point: 'Sustain' }},
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:38,y:15}], route_details: { alignment: 'on', steps: 'Crack safety', landmark: 'SS', read_key: 'Safety', coaching_point: 'Seal inside' }},
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:15,y:15}], route_details: { alignment: 'off', steps: 'Stalk', landmark: 'Slot D', read_key: 'Nickel', coaching_point: 'Sustain' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:33,y:14}], route_details: { alignment: 'on', steps: 'Down DE', landmark: 'DE', read_key: 'DE', coaching_point: 'Kick or log' }},
    // Backside linemen hinge, playside pull
    { position_id: 'LT', route_points: [{x:19,y:10},{x:18,y:13}], route_details: { alignment: 'on', steps: 'Hinge', landmark: 'Backside', read_key: 'Back DE', coaching_point: 'Cut off' }},
    { position_id: 'LG', route_points: [{x:22,y:10},{x:21,y:13}], route_details: { alignment: 'on', steps: 'Hinge', landmark: 'Back A', read_key: 'DT', coaching_point: 'Wall off' }},
    { position_id: 'C', route_points: [{x:25,y:10},{x:27,y:14}], route_details: { alignment: 'on', steps: 'Block back', landmark: 'Back A', read_key: 'Nose', coaching_point: 'Reach backside' }},
    { position_id: 'RG', route_points: [{x:28,y:10},{x:36,y:14}], route_details: { alignment: 'on', steps: 'Pull, kick out', landmark: 'EMOL', read_key: 'Force', coaching_point: 'Kick out force player' }},
    { position_id: 'RT', route_points: [{x:31,y:10},{x:35,y:18}], route_details: { alignment: 'on', steps: 'Pull, lead', landmark: 'LB', read_key: 'Mike', coaching_point: 'Lead through hole' }},
    { position_id: 'QB', route_points: [{x:25,y:5},{x:22,y:6}], route_details: { alignment: 'off', steps: 'Fake weak, give strong', landmark: 'Mesh', read_key: 'Give', coaching_point: 'Sell the fake!' }},
    { position_id: 'RB', route_points: [{x:22,y:5},{x:18,y:6},{x:35,y:16}], route_details: { alignment: 'off', steps: 'Jab step, counter, follow pullers', landmark: 'B gap', read_key: 'Pullers', coaching_point: 'Patience - wait for pullers!' }}
  ]},
  'Trap': { category: 'Run', formation: 'I-Formation', description: 'Trap the DT', positions: [
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:15}], route_details: { alignment: 'on', steps: 'Stalk', landmark: 'CB', read_key: 'Corner', coaching_point: 'Sustain' }},
    { position_id: 'WR_Z', route_points: [{x:45,y:9},{x:45,y:15}], route_details: { alignment: 'off', steps: 'Stalk', landmark: 'CB', read_key: 'Corner', coaching_point: 'Cut off pursuit' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:36,y:15}], route_details: { alignment: 'on', steps: 'Block Sam', landmark: 'C gap', read_key: 'Sam', coaching_point: 'Seal edge' }},
    { position_id: 'LT', route_points: [{x:19,y:10},{x:18,y:14}], route_details: { alignment: 'on', steps: 'Zone away', landmark: 'Backside', read_key: 'DE', coaching_point: 'Cut off' }},
    // Guard pulls to trap
    { position_id: 'LG', route_points: [{x:22,y:10},{x:28,y:14}], route_details: { alignment: 'on', steps: 'Pull, trap 3-tech', landmark: 'A gap', read_key: 'DT', coaching_point: 'Trap kick the DT' }},
    { position_id: 'C', route_points: [{x:25,y:10},{x:27,y:16}], route_details: { alignment: 'on', steps: 'Block playside LB', landmark: 'Mike', read_key: 'Mike', coaching_point: 'Climb fast' }},
    { position_id: 'RG', route_points: [{x:28,y:10},{x:28,y:14}], route_details: { alignment: 'on', steps: 'Let DT go, block Will', landmark: 'Will', read_key: 'DT', coaching_point: 'Skip pull to LB' }},
    { position_id: 'RT', route_points: [{x:31,y:10},{x:33,y:15}], route_details: { alignment: 'on', steps: 'Base block DE', landmark: 'DE', read_key: 'DE', coaching_point: 'Drive' }},
    { position_id: 'QB', route_points: [{x:25,y:5},{x:26,y:7}], route_details: { alignment: 'off', steps: 'Reverse pivot, hand off', landmark: 'Mesh', read_key: 'Give', coaching_point: 'Quick mesh' }},
    { position_id: 'FB', route_points: [{x:25,y:2},{x:28,y:16}], route_details: { alignment: 'off', steps: 'Lead A gap', landmark: 'A gap', read_key: 'LB', coaching_point: 'Fill for RB' }},
    { position_id: 'RB', route_points: [{x:25,y:0},{x:25,y:5},{x:28,y:18}], route_details: { alignment: 'off', steps: 'Take handoff, follow trap', landmark: 'A gap', read_key: 'Trap block', coaching_point: 'Fast downhill, follow FB' }}
  ]},
  // RPOs
  'RPO Bubble': { category: 'RPO', formation: 'Spread', description: 'Zone read + Bubble screen', positions: [
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:15}], route_details: { alignment: 'on', steps: 'Block for bubble', landmark: 'CB', read_key: 'Corner', coaching_point: 'Stalk, spring the play' }},
    // Bubble route - catch behind LOS
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:40,y:9}], route_details: { alignment: 'on', steps: 'Bubble', landmark: 'Behind LOS', read_key: 'Ball', coaching_point: 'Catch and get upfield!' }},
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:15,y:15}], route_details: { alignment: 'off', steps: 'Block', landmark: 'Nickel', read_key: 'DB', coaching_point: 'Crack or stalk' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:40,y:13}], route_details: { alignment: 'on', steps: 'Block flat D', landmark: 'OLB', read_key: 'OLB', coaching_point: 'Spring the bubble' }},
    { position_id: 'LT', route_points: [{x:19,y:10},{x:21,y:15}], route_details: { alignment: 'on', steps: 'Zone', landmark: 'B gap', read_key: 'DT', coaching_point: 'Combo' }},
    { position_id: 'LG', route_points: [{x:22,y:10},{x:24,y:15}], route_details: { alignment: 'on', steps: 'Zone', landmark: 'A gap', read_key: 'Nose', coaching_point: 'Combo to LB' }},
    { position_id: 'C', route_points: [{x:25,y:10},{x:27,y:15}], route_details: { alignment: 'on', steps: 'Zone', landmark: 'Playside A', read_key: 'Nose', coaching_point: 'Covered rules' }},
    { position_id: 'RG', route_points: [{x:28,y:10},{x:30,y:15}], route_details: { alignment: 'on', steps: 'Zone', landmark: 'B gap', read_key: 'DT', coaching_point: 'Double then climb' }},
    { position_id: 'RT', route_points: [{x:31,y:10},{x:33,y:15}], route_details: { alignment: 'on', steps: 'Zone', landmark: 'C gap', read_key: 'DE', coaching_point: 'Zone reach' }},
    { position_id: 'QB', route_points: [{x:25,y:5},{x:28,y:8}], route_details: { alignment: 'off', steps: 'Mesh, read overhang', landmark: 'Mesh', read_key: 'OLB/Nickel', coaching_point: 'Overhang widens = give, squeezes = bubble' }},
    { position_id: 'RB', route_points: [{x:22,y:5},{x:25,y:8},{x:28,y:15}], route_details: { alignment: 'off', steps: 'Zone path', landmark: 'A/B gap', read_key: 'DE', coaching_point: 'Expect the ball' }}
  ]},
  'RPO Slant': { category: 'RPO', formation: 'Spread', description: 'Zone read + Slant option', positions: [
    // Slant: 3 hard steps, break inside
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:13},{x:12,y:18}], route_details: { alignment: 'on', steps: 'Slant', landmark: 'Inside', read_key: 'LB', coaching_point: 'Win inside, expect ball quick' }},
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:45,y:20}], route_details: { alignment: 'on', steps: 'Go/Clear', landmark: 'Deep', read_key: 'CB', coaching_point: 'Clear out or block' }},
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:15,y:12},{x:22,y:17}], route_details: { alignment: 'off', steps: 'Slant', landmark: 'Middle', read_key: 'Mike', coaching_point: 'Find the hole' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:35,y:15}], route_details: { alignment: 'on', steps: 'Block or seam', landmark: 'DE', read_key: 'DE', coaching_point: 'Covered = block' }},
    { position_id: 'LT', route_points: [{x:19,y:10},{x:21,y:15}], route_details: { alignment: 'on', steps: 'Zone', landmark: 'B gap', read_key: 'DT', coaching_point: 'Combo' }},
    { position_id: 'LG', route_points: [{x:22,y:10},{x:24,y:15}], route_details: { alignment: 'on', steps: 'Zone', landmark: 'A gap', read_key: 'Nose', coaching_point: 'Double' }},
    { position_id: 'C', route_points: [{x:25,y:10},{x:27,y:15}], route_details: { alignment: 'on', steps: 'Zone', landmark: 'A gap', read_key: 'Nose', coaching_point: 'Climb' }},
    { position_id: 'RG', route_points: [{x:28,y:10},{x:30,y:15}], route_details: { alignment: 'on', steps: 'Zone', landmark: 'B gap', read_key: 'DT', coaching_point: 'Combo' }},
    { position_id: 'RT', route_points: [{x:31,y:10},{x:33,y:15}], route_details: { alignment: 'on', steps: 'Zone', landmark: 'C gap', read_key: 'DE', coaching_point: 'Reach' }},
    { position_id: 'QB', route_points: [{x:25,y:5},{x:28,y:8}], route_details: { alignment: 'off', steps: 'Mesh, read Mike', landmark: 'Mesh', read_key: 'Mike', coaching_point: 'Mike flows to run = throw slant' }},
    { position_id: 'RB', route_points: [{x:22,y:5},{x:25,y:8},{x:28,y:15}], route_details: { alignment: 'off', steps: 'Zone path', landmark: 'A gap', read_key: 'Mike', coaching_point: 'Expect ball' }}
  ]},
  // SCREENS
  'Tunnel Screen': { category: 'Screen', formation: 'Spread', description: 'WR screen with blockers', positions: [
    // Screen receiver catches behind blockers
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:10,y:11}], route_details: { alignment: 'on', steps: 'Catch, follow blocks', landmark: 'Behind OL', read_key: 'Ball', coaching_point: 'Catch and go!' }},
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:45,y:30}], route_details: { alignment: 'on', steps: 'Go - clear out', landmark: 'Deep', read_key: 'CB', coaching_point: 'Take CB deep' }},
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:8,y:13}], route_details: { alignment: 'off', steps: 'Block DB', landmark: 'Slot D', read_key: 'Nickel', coaching_point: 'Stalk block' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:33,y:25}], route_details: { alignment: 'on', steps: 'Seam - clear', landmark: 'Seam', read_key: 'Safety', coaching_point: 'Occupy safety' }},
    // OL release to screen side
    { position_id: 'LT', route_points: [{x:19,y:10},{x:8,y:15}], route_details: { alignment: 'on', steps: 'Release, lead', landmark: 'Screen', read_key: 'LB', coaching_point: 'Get in front of WR' }},
    { position_id: 'LG', route_points: [{x:22,y:10},{x:10,y:17}], route_details: { alignment: 'on', steps: 'Release, wall', landmark: 'Screen', read_key: 'DB', coaching_point: 'Wall off pursuit' }},
    { position_id: 'C', route_points: [{x:25,y:10},{x:25,y:12}], route_details: { alignment: 'on', steps: 'Fake pass pro, release', landmark: 'Middle', read_key: 'Mike', coaching_point: 'Sell pass, then go' }},
    { position_id: 'RG', route_points: [{x:28,y:10},{x:28,y:12}], route_details: { alignment: 'on', steps: 'Pass set', landmark: 'Right', read_key: 'DT', coaching_point: 'Sell pass pro' }},
    { position_id: 'RT', route_points: [{x:31,y:10},{x:31,y:12}], route_details: { alignment: 'on', steps: 'Pass block', landmark: 'Edge', read_key: 'DE', coaching_point: 'Protect QB' }},
    { position_id: 'QB', route_points: [{x:25,y:5}], route_details: { alignment: 'off', steps: 'Fake deep, throw screen', landmark: 'Pocket', read_key: 'Screen', coaching_point: 'Look off safety, throw quick' }},
    { position_id: 'RB', route_points: [{x:22,y:5},{x:30,y:8}], route_details: { alignment: 'off', steps: 'Fake run', landmark: 'Backfield', read_key: 'Sell', coaching_point: 'Sell the run fake' }}
  ]},
  'RB Screen': { category: 'Screen', formation: 'Shotgun', description: 'Traditional slip screen', positions: [
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:35}], route_details: { alignment: 'on', steps: 'Go - clear out', landmark: 'Deep', read_key: 'CB', coaching_point: 'Take CB deep' }},
    { position_id: 'WR_Z', route_points: [{x:45,y:10},{x:45,y:35}], route_details: { alignment: 'on', steps: 'Go - clear out', landmark: 'Deep', read_key: 'CB', coaching_point: 'Occupy deep' }},
    { position_id: 'WR_Y', route_points: [{x:15,y:9},{x:15,y:30}], route_details: { alignment: 'off', steps: 'Seam - clear', landmark: 'Seam', read_key: 'Safety', coaching_point: 'Pull safety' }},
    { position_id: 'TE', route_points: [{x:33,y:10},{x:33,y:12},{x:20,y:8}], route_details: { alignment: 'on', steps: 'Chip, release to screen', landmark: 'Screen', read_key: 'DE', coaching_point: 'Chip then lead' }},
    // OL set then release to screen
    { position_id: 'LT', route_points: [{x:19,y:10},{x:12,y:5}], route_details: { alignment: 'on', steps: 'Set, set, release', landmark: 'Screen', read_key: 'LB', coaching_point: 'Lead block' }},
    { position_id: 'LG', route_points: [{x:22,y:10},{x:15,y:3}], route_details: { alignment: 'on', steps: 'Set, set, release', landmark: 'Screen', read_key: 'LB', coaching_point: 'Wall off' }},
    { position_id: 'C', route_points: [{x:25,y:10},{x:18,y:5}], route_details: { alignment: 'on', steps: 'Set, release', landmark: 'Screen', read_key: 'Mike', coaching_point: 'Lead blocker' }},
    { position_id: 'RG', route_points: [{x:28,y:10},{x:28,y:12}], route_details: { alignment: 'on', steps: 'Aggressive pass set', landmark: 'Right', read_key: 'DT', coaching_point: 'Sell pass' }},
    { position_id: 'RT', route_points: [{x:31,y:10},{x:31,y:12}], route_details: { alignment: 'on', steps: 'Pass block', landmark: 'Edge', read_key: 'DE', coaching_point: 'Protect' }},
    { position_id: 'QB', route_points: [{x:25,y:5},{x:28,y:8},{x:20,y:4}], route_details: { alignment: 'off', steps: 'Fake deep, dump to RB', landmark: 'Pocket', read_key: 'Rush', coaching_point: 'Let rush upfield, throw behind' }},
    { position_id: 'RB', route_points: [{x:22,y:5},{x:20,y:5},{x:12,y:3}], route_details: { alignment: 'off', steps: 'Fake pass pro, slip out', landmark: 'Behind OL', read_key: 'Blocks', coaching_point: 'Patience! Follow the wall' }}
  ]},
  // PLAY ACTION
  'PA Boot': { category: 'Play Action', formation: 'I-Formation', description: 'Bootleg off run fake', positions: [
    { position_id: 'WR_X', route_points: [{x:5,y:10},{x:5,y:35}], route_details: { alignment: 'on', steps: 'Go - clear', landmark: 'Deep', read_key: 'CB', coaching_point: 'Clear out the CB' }},
    // Corner route - boot side
    { position_id: 'WR_Z', route_points: [{x:45,y:9},{x:45,y:20},{x:49,y:28}], route_details: { alignment: 'off', steps: 'Corner at 12', landmark: 'Sideline', read_key: 'Safety', coaching_point: 'Primary read - stem then break' }},
    // Drag underneath
    { position_id: 'TE', route_points: [{x:33,y:10},{x:33,y:12},{x:43,y:14}], route_details: { alignment: 'on', steps: 'Flat/Drag', landmark: 'Flat', read_key: 'LB', coaching_point: 'Work to QB vision' }},
    { position_id: 'LT', route_points: [{x:19,y:10},{x:18,y:13}], route_details: { alignment: 'on', steps: 'Hinge - sell run', landmark: 'Backside', read_key: 'DE', coaching_point: 'Sell run block' }},
    { position_id: 'LG', route_points: [{x:22,y:10},{x:21,y:13}], route_details: { alignment: 'on', steps: 'Hinge - sell run', landmark: 'Backside', read_key: 'DT', coaching_point: 'Sell' }},
    { position_id: 'C', route_points: [{x:25,y:10},{x:26,y:14}], route_details: { alignment: 'on', steps: 'Zone fake', landmark: 'A gap', read_key: 'Nose', coaching_point: 'Push then release' }},
    { position_id: 'RG', route_points: [{x:28,y:10},{x:30,y:14}], route_details: { alignment: 'on', steps: 'Zone fake', landmark: 'B gap', read_key: 'DT', coaching_point: 'Sell run' }},
    // RT pulls with boot
    { position_id: 'RT', route_points: [{x:31,y:10},{x:38,y:12}], route_details: { alignment: 'on', steps: 'Pull with QB', landmark: 'Boot side', read_key: 'Edge', coaching_point: 'Lead block for QB' }},
    // QB fakes then boots
    { position_id: 'QB', route_points: [{x:25,y:5},{x:22,y:6},{x:40,y:10}], route_details: { alignment: 'off', steps: 'Fake run, boot out', landmark: 'Edge', read_key: 'Flat D', coaching_point: 'Sell fake, eyes down, boot out' }},
    { position_id: 'FB', route_points: [{x:25,y:2},{x:38,y:8}], route_details: { alignment: 'off', steps: 'Fake, release flat', landmark: 'Flat', read_key: 'LB', coaching_point: 'Checkdown option' }},
    { position_id: 'RB', route_points: [{x:25,y:0},{x:22,y:8}], route_details: { alignment: 'off', steps: 'Fake run - sell it!', landmark: 'Backfield', read_key: 'Fake', coaching_point: 'Great fake = big play!' }}
  ]}
};

// DEFENSIVE PLAY TEMPLATES
const DEFENSIVE_TEMPLATES = {
  'Cover 3 Sky': { category: 'Zone', front: '4-3', coverage: 'Cover 3', description: 'SS force, FS deep middle', positions: [
    { position_id: 'DE_L', position_name: 'Left DE', alignment: '5 tech', responsibility: 'C gap contain', read_key: 'Tackle', coaching_point: 'Squeeze contain' },
    { position_id: 'DT_L', position_name: '3 Tech', alignment: '3 tech', responsibility: 'B gap', read_key: 'Guard', coaching_point: 'Penetrate' },
    { position_id: 'DT_R', position_name: '1 Tech', alignment: '1 tech', responsibility: 'A gap', read_key: 'Center', coaching_point: 'Hold point' },
    { position_id: 'DE_R', position_name: 'Right DE', alignment: '5 tech', responsibility: 'C gap', read_key: 'Tackle', coaching_point: 'Set edge' },
    { position_id: 'SAM', position_name: 'Sam', alignment: 'Apex #2', responsibility: 'Curl to flat', read_key: '#2', coaching_point: 'Collision drop' },
    { position_id: 'MIKE', position_name: 'Mike', alignment: '0 tech', responsibility: 'Hook zone', read_key: 'Guards', coaching_point: 'Wall #3' },
    { position_id: 'WILL', position_name: 'Will', alignment: 'Apex weak', responsibility: 'Curl flat', read_key: '#2', coaching_point: 'Read #2 to #1' },
    { position_id: 'CB_L', position_name: 'Left CB', alignment: '7yd off', responsibility: 'Deep 1/3', read_key: '#1', coaching_point: 'Bail carry' },
    { position_id: 'CB_R', position_name: 'Right CB', alignment: '7yd off', responsibility: 'Deep 1/3', read_key: '#1', coaching_point: 'Pedal read' },
    { position_id: 'SS', position_name: 'Strong S', alignment: 'Box 8yd', responsibility: 'Force curl', read_key: '#2 to run', coaching_point: 'Run support' },
    { position_id: 'FS', position_name: 'Free S', alignment: 'Center 12yd', responsibility: 'Deep mid 1/3', read_key: 'QB', coaching_point: 'Range middle' }
  ]},
  'Cover 2 Shell': { category: 'Zone', front: '4-3', coverage: 'Cover 2', description: '2 deep, 5 under', positions: [
    { position_id: 'DE_L', position_name: 'Left DE', alignment: '6 tech', responsibility: 'Contain', read_key: 'Tackle', coaching_point: 'Squeeze C' },
    { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 tech', responsibility: 'B gap', read_key: 'Guard', coaching_point: 'Penetrate' },
    { position_id: 'DT_R', position_name: 'Right DT', alignment: '1 tech', responsibility: 'A gap', read_key: 'Center', coaching_point: 'Anchor point of attack, dont get moved' },
    { position_id: 'DE_R', position_name: 'Right DE', alignment: '6 tech', responsibility: 'Contain', read_key: 'TE', coaching_point: 'Set edge' },
    { position_id: 'SAM', position_name: 'Sam', alignment: 'Stack', responsibility: 'Hook curl', read_key: '#2', coaching_point: 'Wall expand' },
    { position_id: 'MIKE', position_name: 'Mike', alignment: '0 on C', responsibility: 'Mid hook', read_key: 'Triangle', coaching_point: 'Take away mid' },
    { position_id: 'WILL', position_name: 'Will', alignment: 'Stack weak', responsibility: 'Hook curl', read_key: '#2', coaching_point: 'Match #3' },
    { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Press', responsibility: 'Flat zone', read_key: '#1', coaching_point: 'Jam sink' },
    { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Press', responsibility: 'Flat zone', read_key: '#1', coaching_point: 'Funnel inside' },
    { position_id: 'SS', position_name: 'Strong S', alignment: '12yd deep', responsibility: 'Deep half', read_key: '#2 vert', coaching_point: 'Protect half' },
    { position_id: 'FS', position_name: 'Free S', alignment: '12yd deep', responsibility: 'Deep half', read_key: '#2 vert', coaching_point: 'Stay on top' }
  ]},
  'Cover 1 Press': { category: 'Man', front: '4-3', coverage: 'Cover 1', description: 'Man with single high', positions: [
    { position_id: 'DE_L', position_name: 'Left DE', alignment: '5 tech', responsibility: 'Rush contain', read_key: 'Ball', coaching_point: 'Get to QB' },
    { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 tech', responsibility: 'Pass rush', read_key: 'Ball', coaching_point: 'Attack B gap, get upfield' },
    { position_id: 'DT_R', position_name: 'Right DT', alignment: '1 tech', responsibility: 'A gap rush', read_key: 'Ball', coaching_point: 'Collapse' },
    { position_id: 'DE_R', position_name: 'Right DE', alignment: '5 tech', responsibility: 'Rush contain', read_key: 'Ball', coaching_point: 'Speed to power, win the edge' },
    { position_id: 'SAM', position_name: 'Sam', alignment: 'Over TE', responsibility: 'Man TE', read_key: 'TE', coaching_point: 'Jam run' },
    { position_id: 'MIKE', position_name: 'Mike', alignment: 'Stack', responsibility: 'Man RB', read_key: 'RB', coaching_point: 'Match release' },
    { position_id: 'WILL', position_name: 'Will', alignment: 'Stack weak', responsibility: 'Spy/Man', read_key: 'QB', coaching_point: 'Spy or #3' },
    { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Press inside', responsibility: 'Man #1', read_key: 'Your man', coaching_point: 'Jam stay hip' },
    { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Press inside', responsibility: 'Man #1', read_key: 'Your man', coaching_point: 'Physical trail' },
    { position_id: 'SS', position_name: 'Strong S', alignment: 'Apex', responsibility: 'Man #2/Rob', read_key: '#2', coaching_point: 'Match or rob' },
    { position_id: 'FS', position_name: 'Free S', alignment: 'Center 14yd', responsibility: 'Deep mid', read_key: 'QB', coaching_point: 'Help posts' }
  ]},
  'Nickel Cover 4': { category: 'Zone', front: 'Nickel', coverage: 'Cover 4', description: 'Quarters coverage', positions: [
    { position_id: 'DE_L', position_name: 'DE', alignment: '5 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Contain' },
    { position_id: 'DT_L', position_name: 'Nose', alignment: '1 tech', responsibility: 'A gap', read_key: 'Center', coaching_point: 'Two gap' },
    { position_id: 'DT_R', position_name: '3 Tech', alignment: '3 tech', responsibility: 'B gap', read_key: 'Guard', coaching_point: 'Penetrate' },
    { position_id: 'DE_R', position_name: 'DE', alignment: '5 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Set edge, squeeze runs inside' },
    { position_id: 'MIKE', position_name: 'Mike', alignment: 'Stack', responsibility: 'Hook/#3', read_key: '#3', coaching_point: 'Carry vert' },
    { position_id: 'WILL', position_name: 'Will', alignment: 'Weak stack', responsibility: 'Hook/Curl', read_key: '#2 weak', coaching_point: 'Match' },
    { position_id: 'NB', position_name: 'Nickel', alignment: 'Slot', responsibility: 'Man/Zone #2', read_key: '#2 strong', coaching_point: 'Match routes' },
    { position_id: 'CB_L', position_name: 'Left CB', alignment: '8yd off', responsibility: '1/4 zone', read_key: '#1 to #2', coaching_point: 'MEG tech' },
    { position_id: 'CB_R', position_name: 'Right CB', alignment: '8yd off', responsibility: '1/4 zone', read_key: '#1 to #2', coaching_point: 'Pattern match' },
    { position_id: 'SS', position_name: 'Strong S', alignment: '10yd', responsibility: '1/4 zone', read_key: '#2 vert', coaching_point: 'Match #2' },
    { position_id: 'FS', position_name: 'Free S', alignment: '10yd', responsibility: '1/4 zone', read_key: '#2 vert', coaching_point: 'Help seam' }
  ]},
  'Fire Zone': { category: 'Blitz', front: '4-3', coverage: 'Fire Zone 3', description: '5-man pressure, 3 deep', positions: [
    { position_id: 'DE_L', position_name: 'Left DE', alignment: '5 tech', responsibility: 'Seam drop', read_key: '#2', coaching_point: 'Fake rush drop' },
    { position_id: 'DT_L', position_name: 'DT', alignment: '3 tech', responsibility: 'Rush B', read_key: 'Ball', coaching_point: 'Penetrate' },
    { position_id: 'DT_R', position_name: 'DT', alignment: '3 tech', responsibility: 'Rush B', read_key: 'Ball', coaching_point: 'Collapse' },
    { position_id: 'DE_R', position_name: 'Right DE', alignment: '5 tech', responsibility: 'Contain rush', read_key: 'Ball', coaching_point: 'Speed contain' },
    { position_id: 'SAM', position_name: 'Sam', alignment: 'Edge', responsibility: 'Blitz edge', read_key: 'Ball', coaching_point: 'First to QB' },
    { position_id: 'MIKE', position_name: 'Mike', alignment: 'A gap', responsibility: 'Blitz A', read_key: 'Ball', coaching_point: 'Fire!' },
    { position_id: 'WILL', position_name: 'Will', alignment: 'Flat', responsibility: 'Flat zone', read_key: '#2', coaching_point: 'Replace DE' },
    { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Off', responsibility: 'Deep 1/3', read_key: '#1', coaching_point: 'Bail' },
    { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Off', responsibility: 'Deep 1/3', read_key: '#1', coaching_point: 'No deep!' },
    { position_id: 'SS', position_name: 'Strong S', alignment: 'Flat', responsibility: 'Flat zone', read_key: '#2', coaching_point: 'Rally flat' },
    { position_id: 'FS', position_name: 'Free S', alignment: 'Deep mid', responsibility: 'Deep 1/3', read_key: 'QB', coaching_point: 'Protect mid' }
  ]},
  'Cover 0 Blitz': { category: 'Blitz', front: '4-3', coverage: 'Cover 0', description: 'All out blitz, no safety', positions: [
    { position_id: 'DE_L', position_name: 'Left DE', alignment: 'Wide', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Win!' },
    { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'A gap free' },
    { position_id: 'DT_R', position_name: 'Right DT', alignment: '3 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Collapse' },
    { position_id: 'DE_R', position_name: 'Right DE', alignment: 'Wide', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Get-off, speed rush outside' },
    { position_id: 'SAM', position_name: 'Sam', alignment: 'Edge', responsibility: 'Blitz', read_key: 'Ball', coaching_point: 'Green dog' },
    { position_id: 'MIKE', position_name: 'Mike', alignment: 'A gap', responsibility: 'Blitz A', read_key: 'Ball', coaching_point: 'Be first' },
    { position_id: 'WILL', position_name: 'Will', alignment: 'Edge', responsibility: 'Blitz', read_key: 'Ball', coaching_point: 'Contain if need' },
    { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Press', responsibility: 'Man #1', read_key: '#1', coaching_point: 'NO HELP!' },
    { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Press', responsibility: 'Man #1', read_key: '#1', coaching_point: 'Cant get beat' },
    { position_id: 'SS', position_name: 'Strong S', alignment: 'Man', responsibility: 'Man TE', read_key: 'TE', coaching_point: 'Jam at line, stay in hip pocket' },
    { position_id: 'FS', position_name: 'Free S', alignment: 'Man', responsibility: 'Man RB', read_key: 'RB', coaching_point: 'Match release' }
  ]}
};

const initialPlayers = [
  // Offense
  { player_id: 'p1', name: 'Jake Wilson', jersey: '11', position: 'WR_Z', unit: 'offense', depth: 1 },
  { player_id: 'p2', name: 'Marcus Brown', jersey: '7', position: 'WR_X', unit: 'offense', depth: 1 },
  { player_id: 'p3', name: 'Tyler Johnson', jersey: '22', position: 'RB', unit: 'offense', depth: 1 },
  { player_id: 'p7', name: 'Deon Harris', jersey: '3', position: 'WR_Y', unit: 'offense', depth: 1 },
  { player_id: 'p8', name: 'Mike Peters', jersey: '12', position: 'QB', unit: 'offense', depth: 1 },
  { player_id: 'p9', name: 'Jason Wright', jersey: '88', position: 'TE', unit: 'offense', depth: 1 },
  { player_id: 'p10', name: 'Carlos Martinez', jersey: '72', position: 'LT', unit: 'offense', depth: 1 },
  { player_id: 'p11', name: 'Brandon Cole', jersey: '65', position: 'LG', unit: 'offense', depth: 1 },
  { player_id: 'p12', name: 'Derek Stone', jersey: '55', position: 'C', unit: 'offense', depth: 1 },
  { player_id: 'p13', name: 'Trent Williams', jersey: '68', position: 'RG', unit: 'offense', depth: 1 },
  { player_id: 'p14', name: 'Andre Davis', jersey: '77', position: 'RT', unit: 'offense', depth: 1 },
  // Offense 2nd string
  { player_id: 'p15', name: 'Ryan Moore', jersey: '14', position: 'QB', unit: 'offense', depth: 2 },
  { player_id: 'p16', name: 'Kevin James', jersey: '24', position: 'RB', unit: 'offense', depth: 2 },
  { player_id: 'p17', name: 'Chris Allen', jersey: '81', position: 'WR_Z', unit: 'offense', depth: 2 },
  // Defense
  { player_id: 'p4', name: 'Devon Smith', jersey: '5', position: 'CB_L', unit: 'defense', depth: 1 },
  { player_id: 'p5', name: 'Jordan Lee', jersey: '42', position: 'MIKE', unit: 'defense', depth: 1 },
  { player_id: 'p6', name: 'Chris Thompson', jersey: '99', position: 'DE_R', unit: 'defense', depth: 1 },
  { player_id: 'p18', name: 'Malik Jackson', jersey: '91', position: 'DE_L', unit: 'defense', depth: 1 },
  { player_id: 'p19', name: 'DeShawn Brown', jersey: '95', position: 'DT_L', unit: 'defense', depth: 1 },
  { player_id: 'p20', name: 'Jamal Carter', jersey: '97', position: 'DT_R', unit: 'defense', depth: 1 },
  { player_id: 'p21', name: 'Tyrell Adams', jersey: '54', position: 'SAM', unit: 'defense', depth: 1 },
  { player_id: 'p22', name: 'Marcus Hall', jersey: '51', position: 'WILL', unit: 'defense', depth: 1 },
  { player_id: 'p23', name: 'Darius Mitchell', jersey: '21', position: 'CB_R', unit: 'defense', depth: 1 },
  { player_id: 'p24', name: 'Terrance King', jersey: '32', position: 'SS', unit: 'defense', depth: 1 },
  { player_id: 'p25', name: 'Isaiah Ford', jersey: '29', position: 'FS', unit: 'defense', depth: 1 },
  // Defense 2nd string
  { player_id: 'p26', name: 'Corey White', jersey: '44', position: 'MIKE', unit: 'defense', depth: 2 },
  { player_id: 'p27', name: 'Jaylen Brooks', jersey: '23', position: 'CB_L', unit: 'defense', depth: 2 }
];

export default function ZunoApp() {
  // ============== ALL STATE DECLARATIONS (must be at top) ==============
  const [authState, setAuthState] = useState('login'); // 'login', 'register', 'authenticated'
  const [currentUser, setCurrentUser] = useState(null);
  const [authError, setAuthError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [userRole, setUserRole] = useState('coach');
  const [currentView, setCurrentView] = useState('plays');
  const [unit, setUnit] = useState('offense');
  const [playerStudyPlay, setPlayerStudyPlay] = useState(null);
  
  // Demo users database (in production, this would be your backend)
  const [users, setUsers] = useState([
    { 
      id: 'user_1', 
      email: 'coach@lincoln.edu', 
      password: 'demo123', 
      name: 'Coach Johnson',
      role: 'coach',
      team: 'Lincoln High School',
      subscription: 'pro',
      subscriptionExpires: '2025-12-31'
    },
    { 
      id: 'user_2', 
      email: 'jake@lincoln.edu', 
      password: 'player123', 
      name: 'Jake Wilson',
      role: 'player',
      team: 'Lincoln High School',
      playerId: 'p1',
      subscription: 'free'
    }
  ]);

  // Plays data
  const [plays, setPlays] = useState([
    {
      play_id: 'play_1',
      name: 'Z Post',
      formation: 'Spread',
      snap_count: 'On 1',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'WR_Z', position_name: 'WR_Z', route_points: [{ x: 45, y: 10 }, { x: 45, y: 20 }, { x: 35, y: 30 }], tags: [], motion: 'none', route_details: { steps: '1. Release outside\n2. Vertical 15 yards\n3. Post cut at top of route', landmark: 'Hash marks at 15 yards', read_key: 'Safety rotation', coaching_point: 'Sell the go route before breaking post' } },
        { position_id: 'WR_X', position_name: 'WR_X', route_points: [{ x: 5, y: 10 }, { x: 5, y: 25 }], tags: [], motion: 'none', route_details: { steps: '1. Release inside\n2. Vertical to 25 yards', landmark: 'Numbers', read_key: 'Corner depth', coaching_point: 'Stack the corner, create separation at top' } },
        { position_id: 'WR_Y', position_name: 'Slot WR', route_points: [{ x: 15, y: 9 }, { x: 20, y: 15 }], tags: [], motion: 'none', route_details: { steps: '1. Release inside\n2. Sit in hole at 6 yards', landmark: 'Between hash and numbers', read_key: 'Linebacker drop', coaching_point: 'Find the soft spot in zone' } },
        { position_id: 'TE', position_name: 'Tight End', route_points: [{ x: 35, y: 9 }, { x: 40, y: 18 }], tags: [], motion: 'none', route_details: { steps: '1. Release vertical\n2. Corner route at 15', landmark: 'Sideline at 15 yards', read_key: 'Flat defender', coaching_point: 'Sell vertical before breaking out' } },
        { position_id: 'LT', position_name: 'Left Tackle', route_points: [{ x: 19, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass set - kick slide', landmark: 'Protect B gap', read_key: 'Edge rusher', coaching_point: 'Anchor vs bull rush' } },
        { position_id: 'LG', position_name: 'Left Guard', route_points: [{ x: 22, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass set - inside out', landmark: 'Protect A gap', read_key: 'DT and LB', coaching_point: 'Help center then work to backer' } },
        { position_id: 'C', position_name: 'Center', route_points: [{ x: 25, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass set', landmark: 'Protect A gaps', read_key: 'Nose and Mike', coaching_point: 'ID the Mike pre-snap' } },
        { position_id: 'RG', position_name: 'Right Guard', route_points: [{ x: 28, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass set - inside out', landmark: 'Protect A gap', read_key: 'DT and LB', coaching_point: 'Combo to backer if uncovered' } },
        { position_id: 'RT', position_name: 'Right Tackle', route_points: [{ x: 31, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass set - kick slide', landmark: 'Protect B gap', read_key: 'Edge rusher', coaching_point: 'Set depth, patient hands' } },
        { position_id: 'QB', position_name: 'Quarterback', route_points: [{ x: 25, y: 3 }, { x: 25, y: 5 }], tags: [], motion: 'none', route_details: { steps: '1. 5-step drop\n2. Hitch up\n3. Throw', landmark: '7 yards depth', read_key: 'Post-safety read', coaching_point: 'Read high to low - post first, check down last' } },
        { position_id: 'RB', position_name: 'Running Back', route_points: [{ x: 25, y: 0 }, { x: 30, y: 15 }], tags: [], motion: 'none', route_details: { steps: '1. Check protection\n2. Release to flat', landmark: 'Outside numbers', read_key: 'Blitz first', coaching_point: 'Be the hot route vs pressure' } }
      ]
    },
    {
      play_id: 'play_2',
      name: 'Power Right',
      formation: 'I-Formation',
      snap_count: 'On 2',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'WR_X', position_name: 'Split End', route_points: [{ x: 5, y: 10 }, { x: 5, y: 20 }], tags: [], motion: 'none', route_details: { steps: '1. Release vertical\n2. Stalk block corner', landmark: 'Numbers', read_key: 'Corner technique', coaching_point: 'Get to his outside shoulder' } },
        { position_id: 'WR_Z', position_name: 'Flanker', route_points: [{ x: 45, y: 9 }, { x: 40, y: 15 }], tags: [], motion: 'none', route_details: { steps: '1. Crack down on safety\n2. Work to second level', landmark: 'Hash marks', read_key: 'Safety', coaching_point: 'Big block - spring the big play' } },
        { position_id: 'TE', position_name: 'Tight End', route_points: [{ x: 33, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Down block on DE', landmark: 'Inside gap', read_key: 'DE technique', coaching_point: 'Seal the edge, create the hole' } },
        { position_id: 'LT', position_name: 'Left Tackle', route_points: [{ x: 19, y: 10 }, { x: 28, y: 15 }], tags: [], motion: 'none', route_details: { steps: 'Pull and lead through hole', landmark: 'Playside B gap', read_key: 'First color', coaching_point: 'Pull flat, eyes up, find work' } },
        { position_id: 'LG', position_name: 'Left Guard', route_points: [{ x: 22, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Down block - reach DT', landmark: 'Backside A gap', read_key: 'DT shade', coaching_point: 'Cut off backside pursuit' } },
        { position_id: 'C', position_name: 'Center', route_points: [{ x: 25, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Block back on backside', landmark: 'Backside A gap', read_key: 'Nose technique', coaching_point: 'Reach and seal nose' } },
        { position_id: 'RG', position_name: 'Right Guard', route_points: [{ x: 28, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Double team to Mike', landmark: 'Playside A gap', read_key: 'DT to Mike', coaching_point: 'Vertical push then climb' } },
        { position_id: 'RT', position_name: 'Right Tackle', route_points: [{ x: 31, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Double team with RG', landmark: 'Playside B gap', read_key: 'DE', coaching_point: 'Combo to second level' } },
        { position_id: 'QB', position_name: 'Quarterback', route_points: [{ x: 25, y: 5 }, { x: 28, y: 8 }], tags: [], motion: 'none', route_details: { steps: '1. Open to playside\n2. Hand off\n3. Boot fake', landmark: 'Mesh point at 4 yards', read_key: 'Backside DE', coaching_point: 'Sell the fake after handoff' } },
        { position_id: 'FB', position_name: 'Fullback', route_points: [{ x: 25, y: 2 }, { x: 32, y: 12 }], tags: [], motion: 'none', route_details: { steps: '1. Lead through B gap\n2. Kick out force', landmark: 'Outside hip of TE', read_key: 'Force defender', coaching_point: 'Eyes inside out, kick out or log' } },
        { position_id: 'RB', position_name: 'Running Back', route_points: [{ x: 25, y: 0 }, { x: 32, y: 15 }], tags: [], motion: 'none', route_details: { steps: '1. Patient steps\n2. Press the hole\n3. One cut upfield', landmark: 'FB\'s outside hip', read_key: 'Pulling guard', coaching_point: 'Let blocks develop, be decisive' } }
      ]
    },
    {
      play_id: 'play_3',
      name: 'Mesh Concept',
      formation: 'Shotgun',
      snap_count: 'On 1',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'WR_X', position_name: 'X Receiver', route_points: [{ x: 5, y: 10 }, { x: 8, y: 11 }, { x: 30, y: 11 }], tags: [], motion: 'none', route_details: { steps: '1. Inside release\n2. Shallow cross at 5 yards\n3. Run to open grass', landmark: '5-6 yards depth', read_key: 'Linebackers', coaching_point: 'Run under the other mesh route' } },
        { position_id: 'WR_Z', position_name: 'Z Receiver', route_points: [{ x: 45, y: 10 }, { x: 42, y: 12 }, { x: 20, y: 12 }], tags: [], motion: 'none', route_details: { steps: '1. Inside release\n2. Shallow cross at 6 yards\n3. Settle vs zone, run vs man', landmark: '6 yards depth', read_key: 'Linebackers', coaching_point: 'Run over the other mesh route' } },
        { position_id: 'WR_Y', position_name: 'Slot', route_points: [{ x: 15, y: 9 }, { x: 15, y: 25 }], tags: [], motion: 'none', route_details: { steps: '1. Vertical release\n2. Clear out the corner', landmark: 'Deep third', read_key: 'Corner', coaching_point: 'Take the top off' } },
        { position_id: 'TE', position_name: 'Tight End', route_points: [{ x: 33, y: 10 }, { x: 35, y: 22 }], tags: [], motion: 'none', route_details: { steps: '1. Release outside\n2. Corner route at 15', landmark: 'Sideline at 15+', read_key: 'Flat defender', coaching_point: 'Stretch the defense horizontally' } },
        { position_id: 'LT', position_name: 'Left Tackle', route_points: [{ x: 19, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass protection', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Quick pass - be aggressive' } },
        { position_id: 'LG', position_name: 'Left Guard', route_points: [{ x: 22, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass protection', landmark: 'A gap', read_key: 'DT/LB', coaching_point: 'Quick set, punch first' } },
        { position_id: 'C', position_name: 'Center', route_points: [{ x: 25, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass protection', landmark: 'A gaps', read_key: 'Mike', coaching_point: 'Handle nose, eyes on Mike' } },
        { position_id: 'RG', position_name: 'Right Guard', route_points: [{ x: 28, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass protection', landmark: 'A gap', read_key: 'DT/LB', coaching_point: 'Be ready for twist' } },
        { position_id: 'RT', position_name: 'Right Tackle', route_points: [{ x: 31, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass protection', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Mirror the rusher' } },
        { position_id: 'QB', position_name: 'Quarterback', route_points: [{ x: 25, y: 5 }], tags: [], motion: 'none', route_details: { steps: '1. Catch snap\n2. Read mesh point\n3. Throw to open crosser', landmark: 'Stay in pocket', read_key: 'Mike LB', coaching_point: 'If Mike drops = throw under, if Mike jumps under = throw over' } },
        { position_id: 'RB', position_name: 'Running Back', route_points: [{ x: 20, y: 5 }, { x: 8, y: 5 }], tags: [], motion: 'none', route_details: { steps: '1. Check protection\n2. Swing route', landmark: 'Flat', read_key: 'Blitz', coaching_point: 'Be the checkdown, sell the block first' } }
      ]
    },
    {
      play_id: 'play_4',
      name: 'Four Verticals',
      formation: 'Spread',
      snap_count: 'On 1',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'WR_X', position_name: 'X Receiver', route_points: [{ x: 5, y: 10 }, { x: 5, y: 35 }], tags: [], motion: 'none', route_details: { steps: '1. Vertical release\n2. Stack the corner\n3. Track the ball', landmark: 'Outside numbers', read_key: 'Corner leverage', coaching_point: 'Win at the line, run through the catch' } },
        { position_id: 'WR_Z', position_name: 'Z Receiver', route_points: [{ x: 45, y: 10 }, { x: 45, y: 35 }], tags: [], motion: 'none', route_details: { steps: '1. Vertical release\n2. Beat press\n3. Run under the ball', landmark: 'Outside numbers', read_key: 'Corner technique', coaching_point: 'Speed release, track over inside shoulder' } },
        { position_id: 'WR_Y', position_name: 'Slot Left', route_points: [{ x: 15, y: 9 }, { x: 18, y: 35 }], tags: [], motion: 'none', route_details: { steps: '1. Free release\n2. Seam route\n3. Bend to open area', landmark: 'Hash marks', read_key: 'Safety', coaching_point: 'Find the hole in Cover 2, split safeties in Cover 1' } },
        { position_id: 'TE', position_name: 'Slot Right', route_points: [{ x: 35, y: 9 }, { x: 32, y: 35 }], tags: [], motion: 'none', route_details: { steps: '1. Release inside\n2. Seam route\n3. Adjust to coverage', landmark: 'Opposite hash', read_key: 'Safety', coaching_point: 'Landmark the near upright' } },
        { position_id: 'LT', position_name: 'Left Tackle', route_points: [{ x: 19, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Max protection', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Buy time for deep routes' } },
        { position_id: 'LG', position_name: 'Left Guard', route_points: [{ x: 22, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass protection', landmark: 'A gap', read_key: 'DT', coaching_point: 'No inside penetration' } },
        { position_id: 'C', position_name: 'Center', route_points: [{ x: 25, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass protection', landmark: 'A gaps', read_key: 'Nose/Mike', coaching_point: 'Solid base, anchor' } },
        { position_id: 'RG', position_name: 'Right Guard', route_points: [{ x: 28, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Pass protection', landmark: 'A gap', read_key: 'DT', coaching_point: 'Handle games and twists' } },
        { position_id: 'RT', position_name: 'Right Tackle', route_points: [{ x: 31, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Max protection', landmark: 'B gap', read_key: 'Edge', coaching_point: 'Deep drop, be patient' } },
        { position_id: 'QB', position_name: 'Quarterback', route_points: [{ x: 25, y: 3 }, { x: 25, y: 0 }], tags: [], motion: 'none', route_details: { steps: '1. 5-step drop + hitch\n2. Read safeties\n3. Throw to single coverage', landmark: '8-10 yards depth', read_key: 'Safety rotation', coaching_point: 'If 1 high = work seams, if 2 high = work outside' } },
        { position_id: 'RB', position_name: 'Running Back', route_points: [{ x: 25, y: 0 }], tags: [], motion: 'none', route_details: { steps: 'Max protect - check both sides', landmark: 'Backfield', read_key: 'Free rusher', coaching_point: 'Be the 6th protector, scan for blitz' } }
      ]
    },
    {
      play_id: 'play_5',
      name: 'HB Dive',
      formation: 'I-Formation',
      snap_count: 'On 1',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'WR_X', position_name: 'Split End', route_points: [{ x: 5, y: 10 }, { x: 5, y: 18 }], tags: [], motion: 'none', route_details: { steps: 'Stalk block corner', landmark: 'Numbers', read_key: 'Corner', coaching_point: 'Get to his outside shoulder' } },
        { position_id: 'WR_Z', position_name: 'Flanker', route_points: [{ x: 45, y: 9 }, { x: 45, y: 18 }], tags: [], motion: 'none', route_details: { steps: 'Stalk block corner', landmark: 'Numbers', read_key: 'Corner', coaching_point: 'Sustain the block' } },
        { position_id: 'TE', position_name: 'Tight End', route_points: [{ x: 33, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Base block DE', landmark: 'C gap', read_key: 'DE', coaching_point: 'Drive block, get movement' } },
        { position_id: 'LT', position_name: 'Left Tackle', route_points: [{ x: 19, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Drive block DT', landmark: 'B gap', read_key: 'DT', coaching_point: 'Helmet across, drive legs' } },
        { position_id: 'LG', position_name: 'Left Guard', route_points: [{ x: 22, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Double team to backside LB', landmark: 'A gap', read_key: 'DT to Will', coaching_point: 'Move the line of scrimmage' } },
        { position_id: 'C', position_name: 'Center', route_points: [{ x: 25, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Double team playside', landmark: 'Playside A gap', read_key: 'Nose', coaching_point: 'Control nose, climb to Mike' } },
        { position_id: 'RG', position_name: 'Right Guard', route_points: [{ x: 28, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Double team with C', landmark: 'A gap', read_key: 'Nose to Mike', coaching_point: 'Vertical push then second level' } },
        { position_id: 'RT', position_name: 'Right Tackle', route_points: [{ x: 31, y: 10 }], tags: [], motion: 'none', route_details: { steps: 'Reach block DE', landmark: 'B gap', read_key: 'DE', coaching_point: 'Cut off backside' } },
        { position_id: 'QB', position_name: 'Quarterback', route_points: [{ x: 25, y: 5 }, { x: 25, y: 7 }], tags: [], motion: 'none', route_details: { steps: '1. Reverse pivot\n2. Hand off\n3. Carry out fake', landmark: 'Mesh at FB depth', read_key: 'Give', coaching_point: 'Sell play action' } },
        { position_id: 'FB', position_name: 'Fullback', route_points: [{ x: 25, y: 2 }, { x: 26, y: 15 }], tags: [], motion: 'none', route_details: { steps: 'Lead block through A gap', landmark: 'Playside A gap', read_key: 'Mike LB', coaching_point: 'Fill for RB, be physical' } },
        { position_id: 'RB', position_name: 'Running Back', route_points: [{ x: 25, y: 0 }, { x: 26, y: 18 }], tags: [], motion: 'none', route_details: { steps: '1. Take handoff\n2. Follow FB\n3. One cut go', landmark: 'A gap', read_key: 'FB block', coaching_point: 'Press the hole, vertical on cut' } }
      ]
    }
  ]);

  const [defensivePlays, setDefensivePlays] = useState([
    {
      play_id: 'def_play_1',
      name: 'Cover 3 Base',
      front: '4-3',
      coverage: 'Cover 3',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: 'Wide 9 technique', responsibility: 'Contain rush, set edge', read_key: 'Tackle', coaching_point: 'Force everything inside' },
        { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 technique', responsibility: 'B gap, penetrate', read_key: 'Guard', coaching_point: 'Get upfield, disrupt timing' },
        { position_id: 'DT_R', position_name: 'Right DT', alignment: '1 technique', responsibility: 'A gap control', read_key: 'Center/Guard', coaching_point: 'Anchor vs double team' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: '5 technique', responsibility: 'C gap, contain', read_key: 'Tight end', coaching_point: 'Read TE for run/pass' },
        { position_id: 'SAM', position_name: 'SAM LB', alignment: 'Over TE', responsibility: 'Curl/Flat zone', read_key: '#2 receiver', coaching_point: 'Collision TE, drop to curl' },
        { position_id: 'MIKE', position_name: 'MIKE LB', alignment: 'Middle 4-5 yards', responsibility: 'Hook/Curl zone', read_key: 'Guards', coaching_point: 'Flow to ball, middle hole' },
        { position_id: 'WILL', position_name: 'WILL LB', alignment: 'Weak 4-5 yards', responsibility: 'Curl/Flat zone', read_key: '#2 receiver', coaching_point: 'Fast flow, rally to ball' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Outside #1 WR', responsibility: 'Deep 1/3 zone', read_key: '#1 receiver', coaching_point: 'Bail at snap, carry vertical' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Outside #1 WR', responsibility: 'Deep 1/3 zone', read_key: '#1 receiver', coaching_point: 'Cushion and carry deep' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: 'Box/apex', responsibility: 'Force player, curl', read_key: 'Run/Pass key', coaching_point: 'Attack downhill vs run' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Middle 12 yards', responsibility: 'Deep middle 1/3', read_key: 'QB eyes', coaching_point: 'Range the middle third' }
      ]
    },
    {
      play_id: 'def_play_2',
      name: 'Cover 2 Man',
      front: '4-3',
      coverage: 'Cover 2 Man',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: 'Wide 9', responsibility: 'Contain rush', read_key: 'Tackle', coaching_point: 'Speed to QB' },
        { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 tech', responsibility: 'B gap pressure', read_key: 'Guard', coaching_point: 'Penetrate upfield' },
        { position_id: 'DT_R', position_name: 'Right DT', alignment: '1 tech', responsibility: 'A gap push', read_key: 'Center', coaching_point: 'Occupy blockers' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: '5 tech', responsibility: 'C gap rush', read_key: 'TE', coaching_point: 'Quick inside move' },
        { position_id: 'SAM', position_name: 'SAM LB', alignment: 'Box', responsibility: 'Man on RB', read_key: 'Running back', coaching_point: 'Press and trail RB' },
        { position_id: 'MIKE', position_name: 'MIKE LB', alignment: 'Middle', responsibility: 'Man on TE', read_key: 'Tight end', coaching_point: 'Jam and run with TE' },
        { position_id: 'WILL', position_name: 'WILL LB', alignment: 'Weak', responsibility: 'Man on slot/RB', read_key: '#2 receiver', coaching_point: 'Match routes' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Press', responsibility: 'Man on #1 WR', read_key: 'Your man', coaching_point: 'Jam at line, stay on hip' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Press', responsibility: 'Man on #1 WR', read_key: 'Your man', coaching_point: 'Physical press coverage' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: 'Deep half', responsibility: 'Deep 1/2 zone', read_key: 'Deepest threat', coaching_point: 'Over the top help' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Deep half', responsibility: 'Deep 1/2 zone', read_key: 'Deepest threat', coaching_point: 'Split the field deep' }
      ]
    },
    {
      play_id: 'def_play_3',
      name: 'Cover 4 Quarters',
      front: '4-3',
      coverage: 'Cover 4',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: '5 tech', responsibility: 'C gap, contain', read_key: 'TE', coaching_point: 'Box the TE' },
        { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 tech', responsibility: 'B gap', read_key: 'Guard pull', coaching_point: 'Cross face vs down' },
        { position_id: 'DT_R', position_name: 'Right DT', alignment: '3 tech', responsibility: 'B gap', read_key: 'Guard pull', coaching_point: 'Squeeze the guard' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: '5 tech', responsibility: 'C gap, contain', read_key: 'TE', coaching_point: 'Spill runs outside' },
        { position_id: 'SAM', position_name: 'SAM LB', alignment: 'Apex', responsibility: 'Curl/Flat', read_key: '#2 to #1', coaching_point: 'Read 2 to 1 route' },
        { position_id: 'MIKE', position_name: 'MIKE LB', alignment: 'Middle', responsibility: 'Hook/Curl', read_key: 'Guards', coaching_point: 'Fill A gaps vs run' },
        { position_id: 'WILL', position_name: 'WILL LB', alignment: 'Apex weak', responsibility: 'Curl/Flat', read_key: '#2 to #1', coaching_point: 'Pattern match' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Off #1', responsibility: 'Outside 1/4', read_key: '#1 vertical', coaching_point: 'Quarter-quarter-half' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Off #1', responsibility: 'Outside 1/4', read_key: '#1 vertical', coaching_point: 'Cushion, carry deep' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: '8-10 yards', responsibility: 'Inside 1/4', read_key: '#2 vertical', coaching_point: 'Match vertical #2' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: '8-10 yards', responsibility: 'Inside 1/4', read_key: '#2 vertical', coaching_point: 'Help on seams' }
      ]
    },
    {
      play_id: 'def_play_4',
      name: 'Tampa 2',
      front: '4-3',
      coverage: 'Tampa 2',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: 'Wide 5', responsibility: 'Contain, pressure', read_key: 'Tackle', coaching_point: 'Get upfield' },
        { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 tech', responsibility: 'B gap penetrate', read_key: 'Guard', coaching_point: 'Disrupt QB timing' },
        { position_id: 'DT_R', position_name: 'Right DT', alignment: '1 tech', responsibility: 'A gap', read_key: 'Center', coaching_point: 'Control center' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: 'Wide 5', responsibility: 'Contain, pressure', read_key: 'Tackle', coaching_point: 'Speed rush' },
        { position_id: 'SAM', position_name: 'SAM LB', alignment: 'Box', responsibility: 'Curl to Flat', read_key: '#2 receiver', coaching_point: 'Wall off #2' },
        { position_id: 'MIKE', position_name: 'MIKE LB', alignment: 'Middle', responsibility: 'Hook to deep middle', read_key: 'QB drop', coaching_point: 'Carry seam vertical - key to Tampa 2' },
        { position_id: 'WILL', position_name: 'WILL LB', alignment: 'Weak', responsibility: 'Curl to Flat', read_key: '#2 receiver', coaching_point: 'Pattern read' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Press', responsibility: 'Flat zone', read_key: '#1 release', coaching_point: 'Jam and sink to flat' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Press', responsibility: 'Flat zone', read_key: '#1 release', coaching_point: 'Reroute #1, flat responsibility' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: 'Deep half', responsibility: 'Deep 1/2', read_key: '#1 and #2', coaching_point: 'Split the difference' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Deep half', responsibility: 'Deep 1/2', read_key: 'Post side', coaching_point: 'Read QB eyes' }
      ]
    },
    {
      play_id: 'def_play_5',
      name: 'Cover 1 Robber',
      front: '4-3',
      coverage: 'Cover 1',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: '6 tech', responsibility: 'Contain', read_key: 'Tackle', coaching_point: 'Set edge first' },
        { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 tech', responsibility: 'B gap', read_key: 'Guard', coaching_point: 'Penetrate' },
        { position_id: 'DT_R', position_name: 'Right DT', alignment: '2i tech', responsibility: 'A gap', read_key: 'Center', coaching_point: 'Two gap' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: '6 tech', responsibility: 'Contain', read_key: 'TE', coaching_point: 'Wrong arm vs run' },
        { position_id: 'SAM', position_name: 'SAM LB', alignment: 'Edge', responsibility: 'Man on TE', read_key: 'TE', coaching_point: 'Collision and cover' },
        { position_id: 'MIKE', position_name: 'MIKE LB', alignment: 'Middle', responsibility: 'Man on RB', read_key: 'RB', coaching_point: 'Match RB release' },
        { position_id: 'WILL', position_name: 'WILL LB', alignment: 'Weak', responsibility: 'Run fit / spy', read_key: 'QB', coaching_point: 'Fill or spy QB' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Press', responsibility: 'Man on #1', read_key: '#1', coaching_point: 'No inside release' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Press', responsibility: 'Man on #1', read_key: '#1', coaching_point: 'Physical at line' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: 'Underneath', responsibility: 'Robber - rob crossing routes', read_key: 'QB eyes', coaching_point: 'Read QB, jump crossers' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Deep middle', responsibility: 'Center field', read_key: 'QB', coaching_point: 'Single high help' }
      ]
    },
    {
      play_id: 'def_play_6',
      name: 'Nickel Cover 3',
      front: 'Nickel',
      coverage: 'Cover 3',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: '5 tech', responsibility: 'C gap', read_key: 'Tackle', coaching_point: 'Contain rush' },
        { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 tech', responsibility: 'B gap', read_key: 'Guard', coaching_point: 'Penetrate' },
        { position_id: 'DT_R', position_name: 'Right DT', alignment: '1 tech', responsibility: 'A gap', read_key: 'Center', coaching_point: 'Hold point of attack' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: '5 tech', responsibility: 'C gap', read_key: 'TE', coaching_point: 'Set edge' },
        { position_id: 'MIKE', position_name: 'MIKE LB', alignment: 'Middle', responsibility: 'Hook zone', read_key: 'Triangle', coaching_point: 'Wall crossers' },
        { position_id: 'WILL', position_name: 'WILL LB', alignment: 'Weak', responsibility: 'Curl/Flat', read_key: '#2', coaching_point: 'Carry #2 vertical' },
        { position_id: 'NB', position_name: 'Nickel Back', alignment: 'Slot', responsibility: 'Curl/Flat', read_key: '#2', coaching_point: 'Re-route slot' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Off', responsibility: 'Deep 1/3', read_key: '#1', coaching_point: 'Funnel inside' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Off', responsibility: 'Deep 1/3', read_key: '#1', coaching_point: 'Bail technique' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: 'Box', responsibility: 'Force', read_key: 'EMOL', coaching_point: 'Flat in Cover 3' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Deep middle', responsibility: 'Deep 1/3', read_key: 'QB', coaching_point: 'Range post to post' }
      ]
    },
    {
      play_id: 'def_play_7',
      name: 'Dime Cover 6',
      front: 'Dime',
      coverage: 'Cover 6',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: '5 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Get after QB' },
        { position_id: 'DT_L', position_name: 'Nose', alignment: '0 tech', responsibility: 'A gaps', read_key: 'Ball', coaching_point: 'Eat blocks' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: '5 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Speed to power' },
        { position_id: 'MIKE', position_name: 'MIKE LB', alignment: 'Middle', responsibility: 'Hook', read_key: 'Triangle', coaching_point: 'Spy or hook' },
        { position_id: 'NB', position_name: 'Nickel', alignment: 'Slot strong', responsibility: 'Man on slot', read_key: 'Slot', coaching_point: 'Inside leverage' },
        { position_id: 'DIME', position_name: 'Dime', alignment: 'Slot weak', responsibility: 'Flat/Out', read_key: '#2', coaching_point: 'Pattern match' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Press', responsibility: 'Man #1', read_key: '#1', coaching_point: 'Quarters rules' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Off', responsibility: '1/4 zone', read_key: '#1', coaching_point: '2-read' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: '10 yards', responsibility: '1/4 zone', read_key: '#2', coaching_point: 'Match #2' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Deep half', responsibility: 'Deep 1/2', read_key: 'QB', coaching_point: 'Cover 2 side' }
      ]
    },
    {
      play_id: 'def_play_8',
      name: '3-4 Bear',
      front: '3-4 Bear',
      coverage: 'Cover 1',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: '4i tech', responsibility: 'B gap', read_key: 'Guard', coaching_point: 'Wrong arm' },
        { position_id: 'NT', position_name: 'Nose', alignment: '0 tech', responsibility: 'A gaps', read_key: 'Center', coaching_point: 'Two gap nose' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: '4i tech', responsibility: 'B gap', read_key: 'Guard', coaching_point: 'Spill to LBs' },
        { position_id: 'OLB_L', position_name: 'LOLB', alignment: 'Edge', responsibility: 'Contain/Rush', read_key: 'Tackle', coaching_point: 'Set edge or rush' },
        { position_id: 'ILB_L', position_name: 'ILB', alignment: 'A gap', responsibility: 'Fill A', read_key: 'Guards', coaching_point: 'Downhill' },
        { position_id: 'ILB_R', position_name: 'ILB', alignment: 'A gap', responsibility: 'Fill A', read_key: 'Guards', coaching_point: 'Read and react' },
        { position_id: 'OLB_R', position_name: 'ROLB', alignment: 'Edge', responsibility: 'Contain/Rush', read_key: 'TE', coaching_point: 'Primary rusher' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Press', responsibility: 'Man #1', read_key: '#1', coaching_point: 'No cushion' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Press', responsibility: 'Man #1', read_key: '#1', coaching_point: 'Mirror' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: 'Box', responsibility: 'Man TE/RB', read_key: 'TE', coaching_point: 'Run support first' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Center field', responsibility: 'Deep middle', read_key: 'QB', coaching_point: 'Last line' }
      ]
    },
    {
      play_id: 'def_play_9',
      name: 'Cover 0 Blitz',
      front: '4-3',
      coverage: 'Cover 0',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: 'Wide', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Win your matchup' },
        { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'A gap if free' },
        { position_id: 'DT_R', position_name: 'Right DT', alignment: '3 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Collapse pocket' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: 'Wide', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Speed rush' },
        { position_id: 'SAM', position_name: 'SAM LB', alignment: 'Edge', responsibility: 'Blitz', read_key: 'Ball', coaching_point: 'Green dog' },
        { position_id: 'MIKE', position_name: 'MIKE LB', alignment: 'A gap', responsibility: 'Blitz A', read_key: 'Ball', coaching_point: 'Be first there' },
        { position_id: 'WILL', position_name: 'WILL LB', alignment: 'Edge', responsibility: 'Blitz', read_key: 'Ball', coaching_point: 'Contain if needed' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Press', responsibility: 'Man #1', read_key: '#1', coaching_point: 'No safety help!' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Press', responsibility: 'Man #1', read_key: '#1', coaching_point: 'Cannot get beat deep' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: 'Man', responsibility: 'Man TE', read_key: 'TE', coaching_point: 'Physical at line' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Man', responsibility: 'Man RB', read_key: 'RB', coaching_point: 'Match release' }
      ]
    },
    {
      play_id: 'def_play_10',
      name: 'Zone Blitz',
      front: '3-4',
      coverage: 'Cover 3 Fire Zone',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: '5 tech', responsibility: 'Seam/Hook drop', read_key: '#2', coaching_point: 'Fake rush, drop' },
        { position_id: 'NT', position_name: 'Nose', alignment: '0 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Occupy center' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: '5 tech', responsibility: 'Rush contain', read_key: 'Ball', coaching_point: 'Set edge' },
        { position_id: 'OLB_L', position_name: 'LOLB', alignment: 'Edge', responsibility: 'Blitz', read_key: 'Ball', coaching_point: 'Primary rusher' },
        { position_id: 'ILB_L', position_name: 'ILB', alignment: 'Hook', responsibility: 'Hook zone', read_key: '#2', coaching_point: 'Wall crossers' },
        { position_id: 'ILB_R', position_name: 'ILB', alignment: 'A gap', responsibility: 'Blitz A', read_key: 'Ball', coaching_point: 'Fast to QB' },
        { position_id: 'OLB_R', position_name: 'ROLB', alignment: 'Flat', responsibility: 'Flat zone', read_key: '#2', coaching_point: 'Replace DE' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Off', responsibility: 'Deep 1/3', read_key: '#1', coaching_point: 'Bail at snap' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Off', responsibility: 'Deep 1/3', read_key: '#1', coaching_point: 'No deep ball' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: 'Flat', responsibility: 'Flat zone', read_key: '#2', coaching_point: 'Rally to ball' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Deep middle', responsibility: 'Deep 1/3', read_key: 'QB', coaching_point: 'Center field' }
      ]
    },
    {
      play_id: 'def_play_11',
      name: 'Cover 2 Zone',
      front: '4-3',
      coverage: 'Cover 2',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: '6 tech', responsibility: 'Contain', read_key: 'Tackle', coaching_point: 'Squeeze C gap' },
        { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 tech', responsibility: 'B gap', read_key: 'Guard', coaching_point: 'Push pocket' },
        { position_id: 'DT_R', position_name: 'Right DT', alignment: '1 tech', responsibility: 'A gap', read_key: 'Center', coaching_point: 'Anchor' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: '6 tech', responsibility: 'Contain', read_key: 'TE', coaching_point: 'Rush lane' },
        { position_id: 'SAM', position_name: 'SAM LB', alignment: 'Apex', responsibility: 'Hook to Curl', read_key: '#2', coaching_point: 'Wall #2' },
        { position_id: 'MIKE', position_name: 'MIKE LB', alignment: 'Middle', responsibility: 'Middle Hook', read_key: 'QB', coaching_point: 'Squeeze middle' },
        { position_id: 'WILL', position_name: 'WILL LB', alignment: 'Apex weak', responsibility: 'Hook to Curl', read_key: '#2', coaching_point: 'Carry vertical' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Press', responsibility: 'Flat zone', read_key: '#1', coaching_point: 'Jam and sink' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Press', responsibility: 'Flat zone', read_key: '#1', coaching_point: 'Funnel inside' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: 'Deep half', responsibility: 'Deep 1/2', read_key: '#1 #2', coaching_point: 'No deep ball' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Deep half', responsibility: 'Deep 1/2', read_key: '#1 #2', coaching_point: 'Read high to low' }
      ]
    },
    {
      play_id: 'def_play_12',
      name: 'Prevent Defense',
      front: 'Prevent',
      coverage: 'Prevent',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: 'Wide', responsibility: 'Contain', read_key: 'Ball', coaching_point: 'No scramble' },
        { position_id: 'DT_L', position_name: 'DT', alignment: '3 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Stay in lane' },
        { position_id: 'DT_R', position_name: 'DT', alignment: '3 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Get hands up' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: 'Wide', responsibility: 'Contain', read_key: 'Ball', coaching_point: 'Spy QB' },
        { position_id: 'MIKE', position_name: 'LB', alignment: 'Deep hook', responsibility: 'Deep hook', read_key: 'Crossers', coaching_point: 'Take away middle' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Deep', responsibility: 'Deep 1/4', read_key: '#1', coaching_point: 'Nothing behind you' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Deep', responsibility: 'Deep 1/4', read_key: '#1', coaching_point: 'Stay deep' },
        { position_id: 'NB', position_name: 'Nickel', alignment: 'Deep', responsibility: 'Deep 1/4', read_key: '#2', coaching_point: 'Inside leverage' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: 'Deep 1/4', responsibility: 'Deep 1/4', read_key: '#2', coaching_point: 'Keep everything in front' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Centerfield', responsibility: 'Deep middle', read_key: 'Deepest', coaching_point: 'Last line of defense' }
      ]
    },
    {
      play_id: 'def_play_13',
      name: 'Goal Line',
      front: 'Goal Line',
      coverage: 'Man Free',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: '4 tech', responsibility: 'C gap', read_key: 'TE', coaching_point: 'Wrong arm' },
        { position_id: 'DT_L', position_name: 'Left DT', alignment: '2 tech', responsibility: 'A gap', read_key: 'Guard', coaching_point: 'Anchor' },
        { position_id: 'NT', position_name: 'Nose', alignment: '0 tech', responsibility: 'A gap', read_key: 'Center', coaching_point: 'Do not get moved' },
        { position_id: 'DT_R', position_name: 'Right DT', alignment: '2 tech', responsibility: 'A gap', read_key: 'Guard', coaching_point: 'Hold ground' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: '4 tech', responsibility: 'C gap', read_key: 'TE', coaching_point: 'Squeeze down' },
        { position_id: 'SAM', position_name: 'SAM LB', alignment: 'Stack', responsibility: 'B gap', read_key: 'FB', coaching_point: 'Fill fast' },
        { position_id: 'MIKE', position_name: 'MIKE LB', alignment: 'Stack', responsibility: 'A gap', read_key: 'RB', coaching_point: 'Attack downhill' },
        { position_id: 'WILL', position_name: 'WILL LB', alignment: 'Stack', responsibility: 'B gap', read_key: 'Flow', coaching_point: 'Scrape to ball' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Press', responsibility: 'Man #1', read_key: '#1', coaching_point: 'No fade' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Press', responsibility: 'Man #1', read_key: '#1', coaching_point: 'Contest everything' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Middle', responsibility: 'Center field', read_key: 'QB', coaching_point: 'Break on ball' }
      ]
    },
    {
      play_id: 'def_play_14',
      name: 'Nickel Blitz',
      front: 'Nickel',
      coverage: 'Cover 1',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: '5 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Contain' },
        { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 tech', responsibility: 'B gap rush', read_key: 'Ball', coaching_point: 'Penetrate' },
        { position_id: 'DT_R', position_name: 'Right DT', alignment: '3 tech', responsibility: 'B gap rush', read_key: 'Ball', coaching_point: 'Collapse' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: '5 tech', responsibility: 'Rush', read_key: 'Ball', coaching_point: 'Contain' },
        { position_id: 'MIKE', position_name: 'MIKE LB', alignment: 'A gap', responsibility: 'A gap blitz', read_key: 'Ball', coaching_point: 'Fire on snap' },
        { position_id: 'NB', position_name: 'Nickel', alignment: 'Slot', responsibility: 'Blitz off edge', read_key: 'Ball', coaching_point: 'Time the snap' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Press', responsibility: 'Man #1', read_key: '#1', coaching_point: 'No help' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Press', responsibility: 'Man #1', read_key: '#1', coaching_point: 'Stay attached' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: 'Man', responsibility: 'Man TE', read_key: 'TE', coaching_point: 'Collision' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: 'Center field', responsibility: 'Deep middle', read_key: 'QB', coaching_point: 'Single high' }
      ]
    },
    {
      play_id: 'def_play_15',
      name: 'Quarters Match',
      front: '4-3',
      coverage: 'Quarters',
      snap_count: 'On movement',
      version: 1,
      updated: false,
      video_url: '',
      positions: [
        { position_id: 'DE_L', position_name: 'Left DE', alignment: '5 tech', responsibility: 'C gap', read_key: 'Tackle', coaching_point: 'Set edge' },
        { position_id: 'DT_L', position_name: 'Left DT', alignment: '3 tech', responsibility: 'B gap', read_key: 'Guard', coaching_point: 'Control gap' },
        { position_id: 'DT_R', position_name: 'Right DT', alignment: '3 tech', responsibility: 'B gap', read_key: 'Guard', coaching_point: 'Push pocket' },
        { position_id: 'DE_R', position_name: 'Right DE', alignment: '5 tech', responsibility: 'C gap', read_key: 'TE', coaching_point: 'Contain' },
        { position_id: 'SAM', position_name: 'SAM LB', alignment: 'Apex', responsibility: 'Check #2 - Man or Zone', read_key: '#2 vertical?', coaching_point: 'If #2 vert = man, else zone' },
        { position_id: 'MIKE', position_name: 'MIKE LB', alignment: 'Middle', responsibility: 'Hook to RB', read_key: 'Guards/RB', coaching_point: 'Run first' },
        { position_id: 'WILL', position_name: 'WILL LB', alignment: 'Apex weak', responsibility: 'Check #2 - Man or Zone', read_key: '#2 vertical?', coaching_point: 'Same rules' },
        { position_id: 'CB_L', position_name: 'Left CB', alignment: 'Off 7 yards', responsibility: '1/4 - play #1', read_key: '#1', coaching_point: 'If #1 out, look for #2' },
        { position_id: 'CB_R', position_name: 'Right CB', alignment: 'Off 7 yards', responsibility: '1/4 - play #1', read_key: '#1', coaching_point: 'Bracket with safety' },
        { position_id: 'SS', position_name: 'Strong Safety', alignment: '10 yards', responsibility: '1/4 - play #2', read_key: '#2', coaching_point: 'Match vertical' },
        { position_id: 'FS', position_name: 'Free Safety', alignment: '10 yards', responsibility: '1/4 - play #2', read_key: '#2', coaching_point: 'Help on post' }
      ]
    }
  ]);

  // ============== LOGIN SCREEN ==============
  function LoginScreen() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [rememberMe, setRememberMe] = useState(false);
    const [showForgotPassword, setShowForgotPassword] = useState(false);
    const [resetEmail, setResetEmail] = useState('');
    const [resetSent, setResetSent] = useState(false);

    const handleLogin = async () => {
      setAuthError('');
      setAuthLoading(true);
      
      if (USE_FIREBASE) {
        // ===== FIREBASE AUTH =====
        // Uncomment when Firebase is configured:
        // const result = await signIn(email, password);
        // if (result.success) {
        //   setCurrentUser({ ...result.user, ...result.userData });
        //   setAuthState('authenticated');
        //   setUserRole(result.userData?.role || 'coach');
        // } else {
        //   setAuthError(result.error);
        // }
        // setAuthLoading(false);
      } else {
        // ===== DEMO MODE =====
        setTimeout(() => {
          const user = users.find(u => u.email === email && u.password === password);
          
          if (user) {
            setCurrentUser(user);
            setAuthState('authenticated');
            if (user.role === 'player' && user.playerId) {
              const player = players.find(p => p.player_id === user.playerId);
              if (player) setSelectedPlayer(player);
            }
            setUserRole(user.role);
          } else {
            setAuthError('Invalid email or password');
          }
          setAuthLoading(false);
        }, 800);
      }
    };

    const handleForgotPassword = async () => {
      setAuthLoading(true);
      
      if (USE_FIREBASE) {
        // ===== FIREBASE PASSWORD RESET =====
        // This actually sends a real email!
        // Uncomment when Firebase is configured:
        // const result = await resetPassword(resetEmail);
        // if (result.success) {
        //   setResetSent(true);
        // } else {
        //   setAuthError(result.error);
        // }
        // setAuthLoading(false);
      } else {
        // ===== DEMO MODE =====
        setTimeout(() => {
          setResetSent(true);
          setAuthLoading(false);
        }, 1000);
      }
    };

    // Forgot Password Modal
    if (showForgotPassword) {
      return (
        <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
          <div className="w-full max-w-md">
            <div className="text-center mb-8">
              <div className="text-6xl font-black text-blue-500 mb-2">ZUNO</div>
              <p className="text-gray-400">Football Playbook System</p>
            </div>

            <div className="bg-gray-900 rounded-2xl p-8 shadow-xl border border-gray-800">
              {!resetSent ? (
                <>
                  <h2 className="text-2xl font-bold text-white mb-2">Reset Password</h2>
                  <p className="text-gray-400 mb-6">Enter your email and we'll send you a link to reset your password.</p>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Email Address</label>
                      <input
                        type="email"
                        value={resetEmail}
                        onChange={(e) => setResetEmail(e.target.value)}
                        placeholder="coach@school.edu"
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                      />
                    </div>

                    <button
                      onClick={handleForgotPassword}
                      disabled={authLoading || !resetEmail}
                      className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center"
                    >
                      {authLoading ? (
                        <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      ) : (
                        'Send Reset Link'
                      )}
                    </button>
                  </div>
                </>
              ) : (
                <div className="text-center">
                  <div className="text-5xl mb-4">📧</div>
                  <h2 className="text-2xl font-bold text-white mb-2">Check Your Email</h2>
                  <p className="text-gray-400 mb-6">
                    We've sent a password reset link to<br />
                    <span className="text-white font-semibold">{resetEmail}</span>
                  </p>
                  <p className="text-gray-500 text-sm mb-6">
                    Didn't receive the email? Check your spam folder or try again.
                  </p>
                  <button
                    onClick={() => { setResetSent(false); setResetEmail(''); }}
                    className="text-blue-400 hover:text-blue-300 text-sm"
                  >
                    Try a different email
                  </button>
                </div>
              )}

              <div className="mt-6 pt-6 border-t border-gray-800 text-center">
                <button
                  onClick={() => { setShowForgotPassword(false); setResetSent(false); setResetEmail(''); }}
                  className="text-gray-400 hover:text-white"
                >
                  ← Back to Sign In
                </button>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="text-6xl font-black text-blue-500 mb-2">ZUNO</div>
            <p className="text-gray-400">Football Playbook System</p>
          </div>

          {/* Login Card */}
          <div className="bg-gray-900 rounded-2xl p-8 shadow-xl border border-gray-800">
            <h2 className="text-2xl font-bold text-white mb-6">Sign In</h2>
            
            {authError && (
              <div className="bg-red-900/50 border border-red-500 text-red-200 px-4 py-3 rounded-lg mb-4">
                {authError}
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label className="block text-gray-400 text-sm mb-2">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="coach@school.edu"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-2">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                  onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                />
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded border-gray-600 bg-gray-800 text-blue-500 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-gray-400 text-sm">Remember me</span>
                </label>
                <button 
                  onClick={() => setShowForgotPassword(true)}
                  className="text-blue-400 text-sm hover:text-blue-300"
                >
                  Forgot password?
                </button>
              </div>

              <button
                type="button"
                onClick={handleLogin}
                disabled={authLoading || !email || !password}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center"
              >
                {authLoading ? (
                  <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  'Sign In'
                )}
              </button>
            </div>

            <div className="mt-6 text-center">
              <p className="text-gray-400">
                Don't have an account?{' '}
                <button
                  onClick={() => { setAuthState('register'); setAuthError(''); }}
                  className="text-blue-400 hover:text-blue-300 font-semibold"
                >
                  Create Account
                </button>
              </p>
            </div>

            {/* Demo credentials hint */}
            <div className="mt-6 pt-6 border-t border-gray-800">
              <p className="text-gray-500 text-xs text-center mb-2">Demo Credentials:</p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-gray-800 p-2 rounded">
                  <p className="text-gray-400">Coach:</p>
                  <p className="text-gray-300">coach@lincoln.edu</p>
                  <p className="text-gray-300">demo123</p>
                </div>
                <div className="bg-gray-800 p-2 rounded">
                  <p className="text-gray-400">Player:</p>
                  <p className="text-gray-300">jake@lincoln.edu</p>
                  <p className="text-gray-300">player123</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ============== REGISTER SCREEN ==============
  function RegisterScreen() {
    const [formData, setFormData] = useState({
      name: '',
      email: '',
      password: '',
      confirmPassword: '',
      role: 'coach',
      team: '',
      agreeTerms: false
    });
    const [regStep, setRegStep] = useState(1); // 1: Account, 2: Plan Selection

    const handleRegister = () => {
      setAuthError('');
      
      // Validate required fields
      if (!formData.name.trim()) {
        setAuthError('Please enter your name');
        return;
      }
      
      if (!formData.email.trim()) {
        setAuthError('Please enter your email');
        return;
      }
      
      if (!formData.password) {
        setAuthError('Please enter a password');
        return;
      }
      
      if (formData.password !== formData.confirmPassword) {
        setAuthError('Passwords do not match');
        return;
      }
      
      if (formData.password.length < 6) {
        setAuthError('Password must be at least 6 characters');
        return;
      }
      
      if (!formData.agreeTerms) {
        setAuthError('You must agree to the terms and conditions');
        return;
      }

      if (users.find(u => u.email === formData.email)) {
        setAuthError('An account with this email already exists');
        return;
      }

      // Move to plan selection
      setRegStep(2);
    };

    const selectPlan = async (plan) => {
      setAuthLoading(true);
      
      if (USE_FIREBASE) {
        // ===== FIREBASE REGISTRATION =====
        // Uncomment when Firebase is configured:
        // const result = await signUp(
        //   formData.email, 
        //   formData.password, 
        //   formData.name, 
        //   formData.role, 
        //   formData.team
        // );
        // if (result.success) {
        //   // Update subscription after signup
        //   await updateSubscription(result.user.uid, plan, plan === 'free' ? null : '2025-12-31');
        //   setCurrentUser({ ...result.user, subscription: plan, role: formData.role });
        //   setUserRole(formData.role);
        //   setAuthState('authenticated');
        // } else {
        //   setAuthError(result.error);
        //   setRegStep(1); // Go back to form
        // }
        // setAuthLoading(false);
      } else {
        // ===== DEMO MODE =====
        setTimeout(() => {
          const newUser = {
            id: `user_${Date.now()}`,
            email: formData.email,
            password: formData.password,
            name: formData.name,
            role: formData.role,
            team: formData.team,
            subscription: plan,
            subscriptionExpires: plan === 'free' ? null : '2025-12-31'
          };
          
          setUsers([...users, newUser]);
          setCurrentUser(newUser);
          setUserRole(newUser.role);
          setAuthState('authenticated');
          setAuthLoading(false);
        }, 800);
      }
    };

    if (regStep === 2) {
      return (
        <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
          <div className="w-full max-w-5xl">
            <div className="text-center mb-8">
              <div className="text-4xl font-black text-blue-500 mb-2">ZUNO</div>
              <h2 className="text-2xl font-bold text-white">Choose Your Package</h2>
              <p className="text-gray-400 mt-2">Hardware + Software bundles to transform your program</p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {/* Starter Kit */}
              <div className="bg-gray-900 rounded-2xl p-6 border border-gray-800 hover:border-blue-500 transition-colors">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-bold text-white">Starter Kit</h3>
                  <p className="text-blue-400 text-sm mb-2">Skill Players Package</p>
                  <div className="text-4xl font-black text-white mt-2">$3,999</div>
                  <p className="text-gray-400 text-sm">one-time + $1,500/yr renewal</p>
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> <strong>10 HUD Units</strong>
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> 1 Year Software License
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> Unlimited plays
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> AI Play Builder
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> Practice/Game play calling
                  </li>
                </ul>
                <div className="bg-blue-900/30 rounded-lg p-3 mb-4">
                  <p className="text-blue-300 text-sm text-center">
                    <strong>Perfect for:</strong> QBs, WRs, LBs to refine timing
                  </p>
                </div>
                <button
                  onClick={() => selectPlan('starter')}
                  disabled={authLoading}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition-colors"
                >
                  {authLoading ? 'Processing...' : 'Get Starter Kit'}
                </button>
              </div>

              {/* Full Program Bundle */}
              <div className="bg-gray-900 rounded-2xl p-6 border-2 border-green-500 relative">
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-full">BEST VALUE</span>
                </div>
                <div className="text-center mb-6">
                  <h3 className="text-xl font-bold text-white">Full Program</h3>
                  <p className="text-green-400 text-sm mb-2">Complete Team Bundle</p>
                  <div className="text-4xl font-black text-white mt-2">$8,500</div>
                  <p className="text-gray-400 text-sm">one-time + $1,500/yr renewal</p>
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> <strong>25 HUD Units</strong>
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> 1 Year Software License
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> Unlimited plays
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> AI Play Builder
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> Full analytics dashboard
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> Priority support
                  </li>
                </ul>
                <div className="bg-green-900/30 rounded-lg p-3 mb-4">
                  <p className="text-green-300 text-sm text-center">
                    <strong>Perfect for:</strong> Varsity rosters & tempo periods
                  </p>
                </div>
                <button
                  onClick={() => selectPlan('full')}
                  disabled={authLoading}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg transition-colors"
                >
                  {authLoading ? 'Processing...' : 'Get Full Program'}
                </button>
              </div>

              {/* Software Only */}
              <div className="bg-gray-900 rounded-2xl p-6 border border-gray-800 hover:border-gray-600 transition-colors">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-bold text-white">Software Only</h3>
                  <p className="text-gray-400 text-sm mb-2">Annual License Renewal</p>
                  <div className="text-4xl font-black text-white mt-2">$1,500</div>
                  <p className="text-gray-400 text-sm">per year</p>
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> Team-wide license
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> Unlimited plays
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> AI Play Builder
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> Sync to existing HUDs
                  </li>
                  <li className="flex items-center text-gray-300">
                    <span className="text-green-400 mr-2">✓</span> All software updates
                  </li>
                </ul>
                <div className="bg-gray-800 rounded-lg p-3 mb-4">
                  <p className="text-gray-400 text-sm text-center">
                    <strong>For:</strong> Existing customers or BYO hardware
                  </p>
                </div>
                <button
                  onClick={() => selectPlan('software')}
                  disabled={authLoading}
                  className="w-full bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 rounded-lg transition-colors"
                >
                  {authLoading ? 'Processing...' : 'Get Software License'}
                </button>
              </div>
            </div>

            {/* Demo Option */}
            <div className="mt-8 text-center">
              <div className="bg-gray-900 rounded-xl p-6 max-w-lg mx-auto border border-gray-800">
                <p className="text-gray-400 mb-3">Want to try before you buy?</p>
                <button
                  onClick={() => selectPlan('demo')}
                  disabled={authLoading}
                  className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-6 rounded-lg transition-colors"
                >
                  Start Free Demo
                </button>
                <p className="text-gray-500 text-xs mt-2">Full features, no HUD sync</p>
              </div>
            </div>

            <div className="text-center mt-6">
              <button
                onClick={() => setRegStep(1)}
                className="text-gray-400 hover:text-white"
              >
                ← Back to account setup
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="text-6xl font-black text-blue-500 mb-2">ZUNO</div>
            <p className="text-gray-400">Football Playbook System</p>
          </div>

          {/* Register Card */}
          <div className="bg-gray-900 rounded-2xl p-8 shadow-xl border border-gray-800">
            <h2 className="text-2xl font-bold text-white mb-6">Create Account</h2>
            
            {authError && (
              <div className="bg-red-900/50 border border-red-500 text-red-200 px-4 py-3 rounded-lg mb-4">
                {authError}
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label className="block text-gray-400 text-sm mb-2">Full Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Coach Smith"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-2">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  placeholder="coach@school.edu"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-2">Team / School Name</label>
                <input
                  type="text"
                  value={formData.team}
                  onChange={(e) => setFormData({...formData, team: e.target.value})}
                  placeholder="Lincoln High School"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-2">I am a...</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormData({...formData, role: 'coach'})}
                    className={`py-3 rounded-lg font-semibold transition-colors ${
                      formData.role === 'coach' 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                    }`}
                  >
                    🏈 Coach
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({...formData, role: 'player'})}
                    className={`py-3 rounded-lg font-semibold transition-colors ${
                      formData.role === 'player' 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                    }`}
                  >
                    🎽 Player
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-2">Password</label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  placeholder="••••••••"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-2">Confirm Password</label>
                <input
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                  placeholder="••••••••"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <label className="flex items-start">
                <input
                  type="checkbox"
                  checked={formData.agreeTerms}
                  onChange={(e) => setFormData({...formData, agreeTerms: e.target.checked})}
                  className="w-4 h-4 mt-1 rounded border-gray-600 bg-gray-800 text-blue-500 focus:ring-blue-500"
                />
                <span className="ml-2 text-gray-400 text-sm">
                  I agree to the <a href="#" className="text-blue-400 hover:underline">Terms of Service</a> and <a href="#" className="text-blue-400 hover:underline">Privacy Policy</a>
                </span>
              </label>

              <button
                type="button"
                onClick={handleRegister}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition-colors"
              >
                Continue to Plans
              </button>
            </div>

            <div className="mt-6 text-center">
              <p className="text-gray-400">
                Already have an account?{' '}
                <button
                  onClick={() => { setAuthState('login'); setAuthError(''); }}
                  className="text-blue-400 hover:text-blue-300 font-semibold"
                >
                  Sign In
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ============== ADDITIONAL STATE (must be before conditional returns) ==============
  const [players, setPlayers] = useState(initialPlayers);
  const [selectedPlayer, setSelectedPlayer] = useState(null);
  const [installs, setInstalls] = useState([
    {
      install_id: 'install_1',
      name: 'Week 1 - Opening Drive',
      due_date: '2026-01-12',
      play_ids: ['play_1', 'play_2'],
      group: 'Full Offense'
    }
  ]);
  const [editingPlay, setEditingPlay] = useState(null);
  const [editingInstall, setEditingInstall] = useState(null);
  const [viewingDefensivePlay, setViewingDefensivePlay] = useState(null);
  const [playerProgress, setPlayerProgress] = useState({
    p1: {
      play_1: { viewed: true, views: 5, mastered: false, notes: '', lastViewed: '2026-01-10' },
      play_2: { viewed: true, views: 3, mastered: true, notes: 'Remember to block #54 first', lastViewed: '2026-01-12' }
    }
  });
  const [quickLookPlayer, setQuickLookPlayer] = useState(null);
  const [confirmDialog, setConfirmDialog] = useState(null);

  // ============== CHECK AUTH STATE ==============
  if (authState === 'login') {
    return <LoginScreen />;
  }
  
  if (authState === 'register') {
    return <RegisterScreen />;
  }

  // ============== MAIN APP CONTENT (AUTHENTICATED) ==============

  function DefensivePlayViewer({ play, onClose }) {
    const fieldWidth = 650;
    const fieldHeight = 450;

    // Default positions for defensive players on the field
    const getDefensivePosition = (posId) => {
      const positions = {
        'DE_L': { x: 15, y: 20 },
        'DT_L': { x: 22, y: 20 },
        'NT': { x: 25, y: 20 },
        'DT_R': { x: 28, y: 20 },
        'DE_R': { x: 35, y: 20 },
        'SAM': { x: 35, y: 14 },
        'MIKE': { x: 25, y: 14 },
        'WILL': { x: 15, y: 14 },
        'OLB_L': { x: 10, y: 16 },
        'OLB_R': { x: 40, y: 16 },
        'ILB_L': { x: 22, y: 14 },
        'ILB_R': { x: 28, y: 14 },
        'CB_L': { x: 5, y: 12 },
        'CB_R': { x: 45, y: 12 },
        'SS': { x: 35, y: 6 },
        'FS': { x: 25, y: 3 },
        'NB': { x: 15, y: 12 },
        'S': { x: 30, y: 6 }
      };
      return positions[posId] || { x: 25, y: 15 };
    };

    const toCanvasX = (x) => (x / 50) * fieldWidth;
    const toCanvasY = (y) => fieldHeight - (y / 40) * fieldHeight;

    // Determine if a player is blitzing based on responsibility
    const isBlitzing = (responsibility) => {
      if (!responsibility) return false;
      const blitzKeywords = ['blitz', 'rush', 'pressure', 'contain', 'spy', 'a gap', 'b gap', 'c gap', 'dog', 'fire', 'storm'];
      return blitzKeywords.some(k => responsibility.toLowerCase().includes(k));
    };

    // Determine zone type for coverage
    const getZoneType = (responsibility, posId) => {
      if (!responsibility) return null;
      const resp = responsibility.toLowerCase();
      
      // Check for man coverage
      if (resp.includes('man') || resp.includes('#1') || resp.includes('#2') || resp.includes('#3')) {
        return 'man';
      }
      
      // Deep zones
      if (resp.includes('deep 1/3') || resp.includes('deep third')) return 'deep-third';
      if (resp.includes('deep half') || resp.includes('deep 1/2')) return 'deep-half';
      if (resp.includes('deep middle') || resp.includes('middle third') || resp.includes('centerfield')) return 'deep-middle';
      if (resp.includes('deep quarter') || resp.includes('quarter')) return 'quarter';
      
      // Underneath zones
      if (resp.includes('flat')) return 'flat';
      if (resp.includes('curl') || resp.includes('hook')) return 'curl-hook';
      if (resp.includes('seam') || resp.includes('hole')) return 'seam';
      
      // Run responsibilities
      if (resp.includes('run') || resp.includes('gap') || resp.includes('fit')) return 'run-fit';
      
      return null;
    };

    // Get zone color
    const getZoneColor = (zoneType) => {
      const colors = {
        'deep-third': 'rgba(59, 130, 246, 0.35)', // Blue
        'deep-half': 'rgba(139, 92, 246, 0.35)', // Purple
        'deep-middle': 'rgba(34, 197, 94, 0.35)', // Green
        'quarter': 'rgba(168, 85, 247, 0.35)', // Purple
        'flat': 'rgba(251, 191, 36, 0.4)', // Yellow
        'curl-hook': 'rgba(249, 115, 22, 0.35)', // Orange
        'seam': 'rgba(236, 72, 153, 0.35)', // Pink
        'run-fit': 'rgba(107, 114, 128, 0.3)', // Gray
        'man': 'transparent'
      };
      return colors[zoneType] || 'transparent';
    };

    // Get zone bubble positioned relative to the player
    // The bubble should be in front of/around the player showing their coverage area
    const getZoneBubble = (zoneType, posId, playerX, playerY) => {
      // Zone bubbles are drawn IN FRONT of the player (higher Y = downfield)
      // and sized based on their zone responsibility
      
      switch (zoneType) {
        case 'deep-third':
          // Deep third - large oval in front of player, extends downfield
          return { 
            cx: playerX, 
            cy: playerY - 8, // In front of player (downfield)
            rx: 7, 
            ry: 6 
          };
        case 'deep-half':
          // Deep half - wider coverage area
          return { 
            cx: playerX, 
            cy: playerY - 8,
            rx: 10, 
            ry: 6 
          };
        case 'deep-middle':
          // Middle of field deep
          return { 
            cx: playerX, 
            cy: playerY - 10,
            rx: 8, 
            ry: 7 
          };
        case 'quarter':
          // Quarter coverage
          return { 
            cx: playerX, 
            cy: playerY - 7,
            rx: 6, 
            ry: 5 
          };
        case 'flat':
          // Flat zone - near sideline, shallow
          return { 
            cx: playerX < 25 ? playerX - 3 : playerX + 3, // Toward sideline
            cy: playerY - 3, // Shallow
            rx: 5, 
            ry: 4 
          };
        case 'curl-hook':
          // Curl/hook - medium depth, in front of player
          return { 
            cx: playerX, 
            cy: playerY - 5,
            rx: 5, 
            ry: 5 
          };
        case 'seam':
          // Seam - vertical area
          return { 
            cx: playerX, 
            cy: playerY - 6,
            rx: 3, 
            ry: 6 
          };
        default:
          return null;
      }
    };

    // Calculate blitz arrow path
    const getBlitzArrow = (posId, basePos) => {
      const targetY = 21; // Just past LOS
      const targetX = basePos.x < 25 ? basePos.x + 3 : basePos.x - 3;
      
      // Different blitz paths based on position
      if (posId.includes('DE') || posId.includes('DT') || posId === 'NT') {
        return { endX: basePos.x, endY: 23, curve: false };
      }
      if (posId === 'MIKE') {
        return { endX: 25, endY: 22, curve: false };
      }
      if (posId === 'WILL') {
        return { endX: 20, endY: 22, curve: true, curveX: 18 };
      }
      if (posId === 'SAM') {
        return { endX: 30, endY: 22, curve: true, curveX: 32 };
      }
      if (posId.includes('SS')) {
        return { endX: 32, endY: 21, curve: true, curveX: 36 };
      }
      if (posId.includes('CB')) {
        return { endX: basePos.x < 25 ? 12 : 38, endY: 21, curve: true, curveX: basePos.x };
      }
      return { endX: targetX, endY: targetY, curve: false };
    };

    // Render zone bubble - positioned relative to the player
    const renderZone = (pos) => {
      const zoneType = getZoneType(pos.responsibility, pos.position_id);
      if (!zoneType || zoneType === 'man' || zoneType === 'run-fit') return null;
      
      const playerPos = getDefensivePosition(pos.position_id);
      const bubble = getZoneBubble(zoneType, pos.position_id, playerPos.x, playerPos.y);
      if (!bubble) return null;
      
      const color = getZoneColor(zoneType);
      const strokeColor = color.replace('0.35', '0.7').replace('0.4', '0.8').replace('0.3', '0.6');
      
      return (
        <ellipse
          key={`zone-${pos.position_id}`}
          cx={toCanvasX(bubble.cx)}
          cy={toCanvasY(bubble.cy)}
          rx={(bubble.rx / 50) * fieldWidth}
          ry={(bubble.ry / 40) * fieldHeight}
          fill={color}
          stroke={strokeColor}
          strokeWidth="2"
          strokeDasharray="5,3"
        />
      );
    };

    // Render blitz arrow
    const renderBlitzArrow = (pos) => {
      if (!isBlitzing(pos.responsibility)) return null;
      
      const basePos = getDefensivePosition(pos.position_id);
      const arrow = getBlitzArrow(pos.position_id, basePos);
      
      const startX = toCanvasX(basePos.x);
      const startY = toCanvasY(basePos.y);
      const endX = toCanvasX(arrow.endX);
      const endY = toCanvasY(arrow.endY);
      
      if (arrow.curve) {
        const curveX = toCanvasX(arrow.curveX);
        return (
          <g key={`blitz-${pos.position_id}`}>
            <defs>
              <marker id={`arrowhead-${pos.position_id}`} markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#ef4444" />
              </marker>
            </defs>
            <path
              d={`M ${startX} ${startY} Q ${curveX} ${(startY + endY) / 2} ${endX} ${endY}`}
              fill="none"
              stroke="#ef4444"
              strokeWidth="3"
              markerEnd={`url(#arrowhead-${pos.position_id})`}
            />
          </g>
        );
      }
      
      return (
        <g key={`blitz-${pos.position_id}`}>
          <defs>
            <marker id={`arrowhead-${pos.position_id}`} markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#ef4444" />
            </marker>
          </defs>
          <line
            x1={startX}
            y1={startY}
            x2={endX}
            y2={endY}
            stroke="#ef4444"
            strokeWidth="3"
            markerEnd={`url(#arrowhead-${pos.position_id})`}
          />
        </g>
      );
    };

    // Render man coverage line
    const renderManCoverage = (pos) => {
      const resp = (pos.responsibility || '').toLowerCase();
      if (!resp.includes('man') && !resp.includes('#1') && !resp.includes('#2') && !resp.includes('#3')) return null;
      
      const basePos = getDefensivePosition(pos.position_id);
      const startX = toCanvasX(basePos.x);
      const startY = toCanvasY(basePos.y);
      
      // Draw a short line toward the receiver they're covering
      let targetX = startX;
      let targetY = startY + 30;
      
      if (resp.includes('#1') || pos.position_id.includes('CB')) {
        targetX = pos.position_id.includes('L') ? toCanvasX(5) : toCanvasX(45);
        targetY = toCanvasY(20);
      } else if (resp.includes('#2')) {
        targetX = pos.position_id.includes('L') || basePos.x < 25 ? toCanvasX(15) : toCanvasX(35);
        targetY = toCanvasY(20);
      }
      
      return (
        <line
          key={`man-${pos.position_id}`}
          x1={startX}
          y1={startY}
          x2={targetX}
          y2={targetY}
          stroke="#f97316"
          strokeWidth="2"
          strokeDasharray="6,4"
          opacity="0.7"
        />
      );
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center p-4 z-50 overflow-y-auto">
        <div className="bg-gray-900 rounded-lg p-6 max-w-6xl w-full max-h-screen overflow-y-auto">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h2 className="text-3xl font-bold">{play.name}</h2>
              <p className="text-xl text-gray-400">{play.front} - {play.coverage}</p>
            </div>
            <button onClick={onClose} className="bg-gray-700 px-6 py-3 rounded font-bold hover:bg-gray-600">Close</button>
          </div>

          {play.video_url && (
            <div className="bg-blue-900 border border-blue-600 p-4 rounded-lg text-center mb-6">
              <span className="font-bold">📹 Video Available:</span>
              <a href={play.video_url} target="_blank" rel="noopener noreferrer" className="ml-2 text-blue-300 underline hover:text-blue-200">
                Watch Film
              </a>
            </div>
          )}

          {/* Reference Image if available */}
          {play.image_url && (
            <div className="bg-gray-800 p-4 rounded-lg mb-6">
              <h3 className="font-bold mb-2">📸 Reference Image:</h3>
              <img src={play.image_url} alt="Play diagram" className="max-h-48 rounded mx-auto" />
            </div>
          )}

          {/* Legend */}
          <div className="bg-gray-800 p-3 rounded-lg mb-4 flex flex-wrap gap-4 text-sm">
            <span className="font-bold">Legend:</span>
            <span className="flex items-center gap-1"><span className="w-4 h-4 rounded-full bg-blue-500 opacity-50"></span> Deep Zone</span>
            <span className="flex items-center gap-1"><span className="w-4 h-4 rounded-full bg-yellow-500 opacity-50"></span> Flat</span>
            <span className="flex items-center gap-1"><span className="w-4 h-4 rounded-full bg-orange-500 opacity-50"></span> Curl/Hook</span>
            <span className="flex items-center gap-1"><span className="w-4 h-3 bg-red-500"></span> Blitz</span>
            <span className="flex items-center gap-1"><span className="w-6 border-t-2 border-orange-400 border-dashed"></span> Man</span>
          </div>

          <div className="bg-red-950 border-2 border-red-600 rounded-lg p-4 mb-6">
            <h3 className="text-xl font-bold mb-3 text-center">Defensive Alignment</h3>
            <div className="bg-green-900 rounded mx-auto overflow-hidden" style={{ width: fieldWidth, height: fieldHeight }}>
              <svg width={fieldWidth} height={fieldHeight}>
                {/* Field lines */}
                {[...Array(9)].map((_, i) => {
                  const yPos = fieldHeight - (i * (fieldHeight / 8));
                  return (
                    <g key={i}>
                      <line x1={0} y1={yPos} x2={fieldWidth} y2={yPos} stroke="#fff" strokeWidth="1" opacity="0.2" />
                      <text x={8} y={yPos - 3} fill="#fff" fontSize="10" opacity="0.4">{i * 5}yd</text>
                    </g>
                  );
                })}
                
                {/* Hash marks */}
                {[...Array(9)].map((_, i) => {
                  const yPos = fieldHeight - (i * (fieldHeight / 8));
                  return (
                    <g key={`hash-${i}`}>
                      <line x1={toCanvasX(18)} y1={yPos - 3} x2={toCanvasX(18)} y2={yPos + 3} stroke="#fff" strokeWidth="1" opacity="0.3" />
                      <line x1={toCanvasX(32)} y1={yPos - 3} x2={toCanvasX(32)} y2={yPos + 3} stroke="#fff" strokeWidth="1" opacity="0.3" />
                    </g>
                  );
                })}
                
                {/* Line of Scrimmage */}
                <line x1={0} y1={toCanvasY(20)} x2={fieldWidth} y2={toCanvasY(20)} stroke="#ffff00" strokeWidth="4" />
                <text x={fieldWidth / 2} y={toCanvasY(20) + 15} textAnchor="middle" fill="#ffff00" fontSize="11" fontWeight="bold">LINE OF SCRIMMAGE</text>
                
                {/* Offensive players (ghost) */}
                <g opacity="0.25">
                  {[
                    { x: 5, y: 20 }, { x: 45, y: 20 }, { x: 15, y: 20 }, { x: 35, y: 20 },
                    { x: 19, y: 20 }, { x: 22, y: 20 }, { x: 25, y: 20 }, { x: 28, y: 20 }, { x: 31, y: 20 },
                    { x: 25, y: 17 }, { x: 25, y: 14 }
                  ].map((pos, i) => (
                    <circle key={i} cx={toCanvasX(pos.x)} cy={toCanvasY(pos.y)} r="8" fill="#666" stroke="#999" strokeWidth="1" />
                  ))}
                </g>
                
                {/* Zone bubbles (rendered first, behind players) */}
                {play.positions.map(pos => renderZone(pos))}
                
                {/* Man coverage lines */}
                {play.positions.map(pos => renderManCoverage(pos))}
                
                {/* Blitz arrows */}
                {play.positions.map(pos => renderBlitzArrow(pos))}
                
                {/* Defensive players */}
                {play.positions.map(pos => {
                  const position = getDefensivePosition(pos.position_id);
                  const blitzing = isBlitzing(pos.responsibility);
                  
                  return (
                    <g key={pos.position_id}>
                      {/* Glow effect for blitzers */}
                      {blitzing && (
                        <circle
                          cx={toCanvasX(position.x)}
                          cy={toCanvasY(position.y)}
                          r="20"
                          fill="rgba(239, 68, 68, 0.3)"
                        />
                      )}
                      {/* Player circle */}
                      <circle
                        cx={toCanvasX(position.x)}
                        cy={toCanvasY(position.y)}
                        r="16"
                        fill={blitzing ? '#dc2626' : '#1e40af'}
                        stroke="#fff"
                        strokeWidth="2"
                      />
                      {/* Position label */}
                      <text
                        x={toCanvasX(position.x)}
                        y={toCanvasY(position.y) + 5}
                        textAnchor="middle"
                        fill="#fff"
                        fontSize="10"
                        fontWeight="bold"
                      >
                        {pos.position_id.replace('_L', '').replace('_R', '')}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
            <p className="text-center text-gray-400 text-sm mt-2">
              🔴 Red = Blitzing | 🔵 Blue = Coverage | Zones shown as colored bubbles
            </p>
          </div>

          <div className="bg-red-900 border border-red-600 p-4 rounded-lg mb-6">
            <h3 className="font-bold text-xl mb-2">Defensive Overview</h3>
            <div className="grid md:grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-red-300 font-bold">Front:</span>
                <span className="ml-2">{play.front}</span>
              </div>
              <div>
                <span className="text-red-300 font-bold">Coverage:</span>
                <span className="ml-2">{play.coverage}</span>
              </div>
              <div>
                <span className="text-red-300 font-bold">Snap:</span>
                <span className="ml-2">{play.snap_count}</span>
              </div>
            </div>
          </div>

          <h3 className="text-2xl font-bold mb-4">Position Assignments</h3>
          <div className="grid md:grid-cols-2 gap-4">
            {play.positions.map(pos => {
              const blitzing = isBlitzing(pos.responsibility);
              return (
                <div key={pos.position_id} className={`bg-gray-800 p-4 rounded-lg border-l-4 ${blitzing ? 'border-red-500' : 'border-blue-500'}`}>
                  <div className="flex items-center gap-2 mb-3">
                    <h4 className="text-xl font-bold text-red-400">{pos.position_name}</h4>
                    {blitzing && <span className="text-xs bg-red-600 px-2 py-1 rounded font-bold">BLITZ</span>}
                  </div>
                  <div className="space-y-2 text-sm">
                    <div>
                      <span className="font-bold text-blue-300">Alignment:</span>
                      <div className="text-gray-200 ml-2">{pos.alignment}</div>
                    </div>
                    <div>
                      <span className="font-bold text-green-300">Responsibility:</span>
                      <div className="text-gray-200 ml-2">{pos.responsibility}</div>
                    </div>
                    <div>
                      <span className="font-bold text-yellow-300">Read Key:</span>
                      <div className="text-gray-200 ml-2">{pos.read_key}</div>
                    </div>
                    <div>
                      <span className="font-bold text-purple-300">Coaching Point:</span>
                      <div className="text-gray-200 ml-2">{pos.coaching_point}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  function PlayEditor({ play, onSave, onCancel }) {
    const [name, setName] = useState(play.name);
    const [formation, setFormation] = useState(play.formation);
    const [snapCount, setSnapCount] = useState(play.snap_count);
    const [videoUrl, setVideoUrl] = useState(play.video_url || '');
    const [positions, setPositions] = useState(play.positions);
    const [selectedPos, setSelectedPos] = useState(null);
    const [drawMode, setDrawMode] = useState(false);
    const [showRouteDetails, setShowRouteDetails] = useState(false);
    const fieldWidth = 500;
    const fieldHeight = 350;

    const toCanvasX = (x) => (x / 50) * fieldWidth;
    const toCanvasY = (y) => fieldHeight - (y / 40) * fieldHeight;
    const toFieldX = (cx) => (cx / fieldWidth) * 50;
    const toFieldY = (cy) => ((fieldHeight - cy) / fieldHeight) * 40;

    // Default alignments based on position
    const getDefaultAlignment = (posId) => {
      // Off the ball: QB, RB, FB, Slot (WR_Y), and Z receiver (WR_Z is the flanker)
      const offBallPositions = ['QB', 'RB', 'FB', 'WR_Y', 'WR_Z'];
      return offBallPositions.includes(posId) ? 'off' : 'on';
    };

    const handleFormationChange = (formName) => {
      setFormation(formName);
      const template = FORMATIONS[formName];
      if (template) {
        setPositions(template.map(p => ({
          position_id: p.position_id,
          position_name: p.position_id,
          route_points: [{ x: p.x, y: p.y }],
          tags: [],
          motion: 'none',
          route_details: { 
            alignment: getDefaultAlignment(p.position_id),
            steps: '', 
            landmark: '', 
            read_key: '', 
            coaching_point: '' 
          }
        })));
        setSelectedPos(null);
      }
    };

    const updateRoutePoints = (posId, points) => {
      setPositions(positions.map(p => p.position_id === posId ? { ...p, route_points: points } : p));
    };

    const updateRouteDetails = (posId, field, value) => {
      setPositions(positions.map(p =>
        p.position_id === posId
          ? { ...p, route_details: { ...(p.route_details || {}), [field]: value } }
          : p
      ));
    };

    // Apply a route template to the selected position
    const applyRouteTemplate = (posId, templateKey, mirror = false) => {
      const template = ROUTE_TEMPLATES[templateKey];
      if (!template) return;
      
      const pos = positions.find(p => p.position_id === posId);
      if (!pos || !pos.route_points[0]) return;
      
      const startX = pos.route_points[0].x;
      const startY = pos.route_points[0].y;
      
      // Convert relative points to absolute, mirror if on right side of field
      const newPoints = [{ x: startX, y: startY }];
      template.points.forEach(([dx, dy]) => {
        const mirrorMultiplier = mirror ? -1 : 1;
        newPoints.push({ 
          x: startX + (dx * mirrorMultiplier), 
          y: startY + dy 
        });
      });
      
      updateRoutePoints(posId, newPoints);
      updateRouteDetails(posId, 'steps', template.description);
    };

    const handleFieldClick = (e) => {
      if (!selectedPos) return;
      const rect = e.currentTarget.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const pos = positions.find(p => p.position_id === selectedPos);
      if (pos) {
        const newX = Math.round(toFieldX(x));
        const newY = Math.round(toFieldY(y));
        if (!drawMode) {
          updateRoutePoints(selectedPos, [{ x: newX, y: newY }, ...pos.route_points.slice(1)]);
        } else {
          updateRoutePoints(selectedPos, [...pos.route_points, { x: newX, y: newY }]);
        }
      }
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center p-4 z-50">
        <div className="bg-gray-900 rounded-lg p-6 max-w-6xl w-full max-h-screen overflow-y-auto">
          <h2 className="text-2xl font-bold mb-4">Play Editor</h2>
          
          {/* Quick Edit All Button - for image imports */}
          {play.image_url && (
            <div className="mb-4 bg-green-900 border border-green-600 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-green-300">📝 Quick Edit All Assignments</div>
                  <div className="text-xs text-green-400">Fill in all player assignments at once</div>
                </div>
                <button 
                  onClick={() => setShowRouteDetails('bulk')}
                  className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded font-bold"
                >
                  Edit All
                </button>
              </div>
            </div>
          )}

          {/* BULK EDIT VIEW */}
          {showRouteDetails === 'bulk' ? (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-bold">All Position Assignments</h3>
                <button onClick={() => setShowRouteDetails(false)} className="bg-gray-700 px-4 py-2 rounded">← Back</button>
              </div>
              
              {play.image_url && (
                <div className="bg-gray-800 p-2 rounded">
                  <img src={play.image_url} alt={name} className="max-h-48 mx-auto rounded" />
                </div>
              )}
              
              <div className="grid gap-3 max-h-96 overflow-y-auto">
                {positions.map(pos => (
                  <div key={pos.position_id} className="bg-gray-800 rounded p-3">
                    <div className="flex items-center gap-4">
                      <div className="w-16 font-black text-green-400 text-lg">{pos.position_id}</div>
                      <div className="flex-1 grid grid-cols-3 gap-2">
                        <input
                          type="text"
                          value={pos.route_details?.steps || ''}
                          onChange={(e) => updateRouteDetails(pos.position_id, 'steps', e.target.value)}
                          placeholder="Route/Assignment"
                          className="bg-gray-900 rounded px-2 py-1 text-sm text-white"
                        />
                        <input
                          type="text"
                          value={pos.route_details?.read_key || ''}
                          onChange={(e) => updateRouteDetails(pos.position_id, 'read_key', e.target.value)}
                          placeholder="Read"
                          className="bg-gray-900 rounded px-2 py-1 text-sm text-white"
                        />
                        <input
                          type="text"
                          value={pos.route_details?.landmark || ''}
                          onChange={(e) => updateRouteDetails(pos.position_id, 'landmark', e.target.value)}
                          placeholder="Landmark"
                          className="bg-gray-900 rounded px-2 py-1 text-sm text-white"
                        />
                      </div>
                      <select
                        value={pos.route_details?.alignment || 'on'}
                        onChange={(e) => updateRouteDetails(pos.position_id, 'alignment', e.target.value)}
                        className="bg-gray-900 rounded px-2 py-1 text-xs w-16"
                      >
                        <option value="on">ON</option>
                        <option value="off">OFF</option>
                      </select>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="flex gap-4">
                <button onClick={() => {
                  const offBallCount = positions.filter(p => p.route_details?.alignment === 'off').length;
                  if (offBallCount > 4) {
                    alert(`⚠️ ILLEGAL FORMATION! ${offBallCount} players off the ball (max 4)`);
                    return;
                  }
                  onSave({ ...play, name, formation, snap_count: snapCount, video_url: videoUrl, positions });
                }} className="flex-1 bg-blue-600 py-3 rounded font-bold hover:bg-blue-700">Save Play</button>
                <button onClick={() => setShowRouteDetails(false)} className="flex-1 bg-gray-700 py-3 rounded font-bold">Back to Editor</button>
              </div>
            </div>
          ) : (
          <div>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div><label className="block text-sm mb-1">Play Name</label><input type="text" value={name} onChange={(e) => setName(e.target.value)} className="w-full bg-gray-800 rounded px-3 py-2 text-white" /></div>
              <div><label className="block text-sm mb-1">Video URL (optional)</label><input type="text" value={videoUrl} onChange={(e) => setVideoUrl(e.target.value)} placeholder="https://youtube.com/..." className="w-full bg-gray-800 rounded px-3 py-2 text-white" /></div>
              <div><label className="block text-sm mb-1">Formation</label><select value={formation} onChange={(e) => handleFormationChange(e.target.value)} className="w-full bg-gray-800 rounded px-3 py-2 text-white"><option value="">Select Formation</option><option value="Spread">Spread</option><option value="Shotgun">Shotgun</option><option value="I-Formation">I-Formation</option><option value="Empty">Empty</option></select></div>
              <div><label className="block text-sm mb-1">Snap Count</label><input type="text" value={snapCount} onChange={(e) => setSnapCount(e.target.value)} className="w-full bg-gray-800 rounded px-3 py-2 text-white" /></div>
              <div><label className="block text-sm mb-2">Positions ({positions.length})</label><div className="space-y-2 max-h-48 overflow-y-auto">{positions.map(pos => (<div key={pos.position_id} className={`p-2 rounded cursor-pointer ${selectedPos === pos.position_id ? 'bg-blue-600' : 'bg-gray-800'}`} onClick={() => setSelectedPos(pos.position_id)}><span className="font-bold">{pos.position_id}</span></div>))}</div></div>
              {selectedPos && (<div className="p-3 bg-gray-800 rounded"><div className="flex justify-between mb-2"><span className="font-bold">{selectedPos}</span><button onClick={() => setDrawMode(!drawMode)} className={`px-3 py-1 rounded text-sm ${drawMode ? 'bg-green-600' : 'bg-gray-700'}`}>{drawMode ? 'Drawing' : 'Move'}</button></div><button onClick={() => setShowRouteDetails(showRouteDetails === true ? false : true)} className="w-full mt-2 bg-blue-600 hover:bg-blue-700 px-3 py-2 rounded text-sm">{showRouteDetails === true ? '← Back to Route' : 'Edit Route Details'}</button></div>)}
            </div>
            <div>
              <label className="block text-sm mb-2">{showRouteDetails === true && selectedPos ? 'Route Details' : 'Field'}</label>
              {showRouteDetails === true && selectedPos ? (
                <div className="bg-gray-800 rounded p-4 space-y-3" style={{ width: fieldWidth, height: fieldHeight, overflowY: 'auto' }}>
                  {/* ROUTE TEMPLATE SELECTOR */}
                  <div className="bg-blue-900 rounded p-3 border border-blue-600">
                    <label className="block text-sm font-bold mb-2 text-blue-300">🏈 Quick Route Shape</label>
                    <div className="flex gap-2">
                      <select 
                        onChange={(e) => {
                          if (e.target.value) {
                            const pos = positions.find(p => p.position_id === selectedPos);
                            const isRightSide = pos?.route_points?.[0]?.x > 25;
                            applyRouteTemplate(selectedPos, e.target.value, isRightSide);
                            e.target.value = '';
                          }
                        }}
                        className="flex-1 bg-gray-900 rounded px-3 py-2 text-white text-sm"
                        defaultValue=""
                      >
                        <option value="">Select a route...</option>
                        <optgroup label="Quick Routes">
                          <option value="Hitch">Hitch (5-6 yd)</option>
                          <option value="Slant">Slant</option>
                          <option value="Flat">Flat</option>
                          <option value="Out">Out (5 yd)</option>
                          <option value="Drag">Drag/Shallow Cross</option>
                          <option value="Stick">Stick (6 yd)</option>
                        </optgroup>
                        <optgroup label="Intermediate Routes">
                          <option value="In/Dig">In/Dig (10 yd)</option>
                          <option value="Curl">Curl (10 yd)</option>
                          <option value="Comeback">Comeback (12 yd)</option>
                          <option value="Crosser">Deep Cross (12 yd)</option>
                          <option value="Whip">Whip</option>
                          <option value="Angle">Angle</option>
                        </optgroup>
                        <optgroup label="Deep Routes">
                          <option value="Go/Fly">Go/Fly (Vertical)</option>
                          <option value="Post">Post</option>
                          <option value="Corner">Corner</option>
                          <option value="Seam">Seam</option>
                          <option value="Sail">Sail</option>
                        </optgroup>
                        <optgroup label="RB/TE Routes">
                          <option value="Swing">Swing</option>
                          <option value="Wheel">Wheel</option>
                          <option value="Screen">Screen</option>
                          <option value="Check/Release">Check/Release</option>
                        </optgroup>
                        <optgroup label="Blocking">
                          <option value="Blocking">Pass Pro/Block</option>
                        </optgroup>
                      </select>
                    </div>
                    <p className="text-xs text-blue-400 mt-1">Auto-mirrors for right side players</p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-bold mb-1">Alignment (On/Off Ball)</label>
                    <select value={positions.find(p => p.position_id === selectedPos)?.route_details?.alignment || 'on'} onChange={(e) => updateRouteDetails(selectedPos, 'alignment', e.target.value)} className="w-full bg-gray-900 rounded px-3 py-2 text-white text-sm">
                      <option value="on">On the Ball (on LOS)</option>
                      <option value="off">Off the Ball (behind LOS)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-1">Motion Type</label>
                    <select value={positions.find(p => p.position_id === selectedPos)?.motion || 'none'} onChange={(e) => setPositions(positions.map(p => p.position_id === selectedPos ? { ...p, motion: e.target.value } : p))} className="w-full bg-gray-900 rounded px-3 py-2 text-white text-sm">
                      <option value="none">No Motion</option>
                      <option value="jet">Jet Motion (fast across)</option>
                      <option value="orbit">Orbit Motion (behind QB)</option>
                      <option value="shift">Shift (reposition)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-1">Assignment/Steps</label>
                    <textarea value={positions.find(p => p.position_id === selectedPos)?.route_details?.steps || ''} onChange={(e) => updateRouteDetails(selectedPos, 'steps', e.target.value)} placeholder="Route description or blocking assignment" className="w-full bg-gray-900 rounded px-3 py-2 text-white h-16 text-sm" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-sm font-bold mb-1">Landmark</label>
                      <input type="text" value={positions.find(p => p.position_id === selectedPos)?.route_details?.landmark || ''} onChange={(e) => updateRouteDetails(selectedPos, 'landmark', e.target.value)} placeholder="Hash, Numbers, etc" className="w-full bg-gray-900 rounded px-3 py-2 text-white text-sm" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold mb-1">Read Key</label>
                      <input type="text" value={positions.find(p => p.position_id === selectedPos)?.route_details?.read_key || ''} onChange={(e) => updateRouteDetails(selectedPos, 'read_key', e.target.value)} placeholder="Safety, LB, etc" className="w-full bg-gray-900 rounded px-3 py-2 text-white text-sm" />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="relative bg-green-900 rounded cursor-crosshair" style={{ width: fieldWidth, height: fieldHeight }} onClick={handleFieldClick}>
                  <svg width={fieldWidth} height={fieldHeight}>
                    {[...Array(9)].map((_, i) => {
                      const yPos = fieldHeight - (i * (fieldHeight / 8));
                      return <g key={i}><line x1={0} y1={yPos} x2={fieldWidth} y2={yPos} stroke="#fff" strokeWidth="1" opacity="0.3" /><text x={5} y={yPos - 3} fill="#fff" fontSize="10" opacity="0.5">{i * 5}</text></g>;
                    })}
                    <line x1={0} y1={fieldHeight - (2 * fieldHeight / 8)} x2={fieldWidth} y2={fieldHeight - (2 * fieldHeight / 8)} stroke="#ff0" strokeWidth="4" />
                    <g opacity="0.5">{[25, 22, 28, 19, 31].map(x => <circle key={x} cx={toCanvasX(x)} cy={fieldHeight - (2 * fieldHeight / 8)} r="6" fill="#666" stroke="#fff" strokeWidth="1" />)}</g>
                    {positions.map(pos => {
                      const isSelected = pos.position_id === selectedPos;
                      const startX = pos.route_points[0]?.x || 25;
                      const startY = pos.route_points[0]?.y || 5;
                      
                      // Calculate motion path (behind LOS at y=8)
                      let motionPath = null;
                      if (pos.motion && pos.motion !== 'none') {
                        const motionY = 8; // Behind the line of scrimmage
                        if (pos.motion === 'jet') {
                          // Jet motion - fast across behind LOS
                          const motionEndX = startX < 25 ? 40 : 10; // Go to opposite side
                          motionPath = [{x: startX, y: startY}, {x: startX, y: motionY}, {x: motionEndX, y: motionY}];
                        } else if (pos.motion === 'orbit') {
                          // Orbit motion - arc behind QB
                          const motionEndX = startX < 25 ? 30 : 20;
                          motionPath = [{x: startX, y: startY}, {x: startX, y: motionY}, {x: 25, y: 5}, {x: motionEndX, y: motionY}];
                        } else if (pos.motion === 'shift') {
                          // Shift - move to new position behind LOS
                          const motionEndX = startX < 25 ? startX + 8 : startX - 8;
                          motionPath = [{x: startX, y: startY}, {x: motionEndX, y: startY}];
                        }
                      }
                      
                      return (
                        <g key={pos.position_id}>
                          {/* Draw motion path (dashed yellow line behind LOS) */}
                          {motionPath && motionPath.length > 1 && motionPath.map((point, i) => {
                            if (i === 0) return null;
                            const prev = motionPath[i - 1];
                            return (
                              <line 
                                key={`motion-${i}`}
                                x1={toCanvasX(prev.x)} 
                                y1={toCanvasY(prev.y)} 
                                x2={toCanvasX(point.x)} 
                                y2={toCanvasY(point.y)} 
                                stroke="#fbbf24"
                                strokeWidth="3"
                                strokeDasharray="8,4"
                                strokeLinecap="round"
                                opacity="0.8"
                              />
                            );
                          })}
                          {/* Motion arrow at end */}
                          {motionPath && motionPath.length > 1 && (
                            <polygon
                              points={(() => {
                                const last = motionPath[motionPath.length - 1];
                                const prev = motionPath[motionPath.length - 2];
                                const x = toCanvasX(last.x);
                                const y = toCanvasY(last.y);
                                const angle = Math.atan2(toCanvasY(last.y) - toCanvasY(prev.y), toCanvasX(last.x) - toCanvasX(prev.x));
                                return `${x},${y} ${x - 8 * Math.cos(angle - 0.5)},${y - 8 * Math.sin(angle - 0.5)} ${x - 8 * Math.cos(angle + 0.5)},${y - 8 * Math.sin(angle + 0.5)}`;
                              })()}
                              fill="#fbbf24"
                              opacity="0.8"
                            />
                          )}
                          {/* Draw straight line segments for route */}
                          {pos.route_points.map((point, i) => {
                            if (i === 0) return null;
                            const prev = pos.route_points[i - 1];
                            return (
                              <line 
                                key={i} 
                                x1={toCanvasX(prev.x)} 
                                y1={toCanvasY(prev.y)} 
                                x2={toCanvasX(point.x)} 
                                y2={toCanvasY(point.y)} 
                                stroke={isSelected ? "#fbbf24" : "#60a5fa"} 
                                strokeWidth={isSelected ? "4" : "3"} 
                                strokeLinecap="round"
                                opacity={isSelected ? "1" : "0.9"}
                              />
                            );
                          })}
                          {/* Draw arrow at end of route */}
                          {pos.route_points.length > 1 && (
                            <polygon
                              points={(() => {
                                const last = pos.route_points[pos.route_points.length - 1];
                                const prev = pos.route_points[pos.route_points.length - 2];
                                const x = toCanvasX(last.x);
                                const y = toCanvasY(last.y);
                                const angle = Math.atan2(toCanvasY(last.y) - toCanvasY(prev.y), toCanvasX(last.x) - toCanvasX(prev.x));
                                const size = isSelected ? 12 : 10;
                                return `${x},${y} ${x - size * Math.cos(angle - 0.5)},${y - size * Math.sin(angle - 0.5)} ${x - size * Math.cos(angle + 0.5)},${y - size * Math.sin(angle + 0.5)}`;
                              })()}
                              fill={isSelected ? "#fbbf24" : "#60a5fa"}
                              opacity={isSelected ? "1" : "0.9"}
                            />
                          )}
                          {/* Draw starting position circle */}
                          <circle 
                            cx={toCanvasX(pos.route_points[0].x)} 
                            cy={toCanvasY(pos.route_points[0].y)} 
                            r={isSelected ? "12" : "10"} 
                            fill={isSelected ? "#22c55e" : "#3b82f6"} 
                            stroke="#fff" 
                            strokeWidth="3" 
                          />
                          {/* Position label */}
                          <text 
                            x={toCanvasX(pos.route_points[0].x)} 
                            y={toCanvasY(pos.route_points[0].y) - 16} 
                            textAnchor="middle" 
                            fill={isSelected ? "#fbbf24" : "#fff"} 
                            fontSize="12" 
                            fontWeight="bold"
                          >
                            {pos.position_id}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                </div>
              )}
            </div>
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => { 
              // Check for 11 players
              if (positions.length !== 11) { 
                alert(`Invalid play: Must have exactly 11 players on the field. Currently have ${positions.length} players.`); 
                return; 
              }
              // Check for illegal formation (max 4 off the ball)
              const offBallCount = positions.filter(p => p.route_details?.alignment === 'off').length;
              if (offBallCount > 4) {
                alert(`⚠️ ILLEGAL FORMATION!\n\nYou have ${offBallCount} players OFF the ball.\n\nMax allowed: 4 (QB, RB, FB, and 1 receiver)\n\nPlayers currently OFF the ball:\n${positions.filter(p => p.route_details?.alignment === 'off').map(p => '• ' + p.position_id).join('\n')}\n\nFix: Change some players to "On the Ball" in Route Details.`);
                return;
              }
              onSave({ ...play, name, formation, snap_count: snapCount, video_url: videoUrl, positions }); 
            }} className="flex-1 bg-blue-600 py-3 rounded font-bold hover:bg-blue-700">Save</button>
            <button onClick={onCancel} className="flex-1 bg-gray-700 py-3 rounded font-bold hover:bg-gray-600">Cancel</button>
          </div>
          <div className="text-center mt-2">
            <span className={`text-sm font-bold ${positions.length === 11 ? 'text-green-400' : 'text-red-400'}`}>Players on field: {positions.length}/11</span>
          </div>
          </div>
          )}
        </div>
      </div>
    );
  }

  function InstallEditor({ install, onSave, onCancel }) {
    const [name, setName] = useState(install?.name || '');
    const [dueDate, setDueDate] = useState(install?.due_date || '');
    const [selectedPlays, setSelectedPlays] = useState(install?.play_ids || []);
    const [assignedGroup, setAssignedGroup] = useState(install?.group || (unit === 'offense' ? 'Full Offense' : 'Full Defense'));

    const togglePlay = (playId) => {
      if (selectedPlays.includes(playId)) {
        setSelectedPlays(selectedPlays.filter(id => id !== playId));
      } else {
        setSelectedPlays([...selectedPlays, playId]);
      }
    };

    const currentPlays = unit === 'offense' ? plays : defensivePlays;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center p-4 z-50">
        <div className="bg-gray-900 rounded-lg p-6 max-w-2xl w-full">
          <h2 className="text-2xl font-bold mb-4">Create {unit === 'offense' ? 'Offensive' : 'Defensive'} Install</h2>
          <div className="space-y-4">
            <div><label className="block text-sm mb-1">Install Name</label><input type="text" placeholder="Install 1 - Monday" value={name} onChange={(e) => setName(e.target.value)} className="w-full bg-gray-800 rounded px-3 py-2 text-white" /></div>
            <div><label className="block text-sm mb-1">Due Date</label><input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="w-full bg-gray-800 rounded px-3 py-2 text-white" /></div>
            <div><label className="block text-sm mb-1">Position Group</label>
              <select value={assignedGroup} onChange={(e) => setAssignedGroup(e.target.value)} className="w-full bg-gray-800 rounded px-3 py-2 text-white">
                {unit === 'offense' ? (
                  <>
                    <option value="Full Offense">Full Offense</option>
                    <option value="WR Group">WR Group</option>
                    <option value="OL Group">OL Group</option>
                    <option value="Skill Group">Skill Group (QB/RB/WR/TE)</option>
                    <option value="Scout">Scout Team</option>
                  </>
                ) : (
                  <>
                    <option value="Full Defense">Full Defense</option>
                    <option value="DL Group">Defensive Line</option>
                    <option value="LB Group">Linebackers</option>
                    <option value="DB Group">Defensive Backs (CB/S)</option>
                    <option value="Front 7">Front 7 (DL + LB)</option>
                  </>
                )}
              </select>
            </div>
            <div><label className="block text-sm mb-2">Select Plays ({selectedPlays.length})</label>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {currentPlays.map(play => (
                  <div key={play.play_id} onClick={() => togglePlay(play.play_id)} className={`p-3 rounded cursor-pointer ${selectedPlays.includes(play.play_id) ? 'bg-blue-600' : 'bg-gray-800'}`}>
                    <div className="font-bold">{play.name}</div>
                    <div className="text-sm text-gray-400">{unit === 'offense' ? play.formation : `${play.front} - ${play.coverage}`}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => onSave({ install_id: install?.install_id || `install_${Date.now()}`, name, due_date: dueDate, play_ids: selectedPlays, group: assignedGroup, unit })} className="flex-1 bg-blue-600 py-3 rounded font-bold">Save</button>
            <button onClick={onCancel} className="flex-1 bg-gray-700 py-3 rounded font-bold">Cancel</button>
          </div>
        </div>
      </div>
    );
  }

  function PlayLibrary() {
    const imageInputRef = React.useRef(null);
    const [showTemplateLibrary, setShowTemplateLibrary] = useState(false);
    const [templateFilter, setTemplateFilter] = useState('All');
    const [showAIBuilder, setShowAIBuilder] = useState(false);
    const [aiPrompt, setAiPrompt] = useState('');
    const [aiBuilding, setAiBuilding] = useState(false);
    const [pendingImage, setPendingImage] = useState(null); // For image analysis
    const [showImageImportModal, setShowImageImportModal] = useState(false);
    const [analyzing, setAnalyzing] = useState(false);
    const currentPlays = unit === 'offense' ? plays : defensivePlays;
    const setCurrentPlays = unit === 'offense' ? setPlays : setDefensivePlays;

    // Handle image selection - show modal with options
    const handleImageSelect = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = (event) => {
        setPendingImage({
          data: event.target.result,
          name: file.name.replace(/\.[^/.]+$/, '')
        });
        setShowImageImportModal(true);
      };
      reader.readAsDataURL(file);
      e.target.value = '';
    };

    // Import image as simple reference card (no AI)
    const importAsReferenceCard = (playName, personnel = '11') => {
      const personnelGroup = PERSONNEL_GROUPINGS[personnel] || PERSONNEL_GROUPINGS['11'];
      
      if (unit === 'offense') {
        // Create positions based on selected personnel
        const positions = personnelGroup.positions.map(posId => {
          const isOffBall = ['QB', 'RB', 'FB'].includes(posId);
          return {
            position_id: posId,
            position_name: posId,
            route_points: [{ x: 25, y: isOffBall ? 5 : 10 }],
            tags: [],
            motion: 'none',
            route_details: { 
              alignment: isOffBall ? 'off' : 'on',
              steps: '', 
              landmark: '', 
              read_key: ''
            }
          };
        });

        const newPlay = {
          play_id: `play_${Date.now()}`,
          name: playName || 'Imported Play',
          formation: personnelGroup.name,
          snap_count: 'On 1',
          version: 1,
          updated: false,
          video_url: '',
          image_url: pendingImage.data,
          positions: positions
        };
        setPlays([...plays, newPlay]);
      } else {
        const newPlay = {
          play_id: `def_play_${Date.now()}`,
          name: playName || 'Imported Defense',
          front: 'Imported',
          coverage: 'See Image',
          snap_count: 'On movement',
          version: 1,
          updated: false,
          video_url: '',
          image_url: pendingImage.data,
          positions: [
            { position_id: 'DE_L', position_name: 'Left DE', alignment: '', responsibility: '', read_key: '' },
            { position_id: 'DT_L', position_name: 'Left DT', alignment: '', responsibility: '', read_key: '' },
            { position_id: 'DT_R', position_name: 'Right DT', alignment: '', responsibility: '', read_key: '' },
            { position_id: 'DE_R', position_name: 'Right DE', alignment: '', responsibility: '', read_key: '' },
            { position_id: 'SAM', position_name: 'SAM LB', alignment: '', responsibility: '', read_key: '' },
            { position_id: 'MIKE', position_name: 'MIKE LB', alignment: '', responsibility: '', read_key: '' },
            { position_id: 'WILL', position_name: 'WILL LB', alignment: '', responsibility: '', read_key: '' },
            { position_id: 'CB_L', position_name: 'Left CB', alignment: '', responsibility: '', read_key: '' },
            { position_id: 'CB_R', position_name: 'Right CB', alignment: '', responsibility: '', read_key: '' },
            { position_id: 'SS', position_name: 'Strong Safety', alignment: '', responsibility: '', read_key: '' },
            { position_id: 'FS', position_name: 'Free Safety', alignment: '', responsibility: '', read_key: '' }
          ]
        };
        setDefensivePlays([...defensivePlays, newPlay]);
      }
      setPendingImage(null);
      setShowImageImportModal(false);
      alert(`✅ Play imported with ${personnelGroup.name}!\n\nClick EDIT to add each position's assignment.`);
    };

    // AI Analyze the image and generate play data
    const analyzeImageWithAI = async (playName) => {
      setAnalyzing(true);
      try {
        const systemPrompt = unit === 'offense'
          ? `You are an expert football coach analyzing a play diagram image. Extract the play information and return ONLY valid JSON.

Look at the image carefully and identify:
1. The formation (Spread, Shotgun, I-Formation, etc.)
2. All 11 player positions - look for circles, squares, or letters representing players
3. Route paths shown by lines/arrows - trace each route from start to finish

COORDINATE SYSTEM (CRITICAL):
- x: 0 = left sideline, 25 = center of field, 50 = right sideline
- y: 0 = deep backfield, 10 = line of scrimmage, 40 = 30 yards downfield
- The LINE OF SCRIMMAGE is at y=10

TYPICAL STARTING POSITIONS:
- WR_X (split end left): x=5, y=10
- WR_Z (flanker right): x=45, y=9 (slightly off ball)
- WR_Y (slot): x=15, y=9
- TE: x=32-35, y=10 (on the line)
- O-Line: x=19,22,25,28,31 all at y=10
- QB: x=25, y=5
- RB: x=25, y=2

Return this EXACT JSON structure:
{
  "name": "Play Name",
  "formation": "Spread",
  "positions": [
    {"position_id": "WR_X", "route_points": [{"x": 5, "y": 10}, {"x": 5, "y": 20}, {"x": 10, "y": 25}], "motion": "none", "route_details": {"alignment": "on", "steps": "1. Release vertical\\n2. Break in at 10", "landmark": "Hash marks", "read_key": "Safety", "coaching_point": "Sell vertical"}},
    {"position_id": "QB", "route_points": [{"x": 25, "y": 5}, {"x": 25, "y": 8}], "motion": "none", "route_details": {"alignment": "off", "steps": "5 step drop", "landmark": "7 yards", "read_key": "Coverage", "coaching_point": "Read progression"}}
  ]
}

IMPORTANT:
- route_points MUST be an array of {x, y} objects
- First point is where player lines up, subsequent points trace the route
- alignment: "on" = on line of scrimmage, "off" = in backfield
- Include ALL 11 positions even if route is just their starting spot`
          : `You are an expert football coach analyzing a defensive play diagram. Extract the defense information and return ONLY valid JSON.

Look at the image and identify:
1. The defensive front (4-3, 3-4, Nickel, etc.)
2. The coverage (Cover 1, 2, 3, 4, Man, Zone)
3. All 11 defender positions and their assignments

Return this EXACT JSON structure:
{
  "name": "Defense Name",
  "front": "4-3|3-4|Nickel|Dime",
  "coverage": "Cover 0|Cover 1|Cover 2|Cover 3|Cover 4",
  "positions": [
    {"position_id": "CB_L", "position_name": "Left CB", "alignment": "7 yards off #1", "responsibility": "Deep 1/3 zone", "read_key": "#1 to #2", "coaching_point": "Eyes on QB, break on throw"}
  ]
}

Position IDs: DE_L, DT_L, DT_R, DE_R, SAM, MIKE, WILL, CB_L, CB_R, SS, FS`;

        const response = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: 'claude-sonnet-4-20250514',
            max_tokens: 4000,
            system: systemPrompt,
            messages: [{
              role: 'user',
              content: [
                {
                  type: 'image',
                  source: {
                    type: 'base64',
                    media_type: pendingImage.data.split(';')[0].split(':')[1],
                    data: pendingImage.data.split(',')[1]
                  }
                },
                {
                  type: 'text',
                  text: `Analyze this ${unit} play diagram and extract all player assignments. The play should be named "${playName || 'Analyzed Play'}".`
                }
              ]
            }]
          })
        });

        const data = await response.json();
        
        if (data.error) {
          throw new Error(data.error.message || 'API error');
        }

        const responseText = data.content?.[0]?.text || '';
        const jsonMatch = responseText.match(/\{[\s\S]*\}/);
        
        if (jsonMatch) {
          const playData = JSON.parse(jsonMatch[0]);
          
          if (unit === 'offense') {
            const newPlay = {
              play_id: `play_${Date.now()}`,
              name: playData.name || playName || 'AI Analyzed Play',
              formation: playData.formation || 'Spread',
              snap_count: 'On 1',
              version: 1,
              updated: false,
              video_url: '',
              image_url: pendingImage.data, // Keep image as reference
              positions: ensureElevenOffensivePositions(playData.positions || [])
            };
            setPlays([...plays, newPlay]);
          } else {
            const newPlay = {
              play_id: `def_play_${Date.now()}`,
              name: playData.name || playName || 'AI Analyzed Defense',
              front: playData.front || '4-3',
              coverage: playData.coverage || 'Cover 3',
              snap_count: 'On movement',
              version: 1,
              updated: false,
              video_url: '',
              image_url: pendingImage.data,
              positions: ensureElevenDefensivePositions(playData.positions || [])
            };
            setDefensivePlays([...defensivePlays, newPlay]);
          }
          
          setPendingImage(null);
          setShowImageImportModal(false);
          alert(`✅ AI analyzed the image and created "${playData.name || playName}"! Review and edit as needed.`);
        } else {
          throw new Error('Could not parse AI response');
        }
      } catch (error) {
        console.error('Image analysis error:', error);
        alert(`⚠️ AI analysis failed: ${error.message}\n\nYou can still import as a reference card.`);
      } finally {
        setAnalyzing(false);
      }
    };

    const handleDeletePlay = (playId, playName) => {
      setConfirmDialog({
        message: `Are you sure you want to delete "${playName}"?`,
        onConfirm: () => {
          setCurrentPlays(currentPlays.filter(p => p.play_id !== playId));
          setConfirmDialog(null);
        },
        onCancel: () => setConfirmDialog(null)
      });
    };

    // Helper function to ensure offensive plays have all 11 positions
    const ensureElevenOffensivePositions = (positions) => {
      const defaultOffensivePositions = {
        'WR_X': { x: 5, y: 10, name: 'Split End', route: 'Vertical/Block' },
        'WR_Z': { x: 45, y: 10, name: 'Flanker', route: 'Vertical/Block' },
        'WR_Y': { x: 15, y: 9, name: 'Slot', route: 'Route/Block' },
        'TE': { x: 35, y: 9, name: 'Tight End', route: 'Route/Block' },
        'LT': { x: 19, y: 10, name: 'Left Tackle', route: 'Pass Pro/Run Block' },
        'LG': { x: 22, y: 10, name: 'Left Guard', route: 'Pass Pro/Run Block' },
        'C': { x: 25, y: 10, name: 'Center', route: 'Pass Pro/Run Block' },
        'RG': { x: 28, y: 10, name: 'Right Guard', route: 'Pass Pro/Run Block' },
        'RT': { x: 31, y: 10, name: 'Right Tackle', route: 'Pass Pro/Run Block' },
        'QB': { x: 25, y: 5, name: 'Quarterback', route: 'Drop/Handoff' },
        'RB': { x: 25, y: 0, name: 'Running Back', route: 'Run/Pass Pro/Route' }
      };

      // Helper to validate and fix route points
      const fixRoutePoints = (points, posId) => {
        const defaults = defaultOffensivePositions[posId] || { x: 25, y: 10 };
        
        // If no points or invalid, use default
        if (!points || !Array.isArray(points) || points.length === 0) {
          return [{ x: defaults.x, y: defaults.y }];
        }
        
        // Validate and fix each point
        return points.map((pt, i) => {
          // Handle various AI response formats
          let x = pt.x ?? pt.X ?? pt[0] ?? defaults.x;
          let y = pt.y ?? pt.Y ?? pt[1] ?? defaults.y;
          
          // Ensure numbers
          x = typeof x === 'number' ? x : parseFloat(x) || defaults.x;
          y = typeof y === 'number' ? y : parseFloat(y) || defaults.y;
          
          // Clamp to field boundaries
          x = Math.max(0, Math.min(50, Math.round(x)));
          y = Math.max(0, Math.min(40, Math.round(y)));
          
          return { x, y };
        });
      };

      // Helper to determine default alignment
      const getDefaultAlignment = (posId) => {
        const offBallPositions = ['QB', 'RB', 'FB', 'WR_Y', 'WR_Z'];
        return offBallPositions.includes(posId) ? 'off' : 'on';
      };

      const existingIds = new Set(positions.map(p => p.position_id));
      const result = positions.map(pos => {
        const posId = pos.position_id || 'UNKNOWN';
        const defaults = defaultOffensivePositions[posId];
        
        return {
          position_id: posId,
          position_name: pos.position_name || defaults?.name || posId,
          route_points: fixRoutePoints(pos.route_points, posId),
          tags: pos.tags || [],
          motion: pos.motion || 'none',
          route_details: {
            alignment: pos.route_details?.alignment || getDefaultAlignment(posId),
            steps: pos.route_details?.steps || pos.steps || defaults?.route || '',
            landmark: pos.route_details?.landmark || pos.landmark || '',
            read_key: pos.route_details?.read_key || pos.read_key || '',
            coaching_point: pos.route_details?.coaching_point || pos.coaching_point || ''
          }
        };
      });

      // Add missing positions with defaults
      Object.entries(defaultOffensivePositions).forEach(([posId, defaults]) => {
        if (!existingIds.has(posId)) {
          result.push({
            position_id: posId,
            position_name: defaults.name,
            route_points: [{ x: defaults.x, y: defaults.y }],
            tags: [],
            motion: 'none',
            route_details: { 
              alignment: getDefaultAlignment(posId),
              steps: defaults.route, 
              landmark: '', 
              read_key: '', 
              coaching_point: 'Assignment needed' 
            }
          });
        }
      });

      return result.slice(0, 11); // Ensure max 11
    };

    // Helper function to ensure defensive plays have all 11 positions
    const ensureElevenDefensivePositions = (positions) => {
      const default43Positions = {
        'DE_L': { name: 'Left DE', alignment: '5 tech', responsibility: 'C gap/Contain', read_key: 'Tackle', coaching_point: 'Set edge' },
        'DT_L': { name: 'Left DT', alignment: '3 tech', responsibility: 'B gap', read_key: 'Guard', coaching_point: 'Penetrate' },
        'DT_R': { name: 'Right DT', alignment: '1 tech', responsibility: 'A gap', read_key: 'Center', coaching_point: 'Anchor' },
        'DE_R': { name: 'Right DE', alignment: '5 tech', responsibility: 'C gap', read_key: 'TE', coaching_point: 'Read run/pass' },
        'SAM': { name: 'SAM LB', alignment: 'Apex strong', responsibility: 'Curl/Flat', read_key: '#2 receiver', coaching_point: 'Collision TE' },
        'MIKE': { name: 'MIKE LB', alignment: 'Middle', responsibility: 'Hook/Run fit', read_key: 'Guards', coaching_point: 'Flow to ball' },
        'WILL': { name: 'WILL LB', alignment: 'Apex weak', responsibility: 'Curl/Flat', read_key: '#2 receiver', coaching_point: 'Fast flow' },
        'CB_L': { name: 'Left CB', alignment: 'Outside #1', responsibility: 'Coverage', read_key: '#1 receiver', coaching_point: 'Eyes on receiver, stay in phase' },
        'CB_R': { name: 'Right CB', alignment: 'Outside #1', responsibility: 'Coverage', read_key: '#1 receiver', coaching_point: 'Maintain leverage, trust help' },
        'SS': { name: 'Strong Safety', alignment: 'Box/Deep', responsibility: 'Run support/Coverage', read_key: 'Run/Pass key', coaching_point: 'Read keys' },
        'FS': { name: 'Free Safety', alignment: 'Centerfield', responsibility: 'Deep coverage', read_key: 'QB eyes', coaching_point: 'Range' }
      };

      const existingIds = new Set(positions.map(p => p.position_id));
      const result = [...positions];

      // Add missing positions
      Object.entries(default43Positions).forEach(([posId, defaults]) => {
        if (!existingIds.has(posId)) {
          result.push({
            position_id: posId,
            position_name: defaults.name,
            alignment: defaults.alignment,
            responsibility: defaults.responsibility,
            read_key: defaults.read_key,
            coaching_point: defaults.coaching_point
          });
        }
      });

      return result.slice(0, 11); // Ensure max 11
    };


    // AI Play Builder - generates plays from natural language descriptions
    const buildPlayWithAI = async () => {
      if (!aiPrompt.trim()) {
        alert('Please enter a play concept or description');
        return;
      }
      
      setAiBuilding(true);
      
      try {
        const systemPrompt = unit === 'offense' 
          ? `You are an expert football offensive coordinator. Generate a complete offensive play based on the user's description.

CRITICAL RULES:
1. You MUST return EXACTLY 11 offensive positions
2. Use these EXACT position IDs: WR_X, WR_Z, WR_Y, TE, LT, LG, C, RG, RT, QB, RB
3. Include realistic route_points (x: 0-50, y: 0-40, LOS at y=10)
4. Provide detailed coaching points for each position
5. Return ONLY valid JSON, no markdown or explanation

Standard starting positions:
- WR_X (split end): x=5, y=10
- WR_Z (flanker): x=45, y=10  
- WR_Y (slot): x=15, y=9
- TE: x=33, y=10
- LT: x=19, y=10
- LG: x=22, y=10
- C: x=25, y=10
- RG: x=28, y=10
- RT: x=31, y=10
- QB: x=25, y=5 (shotgun) or x=25, y=3 (under center)
- RB: x=25, y=0 or x=20, y=5

For routes, add intermediate and end points showing the path.
For blocking, just use the starting position.

Return this EXACT JSON structure:
{
  "name": "Play Name",
  "formation": "Spread|Shotgun|I-Formation|Empty",
  "snap_count": "On 1",
  "positions": [
    {
      "position_id": "WR_X",
      "route_points": [{"x": 5, "y": 10}, {"x": 5, "y": 25}],
      "motion": "none",
      "route_details": {
        "steps": "Vertical release, stem to 12, break post",
        "landmark": "Far hash",
        "read_key": "Safety",
        "coaching_point": "Sell vertical before breaking"
      }
    }
    // ... all 11 positions
  ]
}`
          : `You are an expert football defensive coordinator. Generate a complete defensive play based on the user's description.

CRITICAL RULES:
1. You MUST return EXACTLY 11 defensive positions
2. Use appropriate position IDs based on the scheme:
   - 4-3: DE_L, DT_L, DT_R, DE_R, SAM, MIKE, WILL, CB_L, CB_R, SS, FS
   - 3-4: DE_L, NT, DE_R, OLB_L, ILB_L, ILB_R, OLB_R, CB_L, CB_R, SS, FS
   - Nickel: DE_L, DT_L, DT_R, DE_R, MIKE, WILL, NB, CB_L, CB_R, SS, FS
3. Provide detailed alignments, responsibilities, and coaching points
4. Return ONLY valid JSON, no markdown or explanation

Return this EXACT JSON structure:
{
  "name": "Defense Name",
  "front": "4-3|3-4|Nickel|Dime",
  "coverage": "Cover 0|Cover 1|Cover 2|Cover 3|Cover 4|Man|Zone",
  "snap_count": "On movement",
  "positions": [
    {
      "position_id": "CB_L",
      "position_name": "Left Cornerback",
      "alignment": "7 yards off #1",
      "responsibility": "Deep 1/3 zone",
      "read_key": "#1 receiver",
      "coaching_point": "Bail at snap, maintain leverage"
    }
    // ... all 11 positions
  ]
}`;

        const response = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: 'claude-sonnet-4-20250514',
            max_tokens: 4000,
            messages: [
              { role: 'user', content: `Create a ${unit} play: ${aiPrompt}` }
            ],
            system: systemPrompt
          })
        });

        const data = await response.json();
        const responseText = data.content?.[0]?.text || '';
        
        // Parse the JSON response
        const jsonMatch = responseText.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const playData = JSON.parse(jsonMatch[0]);
          
          if (unit === 'offense') {
            const newPlay = {
              play_id: `play_${Date.now()}`,
              name: playData.name || 'AI Generated Play',
              formation: playData.formation || 'Spread',
              snap_count: playData.snap_count || 'On 1',
              version: 1,
              updated: false,
              video_url: '',
              positions: ensureElevenOffensivePositions(playData.positions || [])
            };
            setPlays([...plays, newPlay]);
            alert(`✅ Created "${newPlay.name}" with all 11 positions!`);
          } else {
            const newPlay = {
              play_id: `def_play_${Date.now()}`,
              name: playData.name || 'AI Generated Defense',
              front: playData.front || '4-3',
              coverage: playData.coverage || 'Cover 3',
              snap_count: playData.snap_count || 'On movement',
              version: 1,
              updated: false,
              video_url: '',
              positions: ensureElevenDefensivePositions(playData.positions || [])
            };
            setDefensivePlays([...defensivePlays, newPlay]);
            alert(`✅ Created "${newPlay.name}" with all 11 positions!`);
          }
          
          setShowAIBuilder(false);
          setAiPrompt('');
        } else {
          throw new Error('Could not parse AI response');
        }
      } catch (error) {
        console.error('AI Build error:', error);
        alert('Error building play. Please try again with a different description.');
      } finally {
        setAiBuilding(false);
      }
    };


    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">{unit === 'offense' ? 'Offensive' : 'Defensive'} Plays</h2>
          <div className="flex gap-2">
            <button 
              onClick={() => setShowTemplateLibrary(true)}
              className="bg-purple-600 px-4 py-2 rounded flex items-center gap-2 hover:bg-purple-700"
            >
              <Plus size={20} /> Play Library
            </button>
            <button 
              onClick={() => imageInputRef.current?.click()} 
              className="bg-green-600 px-4 py-2 rounded flex items-center gap-2 hover:bg-green-700"
            >
              <Plus size={20} /> Import Image
            </button>

            {unit === 'offense' && (
              <button onClick={() => setEditingPlay({ play_id: `play_${Date.now()}`, name: 'New Play', formation: '', snap_count: 'On 1', video_url: '', positions: [] })} className="bg-blue-600 px-4 py-2 rounded flex items-center gap-2 hover:bg-blue-700">
                <Plus size={20} /> Create
              </button>
            )}
            <button 
              onClick={() => setShowAIBuilder(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 px-4 py-2 rounded flex items-center gap-2 hover:from-purple-700 hover:to-pink-700"
            >
              <Zap size={20} /> AI Build
            </button>
          </div>
        </div>

        {/* Play Template Library Modal */}
        {showTemplateLibrary && (
          <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4" style={{overflow: 'auto'}}>
            <div className="bg-gray-900 rounded-xl w-full max-w-4xl flex flex-col" style={{maxHeight: '85vh'}}>
              <div className="p-4 border-b border-gray-700 flex justify-between items-center flex-shrink-0">
                <h2 className="text-xl font-bold">📚 {unit === 'offense' ? 'Offensive' : 'Defensive'} Play Library</h2>
                <button onClick={() => setShowTemplateLibrary(false)} className="text-gray-400 hover:text-white text-2xl">&times;</button>
              </div>
              
              {/* Category Filter */}
              <div className="p-4 border-b border-gray-700 flex gap-2 flex-wrap flex-shrink-0">
                {unit === 'offense' ? (
                  <>
                    {['All', 'Passing', 'Run', 'RPO', 'Screen', 'Play Action'].map(cat => (
                      <button key={cat} onClick={() => setTemplateFilter(cat)} className={`px-3 py-1 rounded-full text-sm font-bold ${templateFilter === cat ? 'bg-blue-600' : 'bg-gray-700 hover:bg-gray-600'}`}>{cat}</button>
                    ))}
                  </>
                ) : (
                  <>
                    {['All', 'Zone', 'Man', 'Blitz'].map(cat => (
                      <button key={cat} onClick={() => setTemplateFilter(cat)} className={`px-3 py-1 rounded-full text-sm font-bold ${templateFilter === cat ? 'bg-red-600' : 'bg-gray-700 hover:bg-gray-600'}`}>{cat}</button>
                    ))}
                  </>
                )}
              </div>
              
              {/* Play Templates List - Scrollable */}
              <div className="p-4 space-y-3" style={{overflowY: 'auto', flexGrow: 1}}>
                {unit === 'offense' ? (
                  Object.entries(PLAY_TEMPLATES)
                    .filter(([_, play]) => templateFilter === 'All' || play.category === templateFilter)
                    .map(([name, template]) => (
                      <div key={name} className="bg-gray-800 p-4 rounded-lg flex justify-between items-center">
                        <div>
                          <h3 className="font-bold text-lg">{name}</h3>
                          <p className="text-sm text-gray-400">{template.formation} • {template.category}</p>
                          <p className="text-xs text-gray-500 mt-1">{template.description}</p>
                        </div>
                        <button
                          onClick={() => {
                            const newPlay = {
                              play_id: `play_${Date.now()}`,
                              name: name,
                              formation: template.formation,
                              snap_count: 'On 1',
                              version: 1,
                              updated: false,
                              video_url: '',
                              positions: template.positions.map(p => ({
                                ...p,
                                position_name: p.position_id,
                                tags: [],
                                motion: p.motion || 'none'
                              }))
                            };
                            setPlays([...plays, newPlay]);
                            setShowTemplateLibrary(false);
                            alert(`✅ Added "${name}" to your playbook!`);
                          }}
                          className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded font-bold"
                        >
                          + Add
                        </button>
                      </div>
                    ))
                ) : (
                  Object.entries(DEFENSIVE_TEMPLATES)
                    .filter(([_, play]) => templateFilter === 'All' || play.category === templateFilter)
                    .map(([name, template]) => (
                      <div key={name} className="bg-gray-800 p-4 rounded-lg flex justify-between items-center">
                        <div>
                          <h3 className="font-bold text-lg">{name}</h3>
                          <p className="text-sm text-gray-400">{template.front} • {template.coverage}</p>
                          <p className="text-xs text-gray-500 mt-1">{template.description}</p>
                        </div>
                        <button
                          onClick={() => {
                            const newPlay = {
                              play_id: `def_play_${Date.now()}`,
                              name: name,
                              front: template.front,
                              coverage: template.coverage,
                              snap_count: 'On movement',
                              version: 1,
                              updated: false,
                              video_url: '',
                              positions: template.positions
                            };
                            setDefensivePlays([...defensivePlays, newPlay]);
                            setShowTemplateLibrary(false);
                            alert(`✅ Added "${name}" to your playbook!`);
                          }}
                          className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded font-bold"
                        >
                          + Add
                        </button>
                      </div>
                    ))
                )}
              </div>
              
              <div className="p-4 border-t border-gray-700 text-center text-gray-400 text-sm">
                {unit === 'offense' ? Object.keys(PLAY_TEMPLATES).length : Object.keys(DEFENSIVE_TEMPLATES).length} plays available • All plays include 11 players with full assignments
              </div>
            </div>
          </div>
        )}
        
        {/* AI Play Builder Modal */}
        {showAIBuilder && (
          <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center p-4 z-50">
            <div className="bg-gray-900 rounded-lg p-6 max-w-2xl w-full">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h2 className="text-2xl font-bold flex items-center gap-2">
                    <Zap className="text-yellow-400" /> AI Play Builder
                  </h2>
                  <p className="text-gray-400 text-sm mt-1">Describe a {unit === 'offense' ? 'play concept' : 'defensive scheme'} and AI will build it for you</p>
                </div>
                <button onClick={() => setShowAIBuilder(false)} className="text-gray-400 hover:text-white">
                  <X size={24} />
                </button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold mb-2">
                    {unit === 'offense' ? 'Describe the play concept:' : 'Describe the defensive scheme:'}
                  </label>
                  <textarea
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    placeholder={unit === 'offense' 
                      ? "Examples:\n• Mesh concept from spread\n• Four verticals with RB checkdown\n• Inside zone with RPO slant\n• Smash concept vs Cover 2\n• Power run to the right"
                      : "Examples:\n• Cover 3 with strong safety walked up\n• Nickel blitz from the edge\n• Tampa 2 zone coverage\n• Cover 1 Robber\n• 3-4 Bear front"
                    }
                    className="w-full bg-gray-800 rounded-lg px-4 py-3 text-white h-40 resize-none"
                  />
                </div>
                
                <div className="bg-gray-800 rounded-lg p-4">
                  <h3 className="font-bold text-sm mb-2 text-purple-400">💡 Tips for better results:</h3>
                  <ul className="text-sm text-gray-400 space-y-1">
                    {unit === 'offense' ? (
                      <>
                        <li>• Include the formation: "from spread", "from shotgun", "from I-formation"</li>
                        <li>• Name specific routes: "post corner", "curl flat", "mesh crossing"</li>
                        <li>• Specify run schemes: "inside zone", "power", "counter"</li>
                        <li>• Add context: "vs Cover 2", "goal line", "with motion"</li>
                      </>
                    ) : (
                      <>
                        <li>• Specify the front: "4-3", "3-4", "nickel", "dime"</li>
                        <li>• Name the coverage: "Cover 3", "Cover 2 man", "quarters"</li>
                        <li>• Include blitz info: "Mike blitz", "edge pressure", "zone blitz"</li>
                        <li>• Add technique: "press corners", "soft coverage", "pattern match"</li>
                      </>
                    )}
                  </ul>
                </div>
                
                <div className="flex gap-3">
                  <button 
                    onClick={buildPlayWithAI}
                    disabled={aiBuilding || !aiPrompt.trim()}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 py-3 rounded-lg font-bold flex items-center justify-center gap-2 hover:from-purple-700 hover:to-pink-700 disabled:opacity-50"
                  >
                    {aiBuilding ? (
                      <>
                        <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
                        Building Play...
                      </>
                    ) : (
                      <>
                        <Zap size={20} /> Generate Play
                      </>
                    )}
                  </button>
                  <button 
                    onClick={() => setShowAIBuilder(false)}
                    className="px-6 bg-gray-700 py-3 rounded-lg font-bold hover:bg-gray-600"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Hidden image input */}
        <input 
          ref={imageInputRef} 
          type="file" 
          accept="image/*,.png,.jpg,.jpeg,.gif,.webp" 
          onChange={handleImageSelect} 
          className="hidden" 
        />

        {/* Image Import Modal - Choose AI analyze or simple import */}
        {showImageImportModal && pendingImage && (
          <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center p-4 z-50">
            <div className="bg-gray-900 rounded-lg p-6 max-w-2xl w-full">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">📸 Import Play Image</h2>
                <button onClick={() => { setShowImageImportModal(false); setPendingImage(null); }} className="text-gray-400 hover:text-white text-2xl">&times;</button>
              </div>
              
              {/* Image Preview */}
              <div className="mb-4 bg-gray-800 rounded-lg p-2 flex justify-center">
                <img src={pendingImage.data} alt="Play diagram" className="max-h-48 rounded" />
              </div>
              
              {/* Play Name Input */}
              <div className="mb-3">
                <label className="block text-sm font-bold mb-1">Play Name:</label>
                <input 
                  type="text" 
                  defaultValue={pendingImage.name}
                  id="importPlayName"
                  className="w-full bg-gray-800 rounded px-4 py-2 text-white"
                  placeholder="Enter play name..."
                />
              </div>

              {/* Personnel Selection */}
              <div className="mb-4">
                <label className="block text-sm font-bold mb-1">Personnel Grouping:</label>
                <select 
                  id="importPersonnel"
                  className="w-full bg-gray-800 rounded px-4 py-2 text-white"
                  defaultValue="22"
                >
                  {Object.entries(PERSONNEL_GROUPINGS).map(([key, val]) => (
                    <option key={key} value={key}>{val.name}</option>
                  ))}
                </select>
                <p className="text-xs text-gray-500 mt-1">Select the personnel that matches your play diagram</p>
              </div>
              
              {/* Import Options */}
              <div className="space-y-3">
                {/* RECOMMENDED: Import as image card */}
                <div className="bg-green-900 border-2 border-green-500 rounded-lg p-4">
                  <button
                    onClick={() => {
                      const name = document.getElementById('importPlayName').value;
                      const personnel = document.getElementById('importPersonnel').value;
                      importAsReferenceCard(name, personnel);
                    }}
                    disabled={analyzing}
                    className="w-full bg-green-600 py-3 rounded-lg font-bold hover:bg-green-700 disabled:opacity-50 text-lg"
                  >
                    📋 Import Play Card
                  </button>
                  <p className="text-xs text-green-200 text-center mt-2">
                    Import image, then add each position's assignment
                  </p>
                </div>
                
                <div className="text-center text-gray-500 text-sm">— or —</div>
                
                {/* AI Analysis option */}
                <div className="bg-gray-800 rounded-lg p-4">
                  <button
                    onClick={() => {
                      const name = document.getElementById('importPlayName').value;
                      analyzeImageWithAI(name);
                    }}
                    disabled={analyzing}
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 py-3 rounded-lg font-bold flex items-center justify-center gap-2 hover:from-purple-700 hover:to-pink-700 disabled:opacity-50"
                  >
                    {analyzing ? (
                      <>
                        <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
                        Analyzing with AI...
                      </>
                    ) : (
                      <>
                        <Zap size={20} /> AI Auto-Extract (Experimental)
                      </>
                    )}
                  </button>
                  <p className="text-xs text-gray-400 text-center mt-2">
                    AI attempts to read routes from image. Results vary.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Import Info Banner */}
        <div className={`${unit === 'offense' ? 'bg-blue-900 border-blue-600' : 'bg-red-900 border-red-600'} border p-3 rounded-lg text-sm`}>
          <strong>📸 Import Images:</strong> Upload play diagrams from other apps (Hudl, Football Play Card, etc.) as reference cards. Use <strong>⚡ AI Build</strong> to create plays from text descriptions like "Mesh concept" or "Cover 3 blitz".
        </div>
        <div className="space-y-3">
          {currentPlays.map(play => (
            <div key={play.play_id} className="bg-gray-800 p-4 rounded-lg flex justify-between items-center">
              <div className="flex items-center gap-4">
                {/* Show thumbnail if play has reference image */}
                {play.image_url && (
                  <img src={play.image_url} alt="" className="w-16 h-12 object-cover rounded border border-gray-600" />
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold">{play.name}</h3>
                    {play.updated && <span className="text-xs bg-yellow-600 px-2 py-1 rounded font-bold">UPDATED</span>}
                    {play.video_url && <span className="text-xs bg-blue-600 px-2 py-1 rounded font-bold">📹 VIDEO</span>}
                    {play.image_url && <span className="text-xs bg-green-600 px-2 py-1 rounded font-bold">📸 IMG</span>}
                  </div>
                  <p className="text-sm text-gray-400">{unit === 'offense' ? `${play.formation} • v${play.version || 1}` : `${play.front} - ${play.coverage}`}</p>
                </div>
              </div>
              <div className="flex gap-2">
                {unit === 'offense' && (
                  <>
                    <button onClick={() => setEditingPlay(play)} className="p-2 bg-gray-700 rounded hover:bg-gray-600"><Edit2 size={18} /></button>
                    <button type="button" onClick={() => handleDeletePlay(play.play_id, play.name)} className="p-2 bg-red-600 rounded hover:bg-red-700"><Trash2 size={18} /></button>
                  </>
                )}
                {unit === 'defense' && (
                  <>
                    <button onClick={() => setViewingDefensivePlay(play)} className="px-4 py-2 bg-blue-600 rounded hover:bg-blue-700 font-bold">View</button>
                    <button type="button" onClick={() => handleDeletePlay(play.play_id, play.name)} className="p-2 bg-red-600 rounded hover:bg-red-700"><Trash2 size={18} /></button>
                  </>
                )}
              </div>
            </div>
          ))}
          {currentPlays.length === 0 && <p className="text-gray-400 text-center py-8">No {unit === 'offense' ? 'offensive' : 'defensive'} plays yet!</p>}
        </div>
      </div>
    );
  }

  function InstallsView() {
    const getInstallReadiness = (install) => {
      const relevantPlayers = players.filter(p => {
        if (install.group === 'Full Offense') return true;
        if (install.group === 'WR Group') return ['WR_X', 'WR_Z', 'WR_Y'].includes(p.position);
        if (install.group === 'OL Group') return ['LT', 'LG', 'C', 'RG', 'RT'].includes(p.position);
        if (install.group === 'Skill Group') return ['QB', 'RB', 'WR_X', 'WR_Z', 'WR_Y', 'TE'].includes(p.position);
        return true;
      }).filter(player => {
        const playerPlays = install.play_ids.map(id => plays.find(p => p.play_id === id)).filter(p => p && p.positions.find(pos => pos.position_id === player.position));
        return playerPlays.length > 0;
      });

      const reviewedCount = relevantPlayers.filter(player => {
        const playerPlays = install.play_ids.map(id => plays.find(p => p.play_id === id)).filter(p => p && p.positions.find(pos => pos.position_id === player.position));
        return playerPlays.every(play => {
          const progress = playerProgress[player.player_id]?.[play.play_id];
          return progress?.viewed && progress?.version >= (play.version || 1);
        });
      }).length;

      return { total: relevantPlayers.length, reviewed: reviewedCount, pct: relevantPlayers.length > 0 ? Math.round((reviewedCount / relevantPlayers.length) * 100) : 0 };
    };

    const handleDeleteInstall = (installId) => {
      setConfirmDialog({
        message: `Are you sure you want to delete this install?`,
        onConfirm: () => {
          setInstalls(installs.filter(i => i.install_id !== installId));
          setConfirmDialog(null);
        },
        onCancel: () => setConfirmDialog(null)
      });
    };

    return (
      <div className="space-y-4">
        <div className="flex justify-between">
          <h2 className="text-2xl font-bold">Install Periods</h2>
          <button onClick={() => setEditingInstall({})} className="bg-blue-600 px-4 py-2 rounded flex items-center gap-2"><Calendar size={20} /> Create Install</button>
        </div>
        <div className="space-y-3">
          {installs.map(install => {
            const readiness = getInstallReadiness(install);
            return (
              <div key={install.install_id} className="bg-gray-800 p-4 rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="text-lg font-bold">{install.name}</h3>
                    <p className="text-sm text-gray-400">Due: {install.due_date} • {install.group} • {install.play_ids.length} plays</p>
                  </div>
                  <button onClick={() => handleDeleteInstall(install.install_id)} className="p-2 bg-red-600 rounded hover:bg-red-700"><Trash2 size={18} /></button>
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-bold">Readiness: {readiness.pct}%</span>
                    <span className="text-sm text-gray-400">{readiness.reviewed}/{readiness.total} players</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-3">
                    <div className="bg-blue-600 h-3 rounded-full" style={{ width: `${readiness.pct}%` }}></div>
                  </div>
                </div>
              </div>
            );
          })}
          {installs.length === 0 && <p className="text-gray-400 text-center py-8">No installs yet - create one to assign plays to players!</p>}
        </div>
      </div>
    );
  }

  function RosterView() {
    const [newPlayer, setNewPlayer] = useState({ name: '', jersey: '', position: 'QB', unit: 'offense', depth: 1 });
    const [rosterUnit, setRosterUnit] = useState('offense'); // 'offense' or 'defense'
    const [editingPlayer, setEditingPlayer] = useState(null);
    const [showBulkImport, setShowBulkImport] = useState(false);
    const [bulkText, setBulkText] = useState('');
    const [importPreview, setImportPreview] = useState([]);

    // Position groups for depth chart display
    const offensePositions = ['QB', 'RB', 'WR_X', 'WR_Y', 'WR_Z', 'TE', 'LT', 'LG', 'C', 'RG', 'RT'];
    const defensePositions = ['DE_L', 'DT_L', 'DT_R', 'DE_R', 'SAM', 'MIKE', 'WILL', 'CB_L', 'CB_R', 'SS', 'FS'];

    const positionLabels = {
      'QB': 'Quarterback', 'RB': 'Running Back', 'WR_X': 'Wide Receiver (X)', 'WR_Y': 'Slot (Y)', 'WR_Z': 'Wide Receiver (Z)',
      'TE': 'Tight End', 'LT': 'Left Tackle', 'LG': 'Left Guard', 'C': 'Center', 'RG': 'Right Guard', 'RT': 'Right Tackle',
      'DE_L': 'Left DE', 'DT_L': 'Left DT', 'DT_R': 'Right DT', 'DE_R': 'Right DE',
      'SAM': 'SAM LB', 'MIKE': 'MIKE LB', 'WILL': 'WILL LB',
      'CB_L': 'Left CB', 'CB_R': 'Right CB', 'SS': 'Strong Safety', 'FS': 'Free Safety'
    };

    // Position mapping for flexible input
    const positionMap = {
      'qb': 'QB', 'quarterback': 'QB',
      'rb': 'RB', 'runningback': 'RB', 'running back': 'RB', 'hb': 'RB', 'halfback': 'RB', 'tb': 'RB', 'tailback': 'RB',
      'wr': 'WR_X', 'wr1': 'WR_X', 'wrx': 'WR_X', 'x': 'WR_X', 'wr x': 'WR_X',
      'wr2': 'WR_Z', 'wrz': 'WR_Z', 'z': 'WR_Z', 'wr z': 'WR_Z',
      'slot': 'WR_Y', 'wry': 'WR_Y', 'y': 'WR_Y', 'wr y': 'WR_Y', 'wr3': 'WR_Y',
      'te': 'TE', 'tightend': 'TE', 'tight end': 'TE',
      'lt': 'LT', 'lefttackle': 'LT', 'left tackle': 'LT',
      'lg': 'LG', 'leftguard': 'LG', 'left guard': 'LG',
      'c': 'C', 'center': 'C',
      'rg': 'RG', 'rightguard': 'RG', 'right guard': 'RG',
      'rt': 'RT', 'righttackle': 'RT', 'right tackle': 'RT',
      'ol': 'LG', 'oline': 'LG', 'lineman': 'LG',
      'de': 'DE_L', 'del': 'DE_L', 'der': 'DE_R', 'de_l': 'DE_L', 'de_r': 'DE_R', 'left de': 'DE_L', 'right de': 'DE_R',
      'dt': 'DT_L', 'dtl': 'DT_L', 'dtr': 'DT_R', 'dt_l': 'DT_L', 'dt_r': 'DT_R', 'left dt': 'DT_L', 'right dt': 'DT_R', 'nose': 'DT_L', 'nt': 'DT_L',
      'lb': 'MIKE', 'ilb': 'MIKE', 'mlb': 'MIKE', 'mike': 'MIKE', 'middle linebacker': 'MIKE',
      'sam': 'SAM', 'slb': 'SAM', 'strong side lb': 'SAM',
      'will': 'WILL', 'wlb': 'WILL', 'weak side lb': 'WILL',
      'olb': 'SAM', 'outside linebacker': 'SAM',
      'cb': 'CB_L', 'cbl': 'CB_L', 'cbr': 'CB_R', 'cb_l': 'CB_L', 'cb_r': 'CB_R', 'corner': 'CB_L', 'cornerback': 'CB_L', 'left cb': 'CB_L', 'right cb': 'CB_R',
      'cb1': 'CB_L', 'cb2': 'CB_R',
      'ss': 'SS', 'strongsafety': 'SS', 'strong safety': 'SS',
      'fs': 'FS', 'freesafety': 'FS', 'free safety': 'FS',
      's': 'SS', 'safety': 'SS', 'db': 'CB_L'
    };

    const normalizePosition = (pos) => {
      const lower = pos.toLowerCase().trim();
      return positionMap[lower] || pos.toUpperCase();
    };

    const parseRosterText = (text) => {
      const lines = text.trim().split('\n').filter(line => line.trim());
      const parsed = [];
      
      for (const line of lines) {
        // Try different formats:
        // "12 John Smith QB" or "John Smith, 12, QB" or "12, John Smith, QB" or "John Smith 12 QB"
        let name = '', jersey = '', position = '';
        
        // Remove extra whitespace and split by common delimiters
        const cleanLine = line.replace(/\t/g, ' ').replace(/,/g, ' ').replace(/\s+/g, ' ').trim();
        const parts = cleanLine.split(' ');
        
        if (parts.length >= 2) {
          // Find the jersey number (first number found)
          const numberIndex = parts.findIndex(p => /^\d+$/.test(p));
          
          // Find position (last part that matches a known position)
          let posIndex = -1;
          for (let i = parts.length - 1; i >= 0; i--) {
            if (positionMap[parts[i].toLowerCase()] || offensePositions.includes(parts[i].toUpperCase()) || defensePositions.includes(parts[i].toUpperCase())) {
              posIndex = i;
              break;
            }
          }
          
          if (numberIndex !== -1) {
            jersey = parts[numberIndex];
            // Name is everything except number and position
            const nameParts = parts.filter((_, i) => i !== numberIndex && i !== posIndex);
            name = nameParts.join(' ');
            position = posIndex !== -1 ? normalizePosition(parts[posIndex]) : 'QB';
          } else {
            // No number found, assume format: Name Position
            name = parts.slice(0, -1).join(' ');
            position = normalizePosition(parts[parts.length - 1]);
            jersey = String(parsed.length + 1);
          }
        }
        
        if (name) {
          const unit = defensePositions.includes(position) ? 'defense' : 'offense';
          parsed.push({ name, jersey, position, unit });
        }
      }
      
      return parsed;
    };

    const handleBulkTextChange = (text) => {
      setBulkText(text);
      if (text.trim()) {
        setImportPreview(parseRosterText(text));
      } else {
        setImportPreview([]);
      }
    };

    const handleBulkImport = () => {
      if (importPreview.length === 0) return;
      
      const newPlayers = importPreview.map((p, i) => {
        const samePos = [...players, ...importPreview.slice(0, i)].filter(
          existing => existing.position === p.position && existing.unit === p.unit
        );
        return {
          player_id: `p${Date.now()}_${i}`,
          name: p.name,
          jersey: p.jersey,
          position: p.position,
          unit: p.unit,
          depth: samePos.length + 1
        };
      });
      
      setPlayers([...players, ...newPlayers]);
      setBulkText('');
      setImportPreview([]);
      setShowBulkImport(false);
      alert(`✅ Imported ${newPlayers.length} players!`);
    };

    const handleDeletePlayer = (playerId, playerName) => {
      setConfirmDialog({
        message: `Are you sure you want to delete ${playerName}?`,
        onConfirm: () => {
          setPlayers(players.filter(pl => pl.player_id !== playerId));
          setConfirmDialog(null);
        },
        onCancel: () => setConfirmDialog(null)
      });
    };

    const handleAddPlayer = () => {
      if (newPlayer.name && newPlayer.jersey) {
        // Find max depth for this position
        const samePositionPlayers = players.filter(p => p.position === newPlayer.position && p.unit === newPlayer.unit);
        const maxDepth = samePositionPlayers.length > 0 ? Math.max(...samePositionPlayers.map(p => p.depth || 1)) : 0;
        
        setPlayers([...players, { 
          ...newPlayer, 
          player_id: `p${Date.now()}`,
          depth: maxDepth + 1
        }]);
        setNewPlayer({ name: '', jersey: '', position: newPlayer.position, unit: newPlayer.unit, depth: 1 });
      }
    };

    const moveDepth = (playerId, direction) => {
      const player = players.find(p => p.player_id === playerId);
      if (!player) return;
      
      const newDepth = (player.depth || 1) + direction;
      if (newDepth < 1) return;
      
      // Find player currently at that depth
      const swapPlayer = players.find(p => 
        p.position === player.position && 
        p.unit === player.unit && 
        p.depth === newDepth
      );
      
      setPlayers(players.map(p => {
        if (p.player_id === playerId) return { ...p, depth: newDepth };
        if (swapPlayer && p.player_id === swapPlayer.player_id) return { ...p, depth: player.depth || 1 };
        return p;
      }));
    };

    const clearRoster = () => {
      setConfirmDialog({
        message: `Are you sure you want to clear all ${rosterUnit} players? This cannot be undone.`,
        onConfirm: () => {
          setPlayers(players.filter(p => p.unit !== rosterUnit));
          setConfirmDialog(null);
        },
        onCancel: () => setConfirmDialog(null)
      });
    };

    const currentPositions = rosterUnit === 'offense' ? offensePositions : defensePositions;

    if (quickLookPlayer) {
      const currentInstalls = installs.filter(i => {
        if (i.group === 'Full Offense') return true;
        if (i.group === 'WR Group') return ['WR_X', 'WR_Z', 'WR_Y'].includes(quickLookPlayer.position);
        if (i.group === 'OL Group') return ['LT', 'LG', 'C', 'RG', 'RT'].includes(quickLookPlayer.position);
        if (i.group === 'Skill Group') return ['QB', 'RB', 'WR_X', 'WR_Z', 'WR_Y', 'TE'].includes(quickLookPlayer.position);
        return true;
      });

      return (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Quick Look - {quickLookPlayer.name}</h2>
            <button onClick={() => setQuickLookPlayer(null)} className="bg-gray-700 px-4 py-2 rounded">Back to Roster</button>
          </div>
          <div className="bg-gray-800 p-4 rounded-lg">
            <p className="text-gray-400">#{quickLookPlayer.jersey} - {quickLookPlayer.position} - {quickLookPlayer.depth === 1 ? '1st String' : quickLookPlayer.depth === 2 ? '2nd String' : `${quickLookPlayer.depth}rd String`}</p>
          </div>
          <h3 className="text-xl font-bold">Current Installs</h3>
          <div className="space-y-3">
            {currentInstalls.map(install => {
              const myPlays = install.play_ids.map(id => plays.find(p => p.play_id === id)).filter(p => p && p.positions.find(pos => pos.position_id === quickLookPlayer.position));
              return (
                <div key={install.install_id} className="bg-gray-800 p-4 rounded-lg">
                  <h4 className="font-bold mb-2">{install.name}</h4>
                  <div className="space-y-2">
                    {myPlays.map(play => (
                      <div key={play.play_id} className="text-sm bg-gray-900 p-2 rounded">{play.name} - {play.formation}</div>
                    ))}
                  </div>
                </div>
              );
            })}
            {currentInstalls.length === 0 && <p className="text-gray-400 text-center py-4">No current installs</p>}
          </div>
        </div>
      );
    }

    return (
      <div className="space-y-4 pb-20">
        <div className="flex justify-between items-center flex-wrap gap-3">
          <h2 className="text-2xl font-bold">Depth Chart</h2>
          <div className="flex items-center gap-3 flex-wrap">
            {/* Bulk Import Button */}
            <button 
              onClick={() => setShowBulkImport(true)}
              className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded font-bold flex items-center gap-2"
            >
              📋 Bulk Import
            </button>
            {/* Clear Roster Button */}
            <button 
              onClick={clearRoster}
              className="bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded text-sm"
            >
              Clear {rosterUnit}
            </button>
            {/* Unit Toggle */}
            <div className="flex bg-gray-800 rounded-lg overflow-hidden">
              <button 
                onClick={() => setRosterUnit('offense')} 
                className={`px-4 py-2 font-bold ${rosterUnit === 'offense' ? 'bg-blue-600' : 'hover:bg-gray-700'}`}
              >
                Offense
              </button>
              <button 
                onClick={() => setRosterUnit('defense')} 
                className={`px-4 py-2 font-bold ${rosterUnit === 'defense' ? 'bg-red-600' : 'hover:bg-gray-700'}`}
              >
                Defense
              </button>
            </div>
          </div>
        </div>

        {/* Bulk Import Modal */}
        {showBulkImport && (
          <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center p-4 z-50 overflow-y-auto">
            <div className="bg-gray-900 rounded-lg max-w-3xl w-full my-4 flex flex-col max-h-[95vh]">
              {/* Header - Fixed */}
              <div className="flex justify-between items-center p-6 pb-4 border-b border-gray-800">
                <h2 className="text-xl font-bold">📋 Bulk Import Roster</h2>
                <button onClick={() => { setShowBulkImport(false); setBulkText(''); setImportPreview([]); }} className="text-gray-400 hover:text-white text-2xl">&times;</button>
              </div>
              
              {/* Scrollable Content */}
              <div className="flex-1 overflow-y-auto p-6 pt-4">
                <div className="bg-gray-800 p-4 rounded-lg mb-4">
                  <h3 className="font-bold mb-2">How to use:</h3>
                  <p className="text-sm text-gray-400 mb-2">Paste your roster from Excel, Google Sheets, or type it. Each player on a new line.</p>
                  <p className="text-sm text-gray-400 mb-2"><strong>Accepted formats:</strong></p>
                  <ul className="text-xs text-gray-500 space-y-1 ml-4">
                    <li>• <code>12 John Smith QB</code></li>
                    <li>• <code>John Smith, 12, QB</code></li>
                    <li>• <code>12, John Smith, Quarterback</code></li>
                    <li>• <code>John Smith 12 WR</code></li>
                  </ul>
                  <p className="text-xs text-gray-500 mt-2">Positions auto-detect: QB, RB, WR, TE, LT, LG, C, RG, RT, DE, DT, LB, CB, SS, FS, etc.</p>
                </div>

                <textarea
                  value={bulkText}
                  onChange={(e) => handleBulkTextChange(e.target.value)}
                  placeholder="Paste your roster here...

Example:
12 John Smith QB
24 Mike Johnson RB
81 Chris Williams WR
55 David Brown LB
21 James Wilson CB"
                  className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white h-40 font-mono text-sm"
                />

                {importPreview.length > 0 && (
                  <div className="mt-4">
                    <h3 className="font-bold mb-2 text-green-400">✓ Preview ({importPreview.length} players detected):</h3>
                    <div className="bg-gray-800 rounded-lg p-3 max-h-40 overflow-y-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="text-gray-400 border-b border-gray-700">
                            <th className="text-left py-1 px-2">#</th>
                            <th className="text-left py-1 px-2">Name</th>
                            <th className="text-left py-1 px-2">Position</th>
                            <th className="text-left py-1 px-2">Unit</th>
                          </tr>
                        </thead>
                        <tbody>
                          {importPreview.map((p, i) => (
                            <tr key={i} className={`${p.unit === 'offense' ? 'text-blue-300' : 'text-red-300'}`}>
                              <td className="py-1 px-2">{p.jersey}</td>
                              <td className="py-1 px-2">{p.name}</td>
                              <td className="py-1 px-2">{p.position}</td>
                              <td className="py-1 px-2 capitalize">{p.unit}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>

              {/* Footer - Fixed */}
              <div className="flex gap-3 p-6 pt-4 border-t border-gray-800 bg-gray-900 rounded-b-lg">
                <button
                  onClick={handleBulkImport}
                  disabled={importPreview.length === 0}
                  className="flex-1 bg-green-600 hover:bg-green-700 py-3 rounded-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Import {importPreview.length} Players
                </button>
                <button
                  onClick={() => { setShowBulkImport(false); setBulkText(''); setImportPreview([]); }}
                  className="px-6 bg-gray-700 py-3 rounded-lg font-bold"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Add Player Form */}
        <div className={`${rosterUnit === 'offense' ? 'bg-blue-900 border-blue-600' : 'bg-red-900 border-red-600'} border p-4 rounded-lg`}>
          <h3 className="font-bold mb-3">Add Player to {rosterUnit === 'offense' ? 'Offense' : 'Defense'}</h3>
          <div className="grid md:grid-cols-4 gap-3">
            <input 
              type="text" 
              placeholder="Name" 
              value={newPlayer.name} 
              onChange={(e) => setNewPlayer({ ...newPlayer, name: e.target.value })} 
              className="bg-gray-700 rounded px-3 py-2 text-white" 
            />
            <input 
              type="text" 
              placeholder="Jersey #" 
              value={newPlayer.jersey} 
              onChange={(e) => setNewPlayer({ ...newPlayer, jersey: e.target.value })} 
              className="bg-gray-700 rounded px-3 py-2 text-white" 
            />
            <select 
              value={newPlayer.position} 
              onChange={(e) => setNewPlayer({ ...newPlayer, position: e.target.value, unit: rosterUnit })} 
              className="bg-gray-700 rounded px-3 py-2 text-white"
            >
              {currentPositions.map(pos => (
                <option key={pos} value={pos}>{positionLabels[pos] || pos}</option>
              ))}
            </select>
            <button 
              onClick={handleAddPlayer} 
              className={`${rosterUnit === 'offense' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-red-600 hover:bg-red-700'} px-4 py-2 rounded font-bold`}
            >
              Add Player
            </button>
          </div>
        </div>

        {/* Depth Chart Grid */}
        <div className="space-y-4">
          {currentPositions.map(position => {
            const positionPlayers = players
              .filter(p => p.position === position && p.unit === rosterUnit)
              .sort((a, b) => (a.depth || 1) - (b.depth || 1));
            
            return (
              <div key={position} className={`${rosterUnit === 'offense' ? 'bg-gray-800 border-l-4 border-blue-500' : 'bg-gray-800 border-l-4 border-red-500'} rounded-lg overflow-hidden`}>
                <div className={`${rosterUnit === 'offense' ? 'bg-blue-900' : 'bg-red-900'} px-4 py-2`}>
                  <h3 className="font-bold">{positionLabels[position] || position}</h3>
                </div>
                <div className="p-3">
                  {positionPlayers.length > 0 ? (
                    <div className="space-y-2">
                      {positionPlayers.map((player, index) => (
                        <div 
                          key={player.player_id} 
                          className={`flex items-center justify-between p-3 rounded ${
                            player.depth === 1 ? 'bg-gray-700' : 'bg-gray-750 bg-opacity-50'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                              player.depth === 1 ? 'bg-yellow-600' : player.depth === 2 ? 'bg-gray-500' : 'bg-gray-600'
                            }`}>
                              {player.depth || 1}
                            </span>
                            <div>
                              <span className="font-bold">#{player.jersey} {player.name}</span>
                              <span className="ml-2 text-xs text-gray-400">
                                {player.depth === 1 ? 'Starter' : player.depth === 2 ? '2nd String' : `${player.depth}${player.depth === 3 ? 'rd' : 'th'} String`}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {/* Move up/down buttons */}
                            <button 
                              onClick={() => moveDepth(player.player_id, -1)}
                              disabled={player.depth === 1}
                              className="p-1 bg-gray-600 rounded hover:bg-gray-500 disabled:opacity-30 disabled:cursor-not-allowed"
                              title="Move up"
                            >
                              ▲
                            </button>
                            <button 
                              onClick={() => moveDepth(player.player_id, 1)}
                              className="p-1 bg-gray-600 rounded hover:bg-gray-500"
                              title="Move down"
                            >
                              ▼
                            </button>
                            <button 
                              onClick={() => setQuickLookPlayer(player)} 
                              className="px-3 py-1 bg-blue-600 rounded text-sm hover:bg-blue-700"
                            >
                              View
                            </button>
                            <button 
                              onClick={() => handleDeletePlayer(player.player_id, player.name)} 
                              className="p-2 bg-red-600 rounded hover:bg-red-700"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-sm italic py-2">No players assigned</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Summary */}
        <div className={`${rosterUnit === 'offense' ? 'bg-blue-900 border-blue-600' : 'bg-red-900 border-red-600'} border p-4 rounded-lg`}>
          <div className="flex justify-between text-sm">
            <span>Total {rosterUnit === 'offense' ? 'Offensive' : 'Defensive'} Players: <strong>{players.filter(p => p.unit === rosterUnit).length}</strong></span>
            <span>Starters: <strong>{players.filter(p => p.unit === rosterUnit && p.depth === 1).length}</strong> / {currentPositions.length}</span>
          </div>
        </div>
      </div>
    );
  }

  // ============== PRACTICE/GAME / PLAY CALLING VIEW ==============
  function GameDayView() {
    const [connectedDevices, setConnectedDevices] = useState([]);
    const [playHistory, setPlayHistory] = useState([]);
    const [isConnecting, setIsConnecting] = useState(false);
    const [sendingPlay, setSendingPlay] = useState(null);
    const [hudPreview, setHudPreview] = useState(null); // { play, position }

    // Simulated device connection
    const connectDevices = () => {
      setIsConnecting(true);
      setTimeout(() => {
        // Simulate finding devices for players with depth 1 (starters)
        const starterDevices = players
          .filter(p => p.depth === 1 && p.unit === unit)
          .map(p => ({
            device_id: `device_${p.player_id}`,
            player_id: p.player_id,
            player_name: p.name,
            position: p.position,
            jersey: p.jersey,
            unit: p.unit,
            connected: true,
            battery: Math.floor(Math.random() * 40) + 60,
            signal: Math.floor(Math.random() * 3) + 3
          }));
        setConnectedDevices(starterDevices);
        setIsConnecting(false);
      }, 1500);
    };

    const disconnectDevices = () => {
      setConnectedDevices([]);
    };

    // Get current unit's plays
    const currentPlays = unit === 'offense' ? plays : defensivePlays;

    // Send play to ALL connected devices - one click!
    const sendPlay = (play) => {
      if (connectedDevices.length === 0) {
        alert('Connect devices first!');
        return;
      }

      setSendingPlay(play.play_id);
      
      setTimeout(() => {
        // Add to history
        const historyEntry = {
          id: `send_${Date.now()}`,
          play: play,
          deviceCount: connectedDevices.length,
          timestamp: new Date().toLocaleTimeString(),
        };
        setPlayHistory([historyEntry, ...playHistory.slice(0, 19)]); // Keep last 20
        
        setSendingPlay(null);
      }, 600);
    };

    // HUD Preview Component - What players see on their device
    // Image is focal point, assignment info in compact row at bottom
    const HUDPreview = ({ play, position, onClose }) => {
      const assignment = play.positions?.find(p => p.position_id === position);
      const isDefense = unit === 'defense';
      const playerAtPosition = players.find(p => p.position === position && p.depth === 1);

      return (
        <div className="fixed inset-0 bg-black bg-opacity-95 z-50 overflow-y-auto">
          <div className="min-h-full flex items-center justify-center p-4" onClick={onClose}>
            <div className="max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
              {/* Close button */}
              <button 
                onClick={onClose}
                className="absolute top-4 right-4 bg-red-600 hover:bg-red-700 text-white w-10 h-10 rounded-full text-xl font-bold z-50 fixed"
              >
                ✕
              </button>

              {/* Player indicator */}
              {playerAtPosition && (
                <div className="text-center mb-2">
                  <span className="bg-green-600 px-3 py-1 rounded-full text-xs font-bold">
                    #{playerAtPosition.jersey} {playerAtPosition.name}
                  </span>
                </div>
              )}
              
              {/* HUD Device Frame */}
              <div className="bg-black rounded-2xl border-4 border-gray-800 overflow-hidden shadow-2xl">
                
                {/* TOP BAR - Position & Play Name */}
                <div className="bg-gray-900 px-3 py-2 flex justify-between items-center">
                  <span className="text-green-400 font-black text-xl">{position}</span>
                  <span className="text-white font-bold text-sm">{play.name}</span>
                </div>

                {/* FOCAL POINT - Play Image */}
                {play.image_url ? (
                  <div className="p-1">
                    <img 
                      src={play.image_url} 
                      alt={play.name} 
                      className="w-full"
                    />
                  </div>
                ) : (
                  <div className="h-48 bg-green-900 flex items-center justify-center text-gray-500">
                    No image - use Play Editor
                  </div>
                )}

                {/* BOTTOM BAR - Assignment Info in One Row */}
                <div className="bg-gray-900 px-2 py-2">
                  {isDefense ? (
                    <div className="flex gap-1 text-xs">
                      <div className="flex-1 bg-black rounded p-1 text-center">
                        <div className="text-gray-500 text-[10px]">ALIGN</div>
                        <div className="text-white font-bold truncate">{assignment?.alignment || '-'}</div>
                      </div>
                      <div className="flex-1 bg-black rounded p-1 text-center">
                        <div className="text-gray-500 text-[10px]">READ</div>
                        <div className="text-yellow-400 font-bold truncate">{assignment?.read_key || '-'}</div>
                      </div>
                      <div className="flex-1 bg-black rounded p-1 text-center">
                        <div className="text-gray-500 text-[10px]">JOB</div>
                        <div className="text-white font-bold truncate">{assignment?.responsibility || '-'}</div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex gap-1 text-xs">
                      <div className="bg-black rounded p-1 text-center min-w-[50px]">
                        <div className={`font-black text-[10px] ${assignment?.route_details?.alignment === 'off' ? 'text-purple-400' : 'text-blue-400'}`}>
                          {assignment?.route_details?.alignment === 'off' ? 'OFF' : 'ON'}
                        </div>
                      </div>
                      <div className="flex-1 bg-black rounded p-1 text-center">
                        <div className="text-gray-500 text-[10px]">ROUTE</div>
                        <div className="text-green-400 font-bold truncate">{assignment?.route_details?.steps || '-'}</div>
                      </div>
                      <div className="bg-black rounded p-1 text-center min-w-[50px]">
                        <div className="text-gray-500 text-[10px]">READ</div>
                        <div className="text-yellow-400 font-bold truncate">{assignment?.route_details?.read_key || '-'}</div>
                      </div>
                      <div className="bg-black rounded p-1 text-center min-w-[50px]">
                        <div className="text-gray-500 text-[10px]">LAND</div>
                        <div className="text-white font-bold truncate">{assignment?.route_details?.landmark || '-'}</div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Position selector (preview only) */}
              <div className="mt-3 bg-gray-800 rounded-lg p-2">
                <div className="text-xs text-gray-400 mb-1 text-center">Preview as:</div>
                <div className="flex flex-wrap gap-1 justify-center">
                  {play.positions?.map(pos => (
                    <button
                      key={pos.position_id}
                      onClick={() => setHudPreview({ play, position: pos.position_id })}
                      className={`px-2 py-1 rounded text-xs font-bold ${
                        pos.position_id === position ? 'bg-green-600' : 'bg-gray-700 hover:bg-gray-600'
                      }`}
                    >
                      {pos.position_id}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={onClose}
                className="w-full mt-3 bg-gray-700 hover:bg-gray-600 py-2 rounded-lg font-bold text-sm"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      );
    };

    return (
      <div className="space-y-4">
        {/* HUD Preview Modal */}
        {hudPreview && (
          <HUDPreview 
            play={hudPreview.play} 
            position={hudPreview.position} 
            onClose={() => setHudPreview(null)} 
          />
        )}

        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Radio className="text-green-400" /> Practice/Game
            </h2>
            <p className="text-gray-400 text-sm">Tap a play to send to all player HUDs</p>
          </div>
          
          {/* Connection Button */}
          {connectedDevices.length > 0 ? (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 text-green-400 bg-green-900 px-4 py-2 rounded-lg">
                <Wifi size={20} />
                <span className="font-bold">{connectedDevices.length} Connected</span>
              </div>
              <button onClick={disconnectDevices} className="bg-red-600 px-4 py-2 rounded font-bold hover:bg-red-700">
                Disconnect
              </button>
            </div>
          ) : (
            <button 
              onClick={connectDevices} 
              disabled={isConnecting}
              className="bg-green-600 px-6 py-3 rounded-lg font-bold hover:bg-green-500 flex items-center gap-2 disabled:opacity-50 text-lg"
            >
              {isConnecting ? (
                <>
                  <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
                  Connecting...
                </>
              ) : (
                <>
                  <Wifi size={24} /> Connect Devices
                </>
              )}
            </button>
          )}
        </div>

        {/* Connected Devices Bar */}
        {connectedDevices.length > 0 && (
          <div className={`${unit === 'offense' ? 'bg-blue-900 border-blue-600' : 'bg-red-900 border-red-600'} border rounded-lg p-3`}>
            <div className="flex flex-wrap gap-2">
              {connectedDevices.map(device => (
                <div 
                  key={device.device_id} 
                  className={`bg-gray-800 px-3 py-2 rounded-lg flex items-center gap-2 ${
                    sendingPlay ? 'animate-pulse ring-2 ring-green-400' : ''
                  }`}
                >
                  <span className="font-bold">#{device.jersey}</span>
                  <span className="text-sm text-gray-400">{device.position}</span>
                  <span className="text-green-400 text-xs">●</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Main Content - Plays Grid and History */}
        <div className="grid lg:grid-cols-3 gap-4">
          {/* Play Buttons - Large and Easy to Tap */}
          <div className="lg:col-span-2">
            <div className="bg-gray-800 rounded-lg p-4">
              <h3 className="font-bold mb-4 text-lg">📋 Tap to Send</h3>
              
              {connectedDevices.length === 0 ? (
                <div className="text-center py-12 text-gray-400">
                  <WifiOff size={48} className="mx-auto mb-4 opacity-50" />
                  <p className="text-lg">Connect devices to start calling plays</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {currentPlays.map(play => (
                    <div key={play.play_id} className="relative">
                      <button
                        onClick={() => sendPlay(play)}
                        disabled={sendingPlay === play.play_id}
                        className={`w-full p-4 rounded-lg text-left transition-all transform hover:scale-105 active:scale-95 ${
                          sendingPlay === play.play_id
                            ? 'bg-green-600 ring-4 ring-green-400 animate-pulse'
                            : unit === 'offense' 
                              ? 'bg-blue-700 hover:bg-blue-600' 
                              : 'bg-red-700 hover:bg-red-600'
                        }`}
                      >
                        <div className="font-bold text-lg">{play.name}</div>
                        <div className="text-sm text-gray-300 opacity-75">
                          {unit === 'offense' ? play.formation : play.coverage}
                        </div>
                        {sendingPlay === play.play_id && (
                          <div className="text-xs text-green-200 mt-2 flex items-center gap-1">
                            <Send size={14} /> Sending...
                          </div>
                        )}
                      </button>
                      {/* Preview HUD Button */}
                      <button
                        onClick={(e) => { e.stopPropagation(); setHudPreview({ play, position: play.positions?.[0]?.position_id || 'QB' }); }}
                        className="absolute top-2 right-2 bg-black bg-opacity-50 hover:bg-opacity-75 p-1 rounded text-xs"
                        title="Preview HUD"
                      >
                        👁️
                      </button>
                    </div>
                  ))}
                </div>
              )}
              
              {currentPlays.length === 0 && connectedDevices.length > 0 && (
                <p className="text-gray-500 text-center py-8">No plays yet! Add plays in the Playbook first.</p>
              )}
            </div>
          </div>

          {/* Play History */}
          <div className="lg:col-span-1">
            <div className="bg-gray-800 rounded-lg p-4 h-full">
              <h3 className="font-bold mb-3">📜 Sent Plays</h3>
              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {playHistory.map((entry, index) => (
                  <div 
                    key={entry.id} 
                    className={`p-3 rounded-lg ${
                      index === 0 ? 'bg-green-900 border border-green-500' : 'bg-gray-700'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <span className="font-bold">{entry.play.name}</span>
                      <span className="text-xs text-gray-400">{entry.timestamp}</span>
                    </div>
                    <div className="text-xs text-gray-400 mt-1">
                      Sent to {entry.deviceCount} devices
                    </div>
                  </div>
                ))}
                {playHistory.length === 0 && (
                  <p className="text-gray-500 text-center py-8 text-sm">No plays sent yet</p>
                )}
              </div>
              {playHistory.length > 0 && (
                <button 
                  onClick={() => setPlayHistory([])}
                  className="w-full mt-3 py-2 bg-gray-700 rounded text-sm hover:bg-gray-600"
                >
                  Clear History
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  function AnalyticsView() {
    const updatedPlays = plays.filter(p => p.updated);
    const updatedDefensivePlays = defensivePlays.filter(p => p.updated);
    const totalPlays = plays.length + defensivePlays.length;

    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Analytics</h2>
        <div className="grid md:grid-cols-4 gap-4">
          <div className="bg-gray-800 p-6 rounded-lg">
            <div className="text-3xl font-bold text-blue-400">{totalPlays}</div>
            <div className="text-gray-400">Total Plays</div>
          </div>
          <div className="bg-gray-800 p-6 rounded-lg">
            <div className="text-3xl font-bold text-blue-300">{plays.length}</div>
            <div className="text-gray-400">Offensive</div>
          </div>
          <div className="bg-gray-800 p-6 rounded-lg">
            <div className="text-3xl font-bold text-red-400">{defensivePlays.length}</div>
            <div className="text-gray-400">Defensive</div>
          </div>
          <div className="bg-gray-800 p-6 rounded-lg">
            <div className="text-3xl font-bold text-purple-400">{players.length}</div>
            <div className="text-gray-400">Players</div>
          </div>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-gray-800 p-6 rounded-lg">
            <div className="text-3xl font-bold text-green-400">{installs.length}</div>
            <div className="text-gray-400">Installs</div>
          </div>
          <div className="bg-gray-800 p-6 rounded-lg">
            <div className="text-3xl font-bold text-yellow-400">{players.filter(p => p.depth === 1).length}</div>
            <div className="text-gray-400">Starters</div>
          </div>
        </div>
        {(updatedPlays.length > 0 || updatedDefensivePlays.length > 0) && (
          <div className="bg-yellow-900 border border-yellow-600 p-4 rounded-lg">
            <h3 className="font-bold mb-2 text-yellow-200">⚠️ Plays Updated - Need Re-Review</h3>
            <div className="space-y-1">
              {updatedPlays.map(play => <div key={play.play_id} className="text-sm text-yellow-100">📘 {play.name}</div>)}
              {updatedDefensivePlays.map(play => <div key={play.play_id} className="text-sm text-yellow-100">📕 {play.name}</div>)}
            </div>
          </div>
        )}
        <div className="bg-gray-800 p-6 rounded-lg">
          <h3 className="font-bold mb-4">Player Accountability</h3>
          <div className="space-y-2">
            {players.map(player => {
              const totalInstalls = installs.filter(i => {
                if (i.group === 'Full Offense') return true;
                if (i.group === 'WR Group') return ['WR_X', 'WR_Z', 'WR_Y'].includes(player.position);
                if (i.group === 'OL Group') return ['LT', 'LG', 'C', 'RG', 'RT'].includes(player.position);
                if (i.group === 'Skill Group') return ['QB', 'RB', 'WR_X', 'WR_Z', 'WR_Y', 'TE'].includes(player.position);
                return true;
              }).length;
              return (
                <div key={player.player_id} className="flex justify-between p-3 bg-gray-900 rounded">
                  <div><span className="font-bold">{player.name}</span><span className="ml-2 text-sm text-gray-400">{player.position}</span></div>
                  <span className="text-sm text-gray-400">0/{totalInstalls} installs</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  function PlayerDashboard() {
    const [playerView, setPlayerView] = useState('dashboard'); // dashboard, study, flashcards, quiz
    const [currentPlayIndex, setCurrentPlayIndex] = useState(0);
    const [showAnswer, setShowAnswer] = useState(false);
    const [quizAnswers, setQuizAnswers] = useState({});
    const [quizSubmitted, setQuizSubmitted] = useState(false);

    if (!selectedPlayer) {
      return (
        <div className="space-y-6 max-w-2xl mx-auto">
          <div className="text-center">
            <h2 className="text-4xl font-bold mb-2">Welcome to ZUNO</h2>
            <p className="text-gray-400 text-xl">Select your profile to continue</p>
          </div>
          <div className="space-y-3">
            {players.map(player => (
              <button key={player.player_id} onClick={() => setSelectedPlayer(player)} className="w-full bg-gray-800 hover:bg-gray-700 p-6 rounded-lg text-left transition-all">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-2xl font-bold">#{player.jersey} {player.name}</div>
                    <div className="text-gray-400 mt-1">{player.position} • {player.unit}</div>
                  </div>
                  <div className="text-4xl">→</div>
                </div>
              </button>
            ))}
          </div>
          {players.length === 0 && (
            <div className="bg-gray-800 p-8 rounded-lg text-center">
              <p className="text-gray-400 mb-4">No players in the system yet.</p>
              <p className="text-sm text-gray-500">Ask your coach to add you to the roster.</p>
            </div>
          )}
        </div>
      );
    }

    const defensivePositions = ['DE_L', 'DE_R', 'DT_L', 'DT_R', 'NT', 'SAM', 'MIKE', 'WILL', 'OLB_L', 'OLB_R', 'ILB_L', 'ILB_R', 'CB_L', 'CB_R', 'SS', 'FS', 'NB', 'DIME', 'ROVER', 'LB_L', 'LB_R', 'NT_L', 'NT_R'];
    const isDefensivePlayer = defensivePositions.includes(selectedPlayer.position);
    const playerPlaybook = isDefensivePlayer ? defensivePlays : plays;
    const myPlays = playerPlaybook.filter(play => {
      return play.positions && play.positions.some(pos => pos.position_id === selectedPlayer.position);
    });

    const progress = playerProgress[selectedPlayer.player_id] || {};
    const totalPlays = myPlays.length;
    const viewedPlays = myPlays.filter(play => progress[play.play_id]?.viewed).length;
    const masteredPlays = myPlays.filter(play => progress[play.play_id]?.mastered).length;

    // Mark play as viewed
    const markViewed = (playId) => {
      setPlayerProgress(prev => ({
        ...prev,
        [selectedPlayer.player_id]: {
          ...(prev[selectedPlayer.player_id] || {}),
          [playId]: {
            ...(prev[selectedPlayer.player_id]?.[playId] || {}),
            viewed: true,
            views: (prev[selectedPlayer.player_id]?.[playId]?.views || 0) + 1,
            lastViewed: new Date().toISOString().split('T')[0]
          }
        }
      }));
    };

    // Mark play as mastered
    const toggleMastered = (playId) => {
      setPlayerProgress(prev => ({
        ...prev,
        [selectedPlayer.player_id]: {
          ...(prev[selectedPlayer.player_id] || {}),
          [playId]: {
            ...(prev[selectedPlayer.player_id]?.[playId] || {}),
            mastered: !(prev[selectedPlayer.player_id]?.[playId]?.mastered)
          }
        }
      }));
    };

    // Get my assignment for a play
    const getMyAssignment = (play) => {
      return play.positions.find(pos => pos.position_id === selectedPlayer.position);
    };

    // Flashcard Mode
    if (playerView === 'flashcards') {
      if (myPlays.length === 0) {
        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">🃏 Flashcard Study</h2>
              <button onClick={() => setPlayerView('dashboard')} className="bg-gray-700 px-4 py-2 rounded">← Back</button>
            </div>
            <div className="bg-gray-800 rounded-xl p-8 text-center">
              <p className="text-xl text-gray-400 mb-4">No plays available for your position yet.</p>
              <p className="text-gray-500">Ask your coach to add plays that include the {selectedPlayer.position} position.</p>
            </div>
          </div>
        );
      }

      const currentPlay = myPlays[currentPlayIndex];
      const myAssignment = getMyAssignment(currentPlay);

      // Mini field diagram component for flashcards
      const FlashcardDiagram = ({ play, highlightPosition }) => {
        const fieldWidth = 300;
        const fieldHeight = 200;
        const toCanvasX = (x) => (x / 50) * fieldWidth;
        const toCanvasY = (y) => fieldHeight - (y / 40) * fieldHeight;

        if (isDefensivePlayer) {
          // Defensive diagram
          const getDefPos = (posId) => {
            const positions = { 'DE_L': { x: 15, y: 20 }, 'DT_L': { x: 22, y: 20 }, 'DT_R': { x: 28, y: 20 }, 'DE_R': { x: 35, y: 20 }, 'SAM': { x: 35, y: 14 }, 'MIKE': { x: 25, y: 14 }, 'WILL': { x: 15, y: 14 }, 'CB_L': { x: 5, y: 12 }, 'CB_R': { x: 45, y: 12 }, 'SS': { x: 35, y: 6 }, 'FS': { x: 25, y: 3 }, 'NB': { x: 15, y: 12 } };
            return positions[posId] || { x: 25, y: 15 };
          };

          return (
            <div className="bg-green-900 rounded-lg mx-auto mb-4" style={{ width: fieldWidth, height: fieldHeight }}>
              <svg width={fieldWidth} height={fieldHeight}>
                {/* Field lines */}
                {[...Array(5)].map((_, i) => (
                  <line key={i} x1={0} y1={fieldHeight - i * (fieldHeight / 4)} x2={fieldWidth} y2={fieldHeight - i * (fieldHeight / 4)} stroke="#fff" strokeWidth="1" opacity="0.2" />
                ))}
                {/* LOS */}
                <line x1={0} y1={toCanvasY(20)} x2={fieldWidth} y2={toCanvasY(20)} stroke="#ff0" strokeWidth="3" />
                {/* Ghost offense */}
                <g opacity="0.2">
                  {[25, 22, 28, 19, 31].map(x => <circle key={x} cx={toCanvasX(x)} cy={toCanvasY(20)} r="6" fill="#666" />)}
                </g>
                {/* Defense */}
                {play.positions?.map(pos => {
                  const p = getDefPos(pos.position_id);
                  const isMe = pos.position_id === highlightPosition;
                  return (
                    <g key={pos.position_id}>
                      {isMe && <circle cx={toCanvasX(p.x)} cy={toCanvasY(p.y)} r="18" fill="rgba(34,197,94,0.4)" />}
                      <circle cx={toCanvasX(p.x)} cy={toCanvasY(p.y)} r="12" fill={isMe ? '#22c55e' : '#dc2626'} stroke="#fff" strokeWidth="2" />
                      <text x={toCanvasX(p.x)} y={toCanvasY(p.y) + 4} textAnchor="middle" fill="#fff" fontSize="8" fontWeight="bold">{pos.position_id.replace('_L','').replace('_R','')}</text>
                    </g>
                  );
                })}
              </svg>
            </div>
          );
        } else {
          // Offensive diagram
          return (
            <div className="bg-green-900 rounded-lg mx-auto mb-4" style={{ width: fieldWidth, height: fieldHeight }}>
              <svg width={fieldWidth} height={fieldHeight}>
                {/* Field lines */}
                {[...Array(5)].map((_, i) => (
                  <line key={i} x1={0} y1={fieldHeight - i * (fieldHeight / 4)} x2={fieldWidth} y2={fieldHeight - i * (fieldHeight / 4)} stroke="#fff" strokeWidth="1" opacity="0.2" />
                ))}
                {/* LOS */}
                <line x1={0} y1={toCanvasY(10)} x2={fieldWidth} y2={toCanvasY(10)} stroke="#ff0" strokeWidth="3" />
                {/* Players and routes */}
                {play.positions?.map(pos => {
                  const points = pos.route_points || [];
                  if (points.length === 0) return null;
                  const start = points[0];
                  const isMe = pos.position_id === highlightPosition;
                  const isOL = ['LT', 'LG', 'C', 'RG', 'RT'].includes(pos.position_id);
                  
                  return (
                    <g key={pos.position_id}>
                      {/* Route line */}
                      {!isOL && points.length > 1 && (
                        <polyline
                          points={points.map(p => `${toCanvasX(p.x)},${toCanvasY(p.y)}`).join(' ')}
                          fill="none"
                          stroke={isMe ? '#22c55e' : '#3b82f6'}
                          strokeWidth={isMe ? 3 : 2}
                          strokeDasharray={isMe ? '' : '4,2'}
                        />
                      )}
                      {/* Highlight glow */}
                      {isMe && <circle cx={toCanvasX(start.x)} cy={toCanvasY(start.y)} r="16" fill="rgba(34,197,94,0.4)" />}
                      {/* Player dot */}
                      <circle cx={toCanvasX(start.x)} cy={toCanvasY(start.y)} r={isOL ? 8 : 10} fill={isMe ? '#22c55e' : (isOL ? '#666' : '#3b82f6')} stroke="#fff" strokeWidth="2" />
                      {/* Position label */}
                      <text x={toCanvasX(start.x)} y={toCanvasY(start.y) + 3} textAnchor="middle" fill="#fff" fontSize="7" fontWeight="bold">
                        {pos.position_id.replace('WR_', '').replace('_', '')}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          );
        }
      };

      return (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">🃏 Flashcard Study</h2>
            <button onClick={() => setPlayerView('dashboard')} className="bg-gray-700 px-4 py-2 rounded">← Back</button>
          </div>

          <div className="text-center text-gray-400">
            Card {currentPlayIndex + 1} of {myPlays.length}
          </div>

          <div 
            onClick={() => setShowAnswer(!showAnswer)}
            className={`min-h-96 rounded-xl p-6 cursor-pointer transition-all ${showAnswer ? 'bg-green-900 border-2 border-green-500' : 'bg-gray-800 border-2 border-gray-600'}`}
          >
            {!showAnswer ? (
              <div className="text-center">
                <h3 className="text-3xl font-bold mb-2">{currentPlay.name}</h3>
                <p className="text-lg text-gray-400 mb-4">
                  {isDefensivePlayer ? `${currentPlay.front} - ${currentPlay.coverage}` : currentPlay.formation}
                </p>
                
                {/* Visual diagram on question side */}
                <FlashcardDiagram play={currentPlay} highlightPosition={selectedPlayer?.position} />
                
                {/* Reference image if available */}
                {currentPlay.image_url && (
                  <div className="mb-4">
                    <img src={currentPlay.image_url} alt="Play diagram" className="max-h-32 mx-auto rounded opacity-75" />
                  </div>
                )}
                
                <p className="text-lg text-blue-400 mt-4">What is YOUR assignment?</p>
                <p className="text-sm text-green-400">You are highlighted in GREEN</p>
                <p className="text-gray-500 mt-4 text-sm">Tap to reveal answer</p>
              </div>
            ) : (
              <div>
                <h3 className="text-xl font-bold text-green-400 mb-3">Your Assignment: {myAssignment?.position_name || myAssignment?.position_id}</h3>
                
                {/* Visual diagram on answer side too */}
                <FlashcardDiagram play={currentPlay} highlightPosition={selectedPlayer?.position} />
                
                {isDefensivePlayer ? (
                  <div className="space-y-3 text-left bg-gray-800 rounded-lg p-4">
                    <div><span className="font-bold text-blue-300">Alignment:</span> {myAssignment?.alignment}</div>
                    <div><span className="font-bold text-yellow-300">Read Key:</span> {myAssignment?.read_key}</div>
                    <div><span className="font-bold text-purple-300">Responsibility:</span> {myAssignment?.responsibility}</div>
                    <div><span className="font-bold text-orange-300">Coaching Point:</span> {myAssignment?.coaching_point}</div>
                  </div>
                ) : (
                  <div className="space-y-3 text-left bg-gray-800 rounded-lg p-4">
                    {myAssignment?.motion && myAssignment.motion !== 'none' && (
                      <div className="text-yellow-400 font-bold">⚡ MOTION: {myAssignment.motion.toUpperCase()}</div>
                    )}
                    <div><span className="font-bold text-green-300">Steps:</span><pre className="mt-1 whitespace-pre-wrap text-sm">{myAssignment?.route_details?.steps}</pre></div>
                    <div><span className="font-bold text-yellow-300">Landmark:</span> {myAssignment?.route_details?.landmark || '-'}</div>
                    <div><span className="font-bold text-purple-300">Read Key:</span> {myAssignment?.route_details?.read_key || '-'}</div>
                    <div><span className="font-bold text-orange-300">Coaching Point:</span> {myAssignment?.route_details?.coaching_point || '-'}</div>
                  </div>
                )}
                <p className="text-gray-500 mt-4 text-center text-sm">Tap to hide answer</p>
              </div>
            )}
          </div>

          <div className="flex gap-4">
            <button 
              onClick={() => { setCurrentPlayIndex(Math.max(0, currentPlayIndex - 1)); setShowAnswer(false); }}
              disabled={currentPlayIndex === 0}
              className="flex-1 bg-gray-700 py-3 rounded font-bold disabled:opacity-50"
            >
              ← Previous
            </button>
            <button 
              onClick={() => { toggleMastered(currentPlay.play_id); }}
              className={`flex-1 py-3 rounded font-bold ${progress[currentPlay.play_id]?.mastered ? 'bg-green-600' : 'bg-gray-600'}`}
            >
              {progress[currentPlay.play_id]?.mastered ? '✓ Mastered' : 'Mark Mastered'}
            </button>
            <button 
              onClick={() => { setCurrentPlayIndex(Math.min(myPlays.length - 1, currentPlayIndex + 1)); setShowAnswer(false); }}
              disabled={currentPlayIndex === myPlays.length - 1}
              className="flex-1 bg-blue-600 py-3 rounded font-bold disabled:opacity-50"
            >
              Next →
            </button>
          </div>
        </div>
      );
    }

    // Quiz Mode
    if (playerView === 'quiz' && myPlays.length > 0) {
      // Generate wrong answers from other plays
      const generateWrongAnswers = (correctAnswer, field, allPlays) => {
        const allAnswers = allPlays
          .map(p => {
            const assignment = getMyAssignment(p);
            if (isDefensivePlayer) {
              if (field === 'responsibility') return assignment?.responsibility;
              if (field === 'alignment') return assignment?.alignment;
              if (field === 'read_key') return assignment?.read_key;
            } else {
              if (field === 'read_key') return assignment?.route_details?.read_key;
              if (field === 'landmark') return assignment?.route_details?.landmark;
              if (field === 'steps') return assignment?.route_details?.steps?.split('\n')[0];
            }
            return null;
          })
          .filter(a => a && a !== correctAnswer && a.length > 0);
        
        // Get unique wrong answers
        const uniqueWrong = [...new Set(allAnswers)];
        
        // If not enough wrong answers from plays, add generic ones
        const genericDefensive = ['Man coverage on #1', 'Deep 1/3 zone', 'A gap run fit', 'Contain rush', 'Hook/Curl zone', 'Blitz off edge', 'Spy the QB'];
        const genericOffensive = ['Safety rotation', 'Corner depth', 'Linebacker drop', 'Mike linebacker', 'Blitz pickup', 'First defender outside'];
        
        const generics = isDefensivePlayer ? genericDefensive : genericOffensive;
        const combined = [...uniqueWrong, ...generics.filter(g => g !== correctAnswer)];
        
        // Shuffle and take 3
        const shuffled = combined.sort(() => Math.random() - 0.5);
        return shuffled.slice(0, 3);
      };

      // Shuffle array helper
      const shuffleArray = (array) => {
        const shuffled = [...array];
        for (let i = shuffled.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
      };

      // Generate quiz questions with multiple choice options
      const questionTypes = isDefensivePlayer 
        ? ['responsibility', 'alignment', 'read_key']
        : ['read_key', 'landmark'];
      
      const quizQuestions = myPlays.slice(0, 5).map((play, idx) => {
        const assignment = getMyAssignment(play);
        const questionType = questionTypes[idx % questionTypes.length];
        
        let question, correctAnswer;
        
        if (isDefensivePlayer) {
          switch(questionType) {
            case 'responsibility':
              question = `In "${play.name}" (${play.coverage}), what is your responsibility?`;
              correctAnswer = assignment?.responsibility || 'Not specified';
              break;
            case 'alignment':
              question = `In "${play.name}" (${play.front}), what is your alignment?`;
              correctAnswer = assignment?.alignment || 'Not specified';
              break;
            case 'read_key':
              question = `In "${play.name}" (${play.coverage}), what is your read key?`;
              correctAnswer = assignment?.read_key || 'Not specified';
              break;
            default:
              question = `In "${play.name}", what is your responsibility?`;
              correctAnswer = assignment?.responsibility || 'Not specified';
          }
        } else {
          switch(questionType) {
            case 'read_key':
              question = `In "${play.name}" (${play.formation}), what is your read key?`;
              correctAnswer = assignment?.route_details?.read_key || 'Not specified';
              break;
            case 'landmark':
              question = `In "${play.name}" (${play.formation}), what is your landmark?`;
              correctAnswer = assignment?.route_details?.landmark || 'Not specified';
              break;
            default:
              question = `In "${play.name}", what is your read key?`;
              correctAnswer = assignment?.route_details?.read_key || 'Not specified';
          }
        }
        
        const wrongAnswers = generateWrongAnswers(correctAnswer, questionType, myPlays);
        const allOptions = shuffleArray([correctAnswer, ...wrongAnswers]);
        
        return {
          play,
          question,
          correctAnswer,
          options: allOptions,
          questionType
        };
      });

      if (quizSubmitted) {
        const score = quizQuestions.reduce((acc, q, i) => {
          return acc + (quizAnswers[i] === q.correctAnswer ? 1 : 0);
        }, 0);

        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">📝 Quiz Results</h2>
              <button onClick={() => setPlayerView('dashboard')} className="bg-gray-700 px-4 py-2 rounded">← Back</button>
            </div>

            <div className={`text-center p-8 rounded-lg ${score >= quizQuestions.length * 0.8 ? 'bg-green-900' : score >= quizQuestions.length * 0.5 ? 'bg-yellow-900' : 'bg-red-900'}`}>
              <div className="text-6xl font-bold">{score}/{quizQuestions.length}</div>
              <p className="text-xl mt-2">{score >= quizQuestions.length * 0.8 ? '🏆 Excellent!' : score >= quizQuestions.length * 0.5 ? '👍 Good effort!' : '📚 Keep studying!'}</p>
            </div>

            <div className="space-y-4">
              {quizQuestions.map((q, i) => {
                const isCorrect = quizAnswers[i] === q.correctAnswer;
                return (
                  <div key={i} className={`p-4 rounded-lg border-2 ${isCorrect ? 'bg-green-900/50 border-green-500' : 'bg-red-900/50 border-red-500'}`}>
                    <p className="font-bold mb-3">{i + 1}. {q.question}</p>
                    <div className="space-y-2">
                      {q.options.map((option, j) => {
                        const isSelected = quizAnswers[i] === option;
                        const isCorrectOption = option === q.correctAnswer;
                        return (
                          <div 
                            key={j} 
                            className={`p-3 rounded ${
                              isCorrectOption 
                                ? 'bg-green-600 text-white' 
                                : isSelected 
                                  ? 'bg-red-600 text-white' 
                                  : 'bg-gray-700'
                            }`}
                          >
                            {isCorrectOption && '✓ '}{isSelected && !isCorrectOption && '✗ '}{option}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex gap-3">
              <button 
                onClick={() => { setQuizAnswers({}); setQuizSubmitted(false); }}
                className="flex-1 bg-blue-600 py-3 rounded font-bold"
              >
                🔄 Retake Quiz
              </button>
              <button 
                onClick={() => setPlayerView('dashboard')}
                className="flex-1 bg-gray-700 py-3 rounded font-bold"
              >
                Back to Dashboard
              </button>
            </div>
          </div>
        );
      }

      return (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">📝 Quiz Mode</h2>
            <button onClick={() => setPlayerView('dashboard')} className="bg-gray-700 px-4 py-2 rounded">← Back</button>
          </div>

          <div className="bg-blue-900/50 border border-blue-500 p-4 rounded-lg">
            <p className="text-blue-200">Select the correct answer for each question. You have {quizQuestions.length} questions.</p>
          </div>

          <div className="space-y-6">
            {quizQuestions.map((q, i) => (
              <div key={i} className="bg-gray-800 p-5 rounded-lg">
                <p className="font-bold text-lg mb-4">{i + 1}. {q.question}</p>
                <div className="space-y-2">
                  {q.options.map((option, j) => (
                    <button
                      key={j}
                      onClick={() => setQuizAnswers({ ...quizAnswers, [i]: option })}
                      className={`w-full text-left p-4 rounded-lg transition-all ${
                        quizAnswers[i] === option 
                          ? 'bg-blue-600 border-2 border-blue-400' 
                          : 'bg-gray-700 hover:bg-gray-600 border-2 border-transparent'
                      }`}
                    >
                      <span className="font-bold mr-3">{String.fromCharCode(65 + j)}.</span>
                      {option}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="bg-gray-800 p-4 rounded-lg">
            <div className="flex justify-between items-center mb-3">
              <span className="text-gray-400">Questions Answered:</span>
              <span className="font-bold">{Object.keys(quizAnswers).length} / {quizQuestions.length}</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all" 
                style={{ width: `${(Object.keys(quizAnswers).length / quizQuestions.length) * 100}%` }}
              ></div>
            </div>
          </div>

          <button 
            onClick={() => setQuizSubmitted(true)}
            disabled={Object.keys(quizAnswers).length < quizQuestions.length}
            className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed py-4 rounded font-bold text-lg transition-all"
          >
            {Object.keys(quizAnswers).length < quizQuestions.length 
              ? `Answer All Questions (${quizQuestions.length - Object.keys(quizAnswers).length} remaining)` 
              : '✓ Submit Quiz'}
          </button>
        </div>
      );
    }

    // Main Dashboard
    return (
      <div className="space-y-6">
        {/* Play Viewer Modal */}
        {playerStudyPlay && (
          <div className="fixed inset-0 bg-black bg-opacity-95 flex items-center justify-center p-4 z-50 overflow-y-auto">
            <div className="bg-gray-900 rounded-lg p-6 max-w-4xl w-full max-h-screen overflow-y-auto">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h2 className="text-3xl font-bold">{playerStudyPlay.name}</h2>
                  <p className="text-xl text-gray-400">
                    {isDefensivePlayer ? `${playerStudyPlay.front} - ${playerStudyPlay.coverage}` : `${playerStudyPlay.formation} • ${playerStudyPlay.snap_count}`}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => toggleMastered(playerStudyPlay.play_id)} 
                    className={`px-4 py-2 rounded font-bold ${progress[playerStudyPlay.play_id]?.mastered ? 'bg-green-600' : 'bg-gray-700'}`}
                  >
                    {progress[playerStudyPlay.play_id]?.mastered ? '✓ Mastered' : 'Mark Mastered'}
                  </button>
                  <button onClick={() => setPlayerStudyPlay(null)} className="bg-gray-700 px-6 py-2 rounded font-bold hover:bg-gray-600">Close</button>
                </div>
              </div>

              {/* My Assignment - Highlighted */}
              <div className={`${isDefensivePlayer ? 'bg-green-900 border-green-500' : 'bg-blue-900 border-blue-500'} border-2 p-6 rounded-lg mb-6`}>
                <h3 className={`text-2xl font-bold ${isDefensivePlayer ? 'text-green-400' : 'text-blue-400'} mb-4`}>
                  📍 YOUR ASSIGNMENT - {getMyAssignment(playerStudyPlay)?.position_name || getMyAssignment(playerStudyPlay)?.position_id}
                </h3>
                {isDefensivePlayer ? (
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <span className="font-bold text-blue-300">Alignment:</span>
                      <p className="text-xl mt-1">{getMyAssignment(playerStudyPlay)?.alignment}</p>
                    </div>
                    <div>
                      <span className="font-bold text-yellow-300">Read Key:</span>
                      <p className="text-xl mt-1">{getMyAssignment(playerStudyPlay)?.read_key}</p>
                    </div>
                    <div className="md:col-span-2">
                      <span className="font-bold text-purple-300">Responsibility:</span>
                      <p className="text-xl mt-1">{getMyAssignment(playerStudyPlay)?.responsibility}</p>
                    </div>
                    <div className="md:col-span-2">
                      <span className="font-bold text-orange-300">Coaching Point:</span>
                      <p className="text-xl mt-1">{getMyAssignment(playerStudyPlay)?.coaching_point}</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {getMyAssignment(playerStudyPlay)?.motion && getMyAssignment(playerStudyPlay).motion !== 'none' && (
                      <div className="bg-yellow-900 border border-yellow-500 p-3 rounded">
                        <span className="font-bold text-yellow-300">⚡ MOTION: {getMyAssignment(playerStudyPlay).motion.toUpperCase()}</span>
                      </div>
                    )}
                    <div>
                      <span className="font-bold text-green-300">Steps:</span>
                      <p className="text-lg mt-1 whitespace-pre-line">{getMyAssignment(playerStudyPlay)?.route_details?.steps || 'No steps defined'}</p>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <span className="font-bold text-yellow-300">Landmark:</span>
                        <p className="text-lg mt-1">{getMyAssignment(playerStudyPlay)?.route_details?.landmark || '-'}</p>
                      </div>
                      <div>
                        <span className="font-bold text-purple-300">Read Key:</span>
                        <p className="text-lg mt-1">{getMyAssignment(playerStudyPlay)?.route_details?.read_key || '-'}</p>
                      </div>
                    </div>
                    <div>
                      <span className="font-bold text-orange-300">Coaching Point:</span>
                      <p className="text-lg mt-1">{getMyAssignment(playerStudyPlay)?.route_details?.coaching_point || '-'}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Field Diagram */}
              <div className="bg-green-900 rounded-lg p-4 mb-6">
                <svg width={500} height={350}>
                  {[...Array(9)].map((_, i) => {
                    const yPos = 350 - (i * (350 / 8));
                    return <line key={i} x1={0} y1={yPos} x2={500} y2={yPos} stroke="#fff" strokeWidth="1" opacity="0.3" />;
                  })}
                  <line x1={0} y1={350 - (isDefensivePlayer ? 4 : 2) * (350 / 8)} x2={500} y2={350 - (isDefensivePlayer ? 4 : 2) * (350 / 8)} stroke="#ff0" strokeWidth="4" />
                  {isDefensivePlayer ? (
                    // Defensive positions
                    playerStudyPlay.positions.map(pos => {
                      const defPositions = {
                        'DE_L': { x: 15, y: 20 }, 'DT_L': { x: 22, y: 20 }, 'NT': { x: 25, y: 20 },
                        'DT_R': { x: 28, y: 20 }, 'DE_R': { x: 35, y: 20 }, 'SAM': { x: 35, y: 14 },
                        'MIKE': { x: 25, y: 14 }, 'WILL': { x: 15, y: 14 }, 'OLB_L': { x: 10, y: 16 },
                        'OLB_R': { x: 40, y: 16 }, 'ILB_L': { x: 22, y: 14 }, 'ILB_R': { x: 28, y: 14 },
                        'CB_L': { x: 5, y: 10 }, 'CB_R': { x: 45, y: 10 }, 'SS': { x: 35, y: 8 },
                        'FS': { x: 25, y: 5 }, 'NB': { x: 15, y: 12 }, 'DIME': { x: 35, y: 12 }
                      };
                      const position = defPositions[pos.position_id] || { x: 25, y: 15 };
                      const isMe = pos.position_id === selectedPlayer.position;
                      const cx = (position.x / 50) * 500;
                      const cy = 350 - (position.y / 40) * 350;
                      return (
                        <g key={pos.position_id}>
                          <circle cx={cx} cy={cy} r={isMe ? 18 : 12} fill={isMe ? "#22c55e" : "#dc2626"} stroke={isMe ? "#fff" : "#666"} strokeWidth={isMe ? 3 : 1} />
                          <text x={cx} y={cy + 4} textAnchor="middle" fill="#fff" fontSize={isMe ? 12 : 9} fontWeight="bold">{pos.position_id}</text>
                        </g>
                      );
                    })
                  ) : (
                    // Offensive positions with routes
                    playerStudyPlay.positions.map(pos => {
                      const isMe = pos.position_id === selectedPlayer.position;
                      return (
                        <g key={pos.position_id}>
                          {/* Straight line segments for route */}
                          {pos.route_points?.map((point, i) => {
                            if (i === 0) return null;
                            const prev = pos.route_points[i - 1];
                            const x1 = (prev.x / 50) * 500;
                            const y1 = 350 - (prev.y / 40) * 350;
                            const x2 = (point.x / 50) * 500;
                            const y2 = 350 - (point.y / 40) * 350;
                            return (
                              <line 
                                key={i} 
                                x1={x1} 
                                y1={y1} 
                                x2={x2} 
                                y2={y2} 
                                stroke={isMe ? "#fbbf24" : "#666"} 
                                strokeWidth={isMe ? 4 : 2} 
                                strokeLinecap="round"
                                opacity={isMe ? 1 : 0.4}
                              />
                            );
                          })}
                          {/* Arrow at end */}
                          {pos.route_points?.length > 1 && (
                            <polygon
                              points={(() => {
                                const last = pos.route_points[pos.route_points.length - 1];
                                const prev = pos.route_points[pos.route_points.length - 2];
                                const x = (last.x / 50) * 500;
                                const y = 350 - (last.y / 40) * 350;
                                const px = (prev.x / 50) * 500;
                                const py = 350 - (prev.y / 40) * 350;
                                const angle = Math.atan2(y - py, x - px);
                                const size = isMe ? 12 : 6;
                                return `${x},${y} ${x - size * Math.cos(angle - 0.5)},${y - size * Math.sin(angle - 0.5)} ${x - size * Math.cos(angle + 0.5)},${y - size * Math.sin(angle + 0.5)}`;
                              })()}
                              fill={isMe ? "#fbbf24" : "#666"}
                              opacity={isMe ? 1 : 0.4}
                            />
                          )}
                          {/* Starting position */}
                          {pos.route_points?.[0] && (
                            <circle 
                              cx={(pos.route_points[0].x / 50) * 500} 
                              cy={350 - (pos.route_points[0].y / 40) * 350} 
                              r={isMe ? 14 : 8} 
                              fill={isMe ? "#22c55e" : "#3b82f6"} 
                              stroke="#fff" 
                              strokeWidth={isMe ? 3 : 1} 
                            />
                          )}
                          {/* Position label */}
                          {pos.route_points?.[0] && (
                            <text x={(pos.route_points[0].x / 50) * 500} y={350 - (pos.route_points[0].y / 40) * 350 - 18} textAnchor="middle" fill={isMe ? "#fbbf24" : "#888"} fontSize={isMe ? 14 : 9} fontWeight="bold">
                              {pos.position_id}
                            </text>
                          )}
                        </g>
                      );
                    })
                  )}
                </svg>
              </div>

              {/* Video Link */}
              {playerStudyPlay.video_url && (
                <a href={playerStudyPlay.video_url} target="_blank" rel="noopener noreferrer" className="block bg-blue-600 hover:bg-blue-700 p-4 rounded-lg text-center font-bold">
                  📹 Watch Film
                </a>
              )}
            </div>
          </div>
        )}
        
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold">{selectedPlayer.name}</h2>
              <p className="text-gray-400">#{selectedPlayer.jersey} - {selectedPlayer.position} - {selectedPlayer.unit}</p>
            </div>
            <button onClick={() => setSelectedPlayer(null)} className="bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded text-sm">Change Player</button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-gray-800 p-4 rounded-lg text-center">
            <div className="text-3xl font-bold text-blue-400">{totalPlays}</div>
            <div className="text-sm text-gray-400">Total Plays</div>
          </div>
          <div className="bg-gray-800 p-4 rounded-lg text-center">
            <div className="text-3xl font-bold text-yellow-400">{viewedPlays}</div>
            <div className="text-sm text-gray-400">Viewed</div>
          </div>
          <div className="bg-gray-800 p-4 rounded-lg text-center">
            <div className="text-3xl font-bold text-green-400">{masteredPlays}</div>
            <div className="text-sm text-gray-400">Mastered</div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="bg-gray-800 p-4 rounded-lg">
          <div className="flex justify-between mb-2">
            <span className="font-bold">Mastery Progress</span>
            <span>{totalPlays > 0 ? Math.round((masteredPlays / totalPlays) * 100) : 0}%</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-4">
            <div className="bg-green-600 h-4 rounded-full transition-all" style={{ width: `${totalPlays > 0 ? (masteredPlays / totalPlays) * 100 : 0}%` }}></div>
          </div>
        </div>

        {/* Study Mode Buttons */}
        <div className="grid md:grid-cols-2 gap-4">
          <button 
            onClick={() => { setCurrentPlayIndex(0); setShowAnswer(false); setPlayerView('flashcards'); }}
            disabled={myPlays.length === 0}
            className="bg-purple-600 hover:bg-purple-700 p-6 rounded-lg text-left disabled:opacity-50"
          >
            <div className="text-3xl mb-2">🃏</div>
            <div className="text-xl font-bold">Flashcards</div>
            <div className="text-purple-200 text-sm">Flip through your assignments</div>
          </button>
          <button 
            onClick={() => { setQuizAnswers({}); setQuizSubmitted(false); setPlayerView('quiz'); }}
            disabled={myPlays.length === 0}
            className="bg-orange-600 hover:bg-orange-700 p-6 rounded-lg text-left disabled:opacity-50"
          >
            <div className="text-3xl mb-2">📝</div>
            <div className="text-xl font-bold">Quiz Mode</div>
            <div className="text-orange-200 text-sm">Test your knowledge</div>
          </button>
        </div>

        {/* Play List */}
        <div>
          <h3 className="text-2xl font-bold mb-3">Your Plays</h3>
          <div className="space-y-3">
            {myPlays.map(play => {
              const playProgress = progress[play.play_id] || {};
              return (
                <div key={play.play_id} className="bg-gray-800 p-4 rounded-lg">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div className="flex flex-col gap-1">
                        {playProgress.viewed && <span className="text-xs bg-blue-600 px-2 py-0.5 rounded">VIEWED</span>}
                        {playProgress.mastered && <span className="text-xs bg-green-600 px-2 py-0.5 rounded">MASTERED</span>}
                      </div>
                      <div>
                        <h4 className="font-bold text-lg">{play.name}</h4>
                        <p className="text-sm text-gray-400">{isDefensivePlayer ? `${play.front} - ${play.coverage}` : play.formation}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => { 
                        markViewed(play.play_id); 
                        setPlayerStudyPlay(play); 
                      }} 
                      className="bg-blue-600 hover:bg-blue-700 px-6 py-2 rounded font-bold"
                    >
                      Study
                    </button>
                  </div>
                </div>
              );
            })}
            {myPlays.length === 0 && <p className="text-gray-400 text-center py-8">No plays assigned to your position yet!</p>}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white overflow-x-hidden">
      {viewingDefensivePlay && <DefensivePlayViewer play={viewingDefensivePlay} onClose={() => setViewingDefensivePlay(null)} />}
      {confirmDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-900 rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Confirm Delete</h3>
            <p className="text-gray-300 mb-6">{confirmDialog.message}</p>
            <div className="flex gap-3">
              <button onClick={confirmDialog.onConfirm} className="flex-1 bg-red-600 py-3 rounded font-bold hover:bg-red-700">Delete</button>
              <button onClick={confirmDialog.onCancel} className="flex-1 bg-gray-700 py-3 rounded font-bold hover:bg-gray-600">Cancel</button>
            </div>
          </div>
        </div>
      )}
      {editingPlay && <PlayEditor play={editingPlay} onSave={(p) => { const existing = plays.find(pl => pl.play_id === p.play_id); if (existing) { const updatedPlay = { ...p, version: (existing.version || 1) + 1, updated: true }; setPlays(plays.map(pl => pl.play_id === p.play_id ? updatedPlay : pl)); } else { setPlays([...plays, { ...p, version: 1, updated: false }]); } setEditingPlay(null); }} onCancel={() => setEditingPlay(null)} />}
      {editingInstall && <InstallEditor install={editingInstall} onSave={(i) => { const ex = installs.find(inst => inst.install_id === i.install_id); if (ex) { setInstalls(installs.map(inst => inst.install_id === i.install_id ? i : inst)); } else { setInstalls([...installs, i]); } setEditingInstall(null); }} onCancel={() => setEditingInstall(null)} />}
      
      {/* Header */}
      <div className="bg-gray-900 p-4 border-b border-gray-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-bold text-blue-500">ZUNO</h1>
            {currentUser?.team && (
              <span className="text-gray-400 text-sm hidden md:block">| {currentUser.team}</span>
            )}
          </div>
          
          <div className="flex gap-4 items-center">
            {/* Unit Toggle */}
            <div className="flex gap-2 bg-gray-800 p-1 rounded">
              <button onClick={() => setUnit('offense')} className={`px-4 py-2 rounded font-bold transition-all ${unit === 'offense' ? 'bg-green-600 text-white' : 'text-gray-400 hover:text-white'}`}>🏈 Offense</button>
              <button onClick={() => setUnit('defense')} className={`px-4 py-2 rounded font-bold transition-all ${unit === 'defense' ? 'bg-red-600 text-white' : 'text-gray-400 hover:text-white'}`}>🛡 Defense</button>
            </div>
            
            {/* Role Toggle - Players cannot access Coach mode */}
            <div className="flex gap-2">
              {currentUser?.role === 'player' ? (
                // Player logged in - only show Player mode, Coach is locked
                <>
                  <button 
                    disabled 
                    className="px-4 py-2 rounded bg-gray-800 text-gray-500 cursor-not-allowed flex items-center gap-1"
                    title="Coach access restricted"
                  >
                    🔒 Coach
                  </button>
                  <button className="px-4 py-2 rounded bg-blue-600">Player</button>
                </>
              ) : (
                // Coach logged in - can switch between modes
                <>
                  <button onClick={() => setUserRole('coach')} className={`px-4 py-2 rounded ${userRole === 'coach' ? 'bg-blue-600' : 'bg-gray-800'}`}>Coach</button>
                  <button onClick={() => setUserRole('player')} className={`px-4 py-2 rounded ${userRole === 'player' ? 'bg-blue-600' : 'bg-gray-800'}`}>Player</button>
                </>
              )}
            </div>
            
            {/* User Menu */}
            <div className="flex items-center gap-3 pl-4 border-l border-gray-700">
              {/* Subscription Badge */}
              {currentUser?.subscription && (
                <span className={`text-xs font-bold px-2 py-1 rounded ${
                  currentUser.subscription === 'elite' ? 'bg-purple-600' :
                  currentUser.subscription === 'pro' ? 'bg-blue-600' :
                  'bg-gray-600'
                }`}>
                  {currentUser.subscription.toUpperCase()}
                </span>
              )}
              
              {/* User Info */}
              <div className="text-right hidden sm:block">
                <div className="text-sm font-semibold">{currentUser?.name}</div>
                <div className="text-xs text-gray-400">{currentUser?.email}</div>
              </div>
              
              {/* Avatar & Logout */}
              <div className="relative group">
                <button className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center font-bold text-lg">
                  {currentUser?.name?.charAt(0) || 'U'}
                </button>
                
                {/* Dropdown */}
                <div className="absolute right-0 mt-2 w-48 bg-gray-800 rounded-lg shadow-xl border border-gray-700 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                  <div className="p-3 border-b border-gray-700">
                    <div className="font-semibold">{currentUser?.name}</div>
                    <div className="text-xs text-gray-400">{currentUser?.role}</div>
                  </div>
                  <div className="p-2">
                    <button className="w-full text-left px-3 py-2 rounded hover:bg-gray-700 text-sm flex items-center gap-2">
                      ⚙️ Settings
                    </button>
                    <button className="w-full text-left px-3 py-2 rounded hover:bg-gray-700 text-sm flex items-center gap-2">
                      💳 Subscription
                    </button>
                    <button 
                      onClick={() => {
                        setCurrentUser(null);
                        setAuthState('login');
                        setSelectedPlayer(null);
                      }}
                      className="w-full text-left px-3 py-2 rounded hover:bg-red-900 text-red-400 text-sm flex items-center gap-2"
                    >
                      🚪 Sign Out
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex max-w-7xl mx-auto">
        {userRole === 'coach' && (
          <div className="w-64 bg-gray-900 p-4 min-h-screen sticky top-0">
            <nav className="space-y-2">
              <button onClick={() => setCurrentView('plays')} className={`w-full flex items-center gap-3 px-4 py-3 rounded ${currentView === 'plays' ? 'bg-blue-600' : 'bg-gray-800'}`}><Play size={20} /><span>Plays</span></button>
              <button onClick={() => setCurrentView('gameday')} className={`w-full flex items-center gap-3 px-4 py-3 rounded ${currentView === 'gameday' ? 'bg-green-600' : 'bg-gray-800'}`}><Radio size={20} /><span>Practice/Game</span></button>
              <button onClick={() => setCurrentView('installs')} className={`w-full flex items-center gap-3 px-4 py-3 rounded ${currentView === 'installs' ? 'bg-blue-600' : 'bg-gray-800'}`}><Calendar size={20} /><span>Installs</span></button>
              <button onClick={() => setCurrentView('roster')} className={`w-full flex items-center gap-3 px-4 py-3 rounded ${currentView === 'roster' ? 'bg-blue-600' : 'bg-gray-800'}`}><Users size={20} /><span>Roster</span></button>
              <button onClick={() => setCurrentView('analytics')} className={`w-full flex items-center gap-3 px-4 py-3 rounded ${currentView === 'analytics' ? 'bg-blue-600' : 'bg-gray-800'}`}><BarChart3 size={20} /><span>Analytics</span></button>
            </nav>
          </div>
        )}
        <div className="flex-1 p-8 min-h-screen overflow-y-auto pb-20">
          {userRole === 'coach' && currentView === 'plays' && <PlayLibrary />}
          {userRole === 'coach' && currentView === 'gameday' && <GameDayView />}
          {userRole === 'coach' && currentView === 'installs' && <InstallsView />}
          {userRole === 'coach' && currentView === 'roster' && <RosterView />}
          {userRole === 'coach' && currentView === 'analytics' && <AnalyticsView />}
          {userRole === 'player' && <PlayerDashboard />}
        </div>
      </div>
    </div>
  );
}
